<?php

return [
    'name' => 'CmsManager'
];
