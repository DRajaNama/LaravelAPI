<?php

return [
    'name' => 'EmailManager'
];
