<?php

return [
    'name' => 'FaqManager'
];
