<?php

namespace Modules\FaqManager\Entities;

use Illuminate\Database\Eloquent\Model;

class faq extends Model
{
    protected $fillable = ['heading', 'description', 'is_carrierShipper'];

    public function scopeFilter($query, $keyword) {
        if (!empty($keyword)) {
            $query->where(function($query) use ($keyword) {
                $query->where('heading', 'LIKE', '%' . $keyword . '%');
               
            });
        }
        return $query;
    }
}
