<?php
namespace Modules\FaqManager\Http\Controllers\Admin;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use Modules\FaqManager\Entities\Faq;
use Modules\FaqManager\Http\Requests\GeneralRequest;

use DB;

class FaqManagerController extends Controller
{

/**
     * Display a listing of the resource.
     * @return Response
     */
    public function getFaq(Request $request)
    {
  
        $allowed_columns = ['id', 'heading'];
        $sort = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
        $order = $request->get('direction') === 'asc' ? 'asc' : 'desc';
        $faqs = Faq::filter($request->query('keyword'))->orderBy($sort, $order)->where('status',1)->paginate(config('get.ADMIN_PAGE_LIMIT'));
        return view('faqmanager::Admin.faqs.index',compact('faqs'));

    }
/**
     * Show the form for creating a new resource.
     * @return Response
     */
     public function addFaq()
    {
        return view('faqmanager::Admin.faqs.add');
    }
/**
     * Store a newly created resource in storage.
     * @param GeneralRequest $request
     * @return Response
     */
    public function storeFaq(GeneralRequest $request)
    {
         try{

 
            $faq = Faq::create($request->all());
           

        }catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('data.faq')->with('success', 'FAQ added successfully');
    }
/**
     * Show the specified resource.
     * @param int $id
     * @return Response
     */
    public function showFaq($id)
    {
        try{

 
            $faq = Faq::find($id);
           

        }catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        
        return view('faqmanager::Admin.faqs.show',compact('faq'));
    }
/**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Response
     */
    public function editFaq($id)
    {
        try{

 
            $faq = Faq::find($id);
           

        }catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
       
        return view('faqmanager::Admin.faqs.add',compact('faq'));
    }

/**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Response
     */
 public function deleteFaq(Request $request, $id)
    {
        try{ 

            DB::delete('delete from faqs where id = ?',[$id]);
   
         }
         catch (\Illuminate\Database\QueryException $e) {
             return  ['status' => false, 'message' => $e->getMessage(), 'data' => ['id' => $id]];
         }
        
        

        
 
        $responce = ['status' => true, 'message' => 'Faq has been deleted successfully !!', 'data' => ['id' => $id]];

        return $responce;
    }

/**
     * Update the specified resource in storage.
     * @param GeneralRequest $request
     * @param int $id
     * @return Response
     */

    public function updateFaq(GeneralRequest $request, $id)
    {
        try{
            $faq = Faq::find($id);
            $faq->fill($request->all());
            $faq->save();
          }
          catch (\Illuminate\Database\QueryException $e) {
              return back()->withError($e->getMessage())->withInput();
          }
            return redirect()->route('data.faq')->with('success', 'FAQ updated successfully!');
    }



 
}