<?php
namespace Modules\FaqManager\Http\Controllers\Admin;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use Modules\FaqManager\Entities\Faq;
use Modules\FaqManager\Http\Requests\GeneralRequest;

use DB;

class FaqManagerController extends Controller
{

    public function getFaq(Request $request)
    {

        $allowed_columns = ['id', 'heading'];
        $sort = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
        $order = $request->get('direction') === 'asc' ? 'asc' : 'desc';
        $settings = Faq::orderBy($sort, $order)->where('status',0)->paginate(config('get.ADMIN_PAGE_LIMIT'));
        return view('faqmanager::Admin.faqs.page.show-faq',compact('settings'));

    }

     public function addFaq()
    {
        return view('faqmanager::Admin.faqs.page.add');
    }

    public function storeFaq(GeneralRequest $request)
    {
        //dd($request->all());die;
        try{

 
            $faq = Faq::create($request->all());
           

        }catch (\Illuminate\Database\QueryException $e) {
            return back()->withError($e->getMessage())->withInput();
        }
        return redirect()->route('data.faq')->with('success', 'FAQ added successfully');
    }

    public function showFaq($id)
    {
        $settings = Faq::find($id);
        return view('faqmanager::Admin.faqs.page.show',compact('settings'));
    }

    public function editFaq($id)
    {
        $settings = Faq::find($id);
        return view('faqmanager::Admin.faqs.page.add',compact('settings'));
    }

 public function deleteFaq(Request $request, $id)
    {
        
        //Category::destroy($id);


        $getFaqUpdated = DB::table('faqs')
                       ->where('id', '=', $id)
                       ->update(['status' => 1]);

        $allowed_columns = ['id', 'heading'];
        $sort = in_array($request->get('sort'), $allowed_columns) ? $request->get('sort') : 'created_at';
        $order = $request->get('direction') === 'asc' ? 'asc' : 'desc';
        $settings = Faq::orderBy($sort, $order)->where('status',0)->paginate(config('get.ADMIN_PAGE_LIMIT'));
        return view('faqmanager::Admin.faqs.page.show-faq',compact('settings'));
    }





    public function updateFaq(GeneralRequest $request, $id)
    {
        try{
            $faq = Faq::find($id);
            $faq->fill($request->all());
            $faq->save();
          }
          catch (\Illuminate\Database\QueryException $e) {
              return back()->withError($e->getMessage())->withInput();
          }
            return redirect()->route('data.faq')->with('success', 'FAQ updated successfully!');
    }






    /**
     * Display a listing of the resource.
     * @return Response
     */
    public function index()
    {
        return view('categorymanager::index');
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        return view('categorymanager::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show()
    {
        return view('categorymanager::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('categorymanager::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }
}