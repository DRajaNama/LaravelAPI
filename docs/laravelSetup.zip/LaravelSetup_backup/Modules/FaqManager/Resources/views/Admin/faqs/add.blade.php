@extends('layouts.admin.master')
@section('title', !empty($faq) ? 'Edit FAQ' : 'Add FAQ')
@section('content')
@include('layouts.admin.flash.alert')


<style type="text/css">
    input[type=file]{
      display: inline;
    }

    #baanner_preview{
      border: 1px solid black;
      padding: 10px;
    }

    #baanner_preview img{
      width: 200px;
      padding: 5px;
    }
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
       <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage FAQ
                <small>Here you can {{ !empty($faq) ? 'edit' : 'add' }} FAQ</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{route('data.faq')}}">{{ __("FAQ") }}</a></li>
                <li><a href="javascript:void(0)" class="active">{{ !empty($faq) ? 'Edit FAQ ' : 'Add FAQ' }}</a></li>
            </ol>
        </section>
        <section class="content" data-table="settings">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info settings">

                        <div class="box-header with-border">
                            <h3 class="box-title">{{ !empty($faq) ? 'Edit FAQ' : 'Add FAQ' }}</h3>
                            <a href="{{route('data.faq')}}" class="btn btn-default pull-right" title="Cancel"><i
                                        class="fa fa-fw fa-chevron-circle-left"></i> Back</a></div>
                        <!-- /.box-header -->
                        @if(isset($faq))
                            {{ Form::model($faq, ['route' => ['data.faq.update', $faq->id], 'method' => 'patch', 'enctype' => 'multipart/form-data']) }}
                        @else
                         {{ Form::open(['route' => 'data.faq.store', 'enctype' => 'multipart/form-data']) }}
                        @endif
                             
                            <div class="box-body">
                                <div class="row">
                                        
                                    <div class="col-md-12">

                                         <div class="form-group required {{ $errors->has('is_carrierShipper') ? 'has-error' : '' }}">
                                             <div class="input select">
                                                <label for="is_carrierShipper">User Type</label>
                                                
                                                    <select id="is_carrierShipper" name="is_carrierShipper" class="form-control">
                                                    <option value="">Select User Type</option>
                                                    @if(isset($faq))
                                                    <option value="0" <?php if($faq->is_carrierShipper == 0) { echo "selected"; } ?>>Carrier</option>
                                                    <option value="1" <?php if($faq->is_carrierShipper == 1) { echo "selected"; }?>>Shipper</option>
                                                    @else
                                                    <option value="0">Carrier</option>
                                                    <option value="1">Shipper</option>
                                                    @endif
                                                    
                                                    </select>
                                            @if($errors->has('is_carrierShipper'))
                                            <span class="help-block">{{ $errors->first('is_carrierShipper') }}</span>
                                            @endif
                                           </div>
                                        </div>






                                        <div class="form-group required {{ $errors->has('heading') ? 'has-error' : '' }}">
                                             <div class="input text">
                                            <label for="heading">Question</label>
                                            {{ Form::text('heading', old('heading'), ['class' => 'form-control','placeholder' => 'Enter Question']) }}
                                            @if($errors->has('heading'))
                                            <span class="help-block">{{ $errors->first('heading') }}</span>
                                            @endif
                                        </div>
                                        </div>


                                        <div class="form-group required {{ $errors->has('description') ? 'has-error' : '' }}" style="">
                                            <div class="input textarea">
                                                <label for="category_textarea">Solution</label>
                                                {{ Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Provide Answer', 'rows' => 5]) }}
                                                @if($errors->has('description'))
                                                <span class="help-block">{{ $errors->first('description') }}</span>
                                                @endif
                                            </div>
                                        </div>

 
                                        

                                        

                                    </div>
                                </div><!-- /.row -->
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i
                                            class="fa fa-fw fa-save"></i> Submit
                                </button>
                                <a href="{{route('data.faq')}}" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>

      

</div>
</section>

@stop



