@extends('layouts.admin.master')

@section('title') FAQS @stop
@section('content')
@include('layouts.admin.flash.alert')
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage FAQ
                <small>Here you can manage the FAQS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{route('data.faq')}}" class="active">FAQ</a></li>
            </ol>
        </section>

        @php
        $qparams = app('request')->query();

        @endphp
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title"><span class="caption-subject font-green bold uppercase">List FAQ</span></h3>
                            <div class="box-tools">
                                <a href="{{route('data.faq.add')}}" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> New FAQ</a>
                            </div>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive">
                             <div class="tab-content" style="margin-top:10px;">
                                 {{ Form::open(['url' => route('data.faq', $qparams),'method' => 'get']) }}
                         <div class="col-md-12">
                            <div class="row">
                                
                                <div class="col-md-5 form-group">
                                    {{ Form::text('keyword', app('request')->query('keyword'), ['class' => 'form-control','placeholder' => 'Keyword e.g: question, answer']) }}
                                </div>
                                <div class="col-md-3 form-group">
                                    <button class="btn btn-success" title="Search" type="submit"><i class="fa fa-filter"></i> Filter</button>
                                    <a href="{{ route('data.faq') }}" class="btn btn-warning" title="Cancel"><i class="fa fa-fw fa-refresh"></i> Reset</a>
                                </div>
                            </div>
                        </div>
                        {{ Form::close() }}
                         <div class="tab-pane active">
                              <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th scope="col"><a href="{{ URL::route('data.faq',['sort' => 'heading','direction'=> request()->direction == 'asc' ? 'desc' : 'asc']) }}">Question</a></th>
                                    <th scope="col">Type</th>
                                    <th scope="col" class="actions" style="width: 15%;">Actions</th>
                                </tr>
                                </thead>
                                    @if($faqs->count() > 0)
                                    <tbody>
                                @php
                                $i = (($faqs->currentPage() - 1) * ($faqs->perPage()) + 1)
                                @endphp
                                @foreach($faqs as $faq)
                                    <tr class="row-{{ $faq->id }}">
                                        <td> {{$i}}. </td>
                                        <td>{{$faq->heading}}</td>
                                        
                                    <td>

                                        {{ $faq->is_carrierShipper == 0 ? 'Carrier' : 'Shipper' }}
                                      
                                    </td>
                                        <td class="actions">
                                             
                                                <a href="{{url('admin/faqs/view/'.$faq->id)}}" class="btn btn-warning btn-sm" data-toggle="tooltip" alt="View Category" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;
                                                <a href="{{url('admin/faqs/edit/'.$faq->id)}}" class="btn btn-primary btn-sm" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                &nbsp;&nbsp;
                                                

                                                  <a href="javascript:void(0);" class="confirmDeleteBtn btn btn-danger btn-sm btn-flat" data-toggle="tooltip" alt="Delete FAQ" data-url="{{ route('data.faq.delete', $faq->id) }}" data-title="FAQ"><i class="fa fa-trash"></i></a>
                                             
                                        </td>
                                    </tr>
                                @php
                                    $i++;
                                @endphp
                                @endforeach
                                </tbody>
                                @else
                                <tfoot>
                                    <tr>
                                        <td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
                                    </tr>
                                </tfoot>
                                @endif
                            </table>
                        </div>
                        </div>
                    </div>
                        <div class="box-footer clearfix">
                            {{$faqs->appends(Request::query())->links()}}
                         </div>
                    </div>
                </div>
                
            </div>
        </section>
@stop
