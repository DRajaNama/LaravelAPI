@extends('layouts.admin.master')
@section('title') View Faq @stop
@section('content')
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage FAQ
                <small>FAQ Detail</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{url('admin/dashboard')}}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{route('data.faq')}}">FAQ</a></li>
                <li><a href="javascript:void(0)" class="active">FAQ Detail</a></li>
            </ol>
        </section>
        <section class="content" data-table="settings">
            <div class="box">

                <div class="box-header"><h3 class="box-title">FAQ Detail</h3>
                    <a href="{{route('data.faq')}}" class="btn btn-default pull-right" title="Cancel"><i
                        class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                </div>

                <div class="box-body">
                     
                     <table class="table table-hover table-striped">
                        <tbody>

                        <tr>
                            <th scope="row">Type</th>
                            <td> {{ $faq->is_carrierShipper == 0 ? 'Carrier' : 'Shipper' }}</td>
                        </tr>
                        <tr>
                            <th scope="row">Question</th>
                            <td>{{$faq->heading}}</td>
                        </tr>
                         
                        <tr>
                            <th scope="row">Answer</th>
                            <td>{!! $faq->description !!}</td>
                        </tr>

                        
                         
                        <tr>
                            <th scope="row">Created</th>
                            <td>{{$faq->created_at}}</td>
                        </tr>
                        <tr>
                            <th scope="row">Modified</th>
                            <td>{{$faq->updated_at}}</td>
                        </tr>
                        </tbody></table>

                </div>
            </div>
        </section>
@stop
