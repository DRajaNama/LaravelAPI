<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin/faqs')->middleware('auth:admin')->namespace('Admin')->group(function () {
    Route::get('/', 'FaqManagerController@getFaq')->name('data.faq');
    Route::get('/add', 'FaqManagerController@addFaq')->name('data.faq.add');
    Route::post('/add', 'FaqManagerController@storeFaq')->name('data.faq.store');
    Route::get('/view/{id}', 'FaqManagerController@showFaq')->name('data.faq.view');
    Route::get('/edit/{id}', 'FaqManagerController@editFaq')->name('data.faq.edit');
    Route::get('/delete/{id}', 'FaqManagerController@deleteFaq')->name('data.faq.delete');
    Route::delete('/delete/{id}', 'FaqManagerController@deleteFaq')->name('data.faq.delete');
    Route::patch('/{id}/edit', 'FaqManagerController@updateFaq')->name('data.faq.update');
});
