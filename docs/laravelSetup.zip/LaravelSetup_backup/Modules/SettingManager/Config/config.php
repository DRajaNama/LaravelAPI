<?php

return [
    'name' => 'SettingManager'
];
