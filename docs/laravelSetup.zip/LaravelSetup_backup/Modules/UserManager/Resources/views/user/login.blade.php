@extends('layouts.master')
@section('title','Home Page')
@section('content')
@include('layouts.admin.flash.alert')

<!-- main-content -->
<div class="main-content">
   <div class="container">
      <form class="custom-form userform">
         <h2 class="circle-line">Member Login</h2>
         <div class="form-group">
            <div class="row">
               <div class="col-lg-12">
                  <label class="label">Username</label>
               </div>
               <div class="col-lg-12">
                  <input type="text" class="form-control user-icon" placeholder="Enter Your Name">
               </div>
            </div>
         </div>
         <div class="form-group">
            <div class="row">
               <div class="col-lg-12">
                  <label class="label">Password</label>
               </div>
               <div class="col-lg-12">
                  <input type="password" class="form-control lock-icon" placeholder="Enter Your Password">
               </div>
            </div>
         </div>
         <div class="form-group">
            <div class="row">
               <div class="col-lg-12">
                  <div class="d-flex align-items-center rm-f-pass">
                     <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="customCheck1">
                        <label class="custom-control-label" for="customCheck1">Remember my login details</label>
                     </div>
                     <a href="javascript:void(0);" class="yellow-text ml-auto">Forgot Password?</a>
                  </div>
               </div>
            </div>
         </div>
         <button class="btn btn-custom yellow-text">Login Now</button>
         <div class="form-below-text">New user? <a href="registration.html">Register here.</a></div>
         <div class="form-bottom">
            <div class="seperator"><span>OR</span></div>
            <div class="social-link">
               <div class="title">Sign in with</div>
               <ul class="social-list">
                  <li>
                     <a href="javascript:void(0);"><i class="fab fa-facebook-f"></i></a>
                  </li>
                  <li>
                     <a href="javascript:void(0);"><i class="fab fa-google-plus-g"></i></a>
                  </li>
                  <li>
                     <a href="javascript:void(0);"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                  </li>
               </ul>
            </div>
         </div>
      </form>
   </div>
</div>
<!-- main-content -->
@stop
