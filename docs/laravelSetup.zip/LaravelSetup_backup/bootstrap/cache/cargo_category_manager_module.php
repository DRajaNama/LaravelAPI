<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CargoCategoryManager\\Providers\\CargoCategoryManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CargoCategoryManager\\Providers\\CargoCategoryManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);