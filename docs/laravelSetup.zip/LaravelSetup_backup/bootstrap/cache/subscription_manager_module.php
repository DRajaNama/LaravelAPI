<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SubscriptionManager\\Providers\\SubscriptionManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SubscriptionManager\\Providers\\SubscriptionManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);