-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2020 at 02:36 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravelsetup`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_resets`
--

CREATE TABLE `admin_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_password_resets`
--


-- --------------------------------------------------------

--
-- Table structure for table `admin_roles`
--

CREATE TABLE `admin_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1: Super user, 0: General User',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_roles`
--

INSERT INTO `admin_roles` (`id`, `title`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 1, '2019-02-26 21:28:03', NULL),
(2, 'Admin', 0, '2019-02-26 21:28:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_role_admin_user`
--

CREATE TABLE `admin_role_admin_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `admin_role_id` int(10) UNSIGNED NOT NULL,
  `admin_user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_role_admin_user`
--

INSERT INTO `admin_role_admin_user` (`id`, `admin_role_id`, `admin_user_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(2, 1, 2, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(3, 2, 3, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(4, 1, 4, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(5, 2, 5, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(6, 1, 6, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(7, 1, 7, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(8, 1, 8, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(9, 2, 9, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(10, 1, 10, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(11, 1, 11, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(12, 2, 12, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(13, 1, 13, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(14, 2, 14, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(15, 2, 15, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(16, 2, 16, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(17, 2, 17, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(18, 1, 18, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(19, 2, 19, '2019-02-26 21:28:06', '2019-02-26 21:28:06'),
(20, 2, 20, '2019-02-26 21:28:06', '2019-02-26 21:28:06');

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password_reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1: Active User, 0: Inactive User',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `name`, `email`, `mobile`, `password`, `profile_photo`, `email_verified_at`, `password_reset_token`, `remember_token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@yopmail.com', '1234567890', '$2y$10$fPFtlazdCHXKCReuTFnzbOrW6JLnLMOts5HlNyYrkVmrJbC1ZNsf6', NULL, '2020-01-15 18:30:00', NULL, 'MZpIuxXBPoHt0OjHcxMeu3VTUKdbLzO8yZZ20GNHCUwHSnQLUuKF7zDzeJO1', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `email_hooks`
--

CREATE TABLE `email_hooks` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=in active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_hooks`
--

INSERT INTO `email_hooks` (`id`, `title`, `slug`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Welcome Email - App Register', 'welcome-email', 'when user has been registered then send welcome email for verify account.', 1, '2019-02-27 00:03:36', '2019-02-27 00:03:36'),
(2, 'Admin Forgot Password Email', 'forgot-password-email', 'Forgot Password Email send when the admin has forgot password', 1, '2019-02-27 00:04:17', '2019-02-27 00:04:17'),
(4, 'Contact us', 'contact-us', 'Contact usContact usContact usContact us Contact us', 1, '2019-02-27 00:05:18', '2019-02-27 00:05:18'),
(5, 'User Forgot Password Email', 'user-forgot-password-email', 'Forgot Password Email send when the user has forgot password', 1, '2019-02-27 00:04:17', '2019-02-27 00:04:17'),
(6, 'Welcome Email - Registered From Admin', 'welcome-email-user-admin', 'when user has been registered by the admin then send welcome email for verify account.', 1, '2019-02-27 00:03:36', '2019-02-27 00:03:36'),
(7, 'Inquiry Mail', 'inquiry-mail', 'Inquiry Mail', 1, '0000-00-00 00:00:00', '2019-02-27 00:03:36');

-- --------------------------------------------------------

--
-- Table structure for table `email_preferences`
--

CREATE TABLE `email_preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `layout_html` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_preferences`
--

INSERT INTO `email_preferences` (`id`, `title`, `layout_html`, `created_at`, `updated_at`) VALUES
(1, 'Main Layout', '<html>\r\n<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /></head>\r\n<body><div>\r\n<table align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"border:1px solid #dddddd;\" width=\"650\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<table cellpadding=\"0\" cellspacing=\"0\" style=\"background:#ffffff; border-bottom:1px solid #dddddd; padding:15px;\" width=\"100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td><a href=\"##BASE_URL##\" target=\"_blank\"><img alt=\"\" border=\"0\" src=\"##SYSTEM_LOGO##\" /></a></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"background:#ffffff; padding:15px;\">\r\n			<table cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n				<tbody>\r\n					<tr>\r\n						<td style=\"font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif; color:#000000; font-size:16px;\">\r\n							##EMAIL_CONTENT##\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td style=\"font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif; color:#043f8d; font-size:16px; vertical-align:middle; text-align:left; padding-top:20px;\">\r\n						##EMAIL_FOOTER##\r\n						</td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"background:#043f8d; border-top:1px solid #dddddd; text-align:center; font-family:\'Trebuchet MS\', Arial, Helvetica, sans-serif; color:#ffffff; padding:12px; font-size:12px; text-transform:uppercase; font-weight:normal;\">##COPYRIGHT_TEXT##</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</div>\r\n</body>\r\n</head>\r\n</html>', '2019-02-27 00:05:47', '2019-02-27 00:05:47');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `email_hook_id` int(10) UNSIGNED NOT NULL,
  `subject` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_preference_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=in active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `email_hook_id`, `subject`, `description`, `footer_text`, `email_preference_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '##USER_NAME##, a very warm welcome to the ##SYSTEM_APPLICATION_NAME##', '<p>We&rsquo;re so happy to have you with us.</p>\r\n\r\n<p>Please click on the button below to confirm we got the right email address.</p>\r\n\r\n<p><a href=\"##VERIFY_LINK##\">VERIFY MY EMAIL</a></p>\r\n\r\n<p>Or copy and paste the link below.</p>\r\n\r\n<p>##VERIFY_LINK##</p>', 'Thanks and Regards,\r\n##SYSTEM_APPLICATION_NAME##', 1, 1, '2019-02-27 00:20:47', '2019-10-02 08:27:45'),
(2, 2, 'Reset Password Notification', '<h1 style=\"font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; color: #2F3133; font-size: 19px; font-weight: bold; margin-top: 0; text-align: left;\">Hello!</h1>\r\n\r\n<p style=\"font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; color: #74787E; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;\">You are receiving this email because we received a password reset request for your account.</p>\r\n\r\n<p style=\"font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; color: #74787E; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;\"><a href=\"##RESET_PASSWORD_URL##\">Reset Password</a></p>\r\n\r\n<p style=\"font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; color: #74787E; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;\">This password reset link will expire in 60 minutes.</p>\r\n\r\n<p style=\"font-family: Avenir, Helvetica, sans-serif; box-sizing: border-box; color: #74787E; font-size: 16px; line-height: 1.5em; margin-top: 0; text-align: left;\">If you did not request a password reset, no further action is required.</p>', 'Thanks & Regards,\r\n##SYSTEM_APPLICATION_NAME##', 1, 1, '2019-02-27 00:21:52', '2019-02-27 00:21:52'),
(3, 5, 'New Password Notification', '<p>Hi ##USER_NAME##,</p>\r\n\r\n<p><br />\r\nYour New Password is ##PASSWORD##.</p>\r\n\r\n<p>Please use this password to login in the mobile app.</p>', 'Thanks & Regards,\r\n##SYSTEM_APPLICATION_NAME##', 1, 1, '2019-02-27 00:21:52', '2019-10-03 00:27:36'),
(4, 6, '##USER_NAME##, a very warm welcome to the ##SYSTEM_APPLICATION_NAME##', '<p>We&rsquo;re so happy to have you with us.</p>\r\n\r\n<p>Please click on the button below to confirm we got the right email address.</p>\r\n\r\n<p><a href=\"##VERIFY_LINK##\">VERIFY MY EMAIL</a></p>\r\n\r\n<p>Your auto generated password to login in mobile app is ##PASSWORD## </p>', 'Thanks and Regards,\r\n##SYSTEM_APPLICATION_NAME##', 1, 1, '2019-02-27 00:20:47', '2019-10-02 08:27:45'),
(5, 7, '##INQUIRY_SUBJECT##', '<p>Name : ##INQUIRY_NAME##<br />\r\nEmail : ##INQUIRY_EMAIL##<br />\r\nPhone : ##INQUIRY_PHONE##<br />\r\n<br />\r\nInquiry Message:<br />\r\n##INQUIRY_MESSAGE##</p>', 'Thanks and Regards,\r\n##SYSTEM_APPLICATION_NAME##', 1, 1, '2019-02-27 00:20:47', '2019-10-04 03:05:19');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `heading` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0=active, 1=in active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `heading`, `description`, `status`, `created_at`, `updated_at`) VALUES
(26, 'Lorem ipsum dolor sit amet, gubergren elaboraret eos ne, bonorum volumus interpretaris per ad.', '<p>Civibus quaerendum sit ei, usu errem quidam definitionem ut, pro quod scaevola inimicus cu. Ut integre legendos incorrupte ius. Sea saperet prodesset posidonium te, usu in numquam erroribus similique. Qui facilisi scribentur dissentiunt no, prima atomorum vulputate an vim, ei eam tale assueverit.</p>', 1, '2019-09-17 00:06:40', '2019-09-17 00:06:40'),
(27, 'Cum falli expetenda in, ad nam inani discere, ludus nominavi ea eum. Sed dico timeam scriptorem ne, mei veritus platonem interpretaris te, pro ne saepe copiosae facilisis.', '<p>Offendit vituperatoribus vix ne, postea dicunt tamquam mel no. Eum et docendi epicuri abhorreant, usu ea essent gloriatur necessitatibus, id ius solet graecis corpora. No nominavi interpretaris ius.</p>\r\n\r\n<p>Cum altera disputando at, ut augue ceteros democritum nam, malis cotidieque vel no. Cetero necessitatibus duo an, id fastidii epicurei abhorreant sit.</p>', 1, '2019-09-17 00:07:48', '2019-09-17 00:07:48'),
(28, 'Qui at ipsum efficiendi, nec nullam deseruisse reformidans eu. Vim erant dolorem ut, nec ut vide ludus.', '<p>Ut praesent salutandi est, eu mazim lobortis vel, ad eos errem nonumy luptatum. No duo ludus labitur volutpat. Ei eum dicant delicata, noster copiosae ei vim. No sea augue definiebas, et periculis temporibus vix. Saepe quidam percipitur ei vim, per conceptam neglegentur id. Has eu ridens appetere deseruisse, essent luptatum eu per. Mea viris invenire no, vel et meliore epicuri vulputate, at viderer lobortis vulputate sea.</p>', 1, '2019-09-17 00:08:08', '2019-09-17 00:08:08'),
(29, 'Mea id consul contentiones, in essent minimum adolescens vim. Ea eam stet iusto, sea an quaeque utroque percipitur, ea debet vocent mei. Sit audiam legimus deseruisse ea, ne mea appetere aliquando.', '<p><br />\r\nUt praesent salutandi est, eu mazim lobortis vel, ad eos errem nonumy luptatum. No duo ludus labitur volutpat. Ei eum dicant delicata, noster copiosae ei vim. No sea augue definiebas, et periculis temporibus vix. Saepe quidam percipitur ei vim, per conceptam neglegentur id. Has eu ridens appetere deseruisse, essent luptatum eu per. Mea viris invenire no, vel et meliore epicuri vulputate, at viderer lobortis vulputate sea.</p>', 1, '2019-09-17 00:08:36', '2019-09-17 00:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('01a28ffaebcf029660f84885b64ef83667c9807cbb27e121de093367b8bc036e609debe039ac05b0', 2, 1, 'Maxminpower', '[]', 0, '2019-09-30 08:57:42', '2019-09-30 08:57:42', '2020-09-30 14:27:42'),
('12f73060ad57ca2381669f43e94388c4aa9ef02aa84929423c1dd133512d6d471af45016a0a90c38', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:03:59', '2019-10-01 01:03:59', '2020-10-01 06:33:59'),
('1e29e6e57370f47868a103025ba66c8d0f613b494ad48101a8dfacb057441345f7a359a2c9cadf55', 2, 1, 'Maxminpower', '[]', 0, '2019-12-09 01:01:48', '2019-12-09 01:01:48', '2020-12-09 06:31:48'),
('1f407ad514d93724c99f63c9e3a8d1bac0c3923041a36698baf725441d026db3bac023d92eced550', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:10:52', '2019-10-01 01:10:52', '2020-10-01 06:40:52'),
('2059a209306282437b31f6491e5b01aa931de7447a0b27f623028dbc6a54f2a6728a62905871cf97', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 01:10:07', '2019-12-06 01:10:07', '2020-12-06 06:40:07'),
('27d901c11edbe58569b92fbf9a865109d5e253dc1a4f08046979ea01eb3b664be09aa47a0fa27a55', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:02:17', '2019-10-01 01:02:17', '2020-10-01 06:32:17'),
('301993d337e3e35190f33862da52d01f0a9f8fda0b90b7c2d23bccb3aca1116b6250568403002b3b', 2, 1, 'Maxminpower', '[]', 0, '2019-12-05 23:52:04', '2019-12-05 23:52:04', '2020-12-06 05:22:04'),
('3300652b7c738a6057cb0b4068d290ee9e9d965a8a19aae725955aae964c0e30a951488299ecea58', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:01:22', '2019-10-01 01:01:22', '2020-10-01 06:31:22'),
('3c76a10f2babff31810fd946bf5fad7ff969ba14a3b3939213186b329bbe0e347c1a93ed4aad1f73', 2, 1, 'Maxminpower', '[]', 0, '2019-10-01 04:25:17', '2019-10-01 04:25:17', '2020-10-01 09:55:17'),
('3ffd941db0d04cd410c29db9c414c4cf69409a89a0159a23b96dd9752f3384f8f1751d14c5fd348b', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 01:13:45', '2019-12-06 01:13:45', '2020-12-06 06:43:45'),
('41075ea153796fc761f4072ea05b556bf01a945d5fe7bb115aa31c1f3a8a136f1e0d0cbf43dedd28', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:00:22', '2019-10-01 01:00:22', '2020-10-01 06:30:22'),
('4ad460d7cec1457a263011503d8db8803f7ad52a9d9da8ad8d82018ad514e0d05c9c6153276c56d3', 2, 1, 'Maxminpower', '[]', 0, '2019-12-05 23:57:33', '2019-12-05 23:57:33', '2020-12-06 05:27:33'),
('62b15f9be81d284318125cf3cf5a884fde85f604e25cbd0567e40a2c0c0f74c1cda0c4511753609e', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:03:42', '2019-10-01 01:03:42', '2020-10-01 06:33:42'),
('7cd764213384abd0d05e92eb0fa027f64e18609ce25c7543aec0db743ec0a641fae812ffb5e92739', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:05:43', '2019-10-01 01:05:43', '2020-10-01 06:35:43'),
('7df8c5289a0ce353739ee002457dbbe0665158d86540450028ca48557caf6a2dce2742c49d2ce451', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:15:43', '2019-12-06 00:15:43', '2020-12-06 05:45:43'),
('7e0bc88a4548b7fba23abe581bff5d0e6dc26d7b6878b38adfc096a138866a05ff9e262e335612b8', 2, 1, 'Maxminpower', '[]', 0, '2019-12-09 00:54:59', '2019-12-09 00:54:59', '2020-12-09 06:24:59'),
('81f23e4c0b36afd65f9cdcdaf263563444f23225a90fd262c787b5a08df287f698d39b5dbfe3d1f2', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:41:35', '2019-12-06 00:41:35', '2020-12-06 06:11:35'),
('99ef984a455f0c66e5c4ffaa9814a66a130cff6cf54c3b3e68c933b8fca2c7e819b092255c0503e4', 2, 1, 'Maxminpower', '[]', 0, '2019-12-10 05:00:27', '2019-12-10 05:00:27', '2020-12-10 10:30:27'),
('9e6851710f35324d29c197879b98a1e157499807842233a283ff01e617cef74ba27ea39306c5b412', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:00:46', '2019-10-01 01:00:46', '2020-10-01 06:30:46'),
('ab0af5b584a8de827b527a0ea05fb2f719b90f53bff7243eb329079fabbcdc4056466630dbb330f3', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:10:47', '2019-10-01 01:10:47', '2020-10-01 06:40:47'),
('bbdcf07e7c25d87f2b074492a83e9d3f2d66f9228dea5fd0f91d38700d86c440894178684793e921', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:45:39', '2019-12-06 00:45:39', '2020-12-06 06:15:39'),
('bd9d0dac80be93a198e22b3518dcd45b5c097feb19dc72864a9c7f4b29b9a0e83348e6c0ce976de6', 2, 1, 'Maxminpower', '[]', 0, '2019-12-10 00:02:03', '2019-12-10 00:02:03', '2020-12-10 05:32:03'),
('dc8ff78f7de17e248d9020ac6289552addf400ae76a078973b42f946d8ebb746b67f90a25c1e2bc6', 29, 1, 'Maxminpower', '[]', 0, '2019-10-01 01:03:54', '2019-10-01 01:03:54', '2020-10-01 06:33:54'),
('df754d428a4fcb263dc194f193033f1f034a34f7a88227dfebf92c97e01cc45886e34f8f6b4da5f5', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:14:16', '2019-12-06 00:14:16', '2020-12-06 05:44:16'),
('eb36e9d1e70c7352c23d60a97f7860abb61e7646aa107dbca99dcb82fa379acc33beeed1274e8567', 2, 1, 'Maxminpower', '[]', 0, '2019-12-10 05:00:38', '2019-12-10 05:00:38', '2020-12-10 10:30:38'),
('edd885b562c132b898c7a29fa39f6100a825abf8eb88ccc5bcd87768e4549fd716b8694764cc5374', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:24:50', '2019-12-06 00:24:50', '2020-12-06 05:54:50'),
('fd8c8e0a3c2c6c7568bc57950dedf5c2e4e2e8222834a8ece42de6935844fd74518cfc1c7f1aecce', 2, 1, 'Maxminpower', '[]', 0, '2019-12-06 00:02:18', '2019-12-06 00:02:18', '2020-12-06 05:32:18');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'NGBWrLsoLqkyMtlWoxXeohr3Xwr1fM8EZbhHrR31', 'http://localhost', 1, 0, 0, '2019-09-27 08:32:08', '2019-09-27 08:32:08'),
(2, NULL, 'Laravel Password Grant Client', 'rkAGYOh83ZyQrPiZ059R7L3stnPLC8BDZF9F3PI0', 'http://localhost', 0, 1, 0, '2019-09-27 08:32:09', '2019-09-27 08:32:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-09-27 08:32:09', '2019-09-27 08:32:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keyword` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=in active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `sub_title`, `slug`, `short_description`, `description`, `banner`, `meta_title`, `meta_keyword`, `meta_description`, `status`, `created_at`, `updated_at`) VALUES
(6, 'Monthly', 'Monthly', 'monthly-2', 'Monthly', '<p>Monthly</p>', NULL, 'Monthly', 'Monthly', 'Monthly', 0, '2019-09-03 04:48:41', '2019-09-03 04:48:41'),
(7, 'Frequently Answer Question', 'faq', 'faq', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', NULL, 'faq', 'faq', 'faq', 0, '2019-09-16 09:08:59', '2019-10-03 01:48:42'),
(8, 'Terms and Conditions', 'Terms and Conditions', 'terms-conditions', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', NULL, 'Terms and Conditions', 'Terms and Conditions', 'Terms and Conditions', 1, '2019-09-16 23:30:36', '2019-10-03 01:48:28'),
(9, 'test test', 'test', 'test', 'test', '<p>test</p>', NULL, 'test', 'test', 'test', 0, '2019-09-17 01:52:34', '2019-09-17 01:52:34'),
(10, 'test test', 'test test', 'test-test', 'test test', '<p>test test</p>', NULL, 'test test', 'test test', 'test test', 0, '2019-09-17 01:53:26', '2019-09-17 01:53:26'),
(11, 'Contact Us', 'Contact Us', 'contact-us', 'Contact Us', '<p>Contact Us</p>', NULL, 'Contact Us', 'Contact Us', 'Contact Us', 0, '2019-09-17 01:54:17', '2019-09-17 01:54:17'),
(12, 'About Us', 'About Us', 'about-us', 'About Us', '<div>\r\n<h2>What is Lorem Ipsum?</h2>\r\n\r\n<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n\r\n<div>\r\n<h2>Why do we use it?</h2>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n\r\n<p>&nbsp;</p>', NULL, 'About Us', 'About Us', 'About Us', 1, '2019-09-17 23:31:58', '2019-10-03 01:11:35');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `manager` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `slug`, `config_value`, `manager`, `field_type`, `created_at`, `updated_at`) VALUES
(1, 'Website Name', 'SYSTEM_APPLICATION_NAME', 'LaravelSetup', 'general', 'text', '2019-02-27 00:33:36', '2019-12-05 08:14:23'),
(2, 'Admin Email', 'ADMIN_EMAIL', 'admin@yopmail.com', 'general', 'text', '2019-02-27 00:33:36', '2020-01-13 03:29:58'),
(3, 'From Email', 'FROM_EMAIL', 'developer@yopmail.com', 'general', 'text', '2019-02-27 00:33:36', '2020-01-13 03:29:42'),
(4, 'Owner Name', 'WEBSITE_OWNER', 'LaravelSetup', 'general', 'text', '2019-02-27 00:33:36', '2020-01-13 03:30:31'),
(5, 'Telephone', 'TELEPHONE', '+00 0000000000', 'general', 'text', '2019-02-27 00:33:36', '2020-01-13 04:52:18'),
(6, 'Admin Page Limit', 'ADMIN_PAGE_LIMIT', '10', 'general', 'text', '2019-02-27 00:33:36', '2020-01-17 07:23:18'),
(7, 'Front Page Limit', 'FRONT_PAGE_LIMIT', '20', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(8, 'Admin Date Format', 'ADMIN_DATE_FORMAT', 'd F, Y', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(9, 'Admin Date Time Format', 'ADMIN_DATE_TIME_FORMAT', 'd F, Y H:i A', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(10, 'Front Date Format', 'FRONT_DATE_FORMAT', 'd F, Y', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(11, 'Front Date Time Format', 'FRONT_DATE_TIME_FORMAT', 'd F, Y', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(12, 'Reset URL expired in hours', 'RESET_URL_EXPIRED', '24', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(13, 'Development Mode', 'DEVELOPMENT_MODE', '1', 'general', 'checkbox', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(14, 'Default currency', 'DEFAULT_CURRENCY', 'USD', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(15, 'Contact us text', 'CONTACT_US_TEXT', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(16, 'Google Map Api Key', 'GOOGLE_MAP_KEY', 'AIzaSyD9pg6_fzfgDHJFSW0wkrIcuCOw_V9qOfM', 'general', 'text', '2019-02-27 00:33:36', '2019-02-27 00:33:36'),
(17, 'Office Address', 'ADDRESS', 'Office LaravelSetup', 'general', 'text', '2019-02-27 00:33:36', '2020-01-13 03:30:54'),
(20, 'SMTP ALLOW', 'SMTP_ALLOW', '1', 'smtp', 'text', '2019-02-27 00:33:36', '2019-02-28 22:29:23'),
(21, 'Email Host Name', 'SMTP_EMAIL_HOST', 'smtp@mail.com', 'smtp', 'text', '2019-02-27 00:33:36', '2020-01-13 04:53:11'),
(22, 'SMTP Username', 'SMTP_USERNAME', 'wwwsmtpsetup.co', 'smtp', 'text', '2019-02-27 00:33:36', '2020-01-13 04:53:11'),
(23, 'SMTP password', 'SMTP_PASSWORD', 'smtppassword', 'smtp', 'text', '2019-02-27 00:33:36', '2020-01-13 04:53:11'),
(24, 'SMTP port', 'SMTP_PORT', '25', 'smtp', 'text', '2019-02-27 00:33:36', '2019-02-28 22:29:23'),
(25, 'SMTP Tls', 'SMTP_TLS', '1', 'smtp', 'text', '2019-02-27 00:33:36', '2019-02-28 22:29:24'),
(47, 'Main Favicon', 'MAIN_FAVICON', '1578910753-setting-laravel.jpg', 'theme_images', 'text', '2019-02-27 21:09:43', '2020-01-13 04:49:16'),
(48, 'MAIN LOGO', 'MAIN_LOGO', '1578909936-setting-laravel.jpg', 'theme_images', 'text', '2019-02-27 21:09:43', '2020-01-13 04:40:18'),
(52, 'TEST SETTING', 'dar', 'TEST SETTING', 'general', 'text', '2019-02-28 01:13:03', '2020-01-17 07:46:35'),
(53, 'sferg', 'ergrweg', 'rwegtt', 'general', 'text', '2019-02-28 18:18:08', '2019-02-28 18:18:08'),
(55, 'contact email', 'CONTACT_EMAIL', 'info@laravelSetup.com', 'general', 'text', '2019-09-13 06:15:50', '2020-01-13 03:30:17'),
(56, 'facebook url', 'FACEBOOK_URL', 'https://www.facebook.com', 'general', 'text', '2019-09-13 07:31:00', '2019-09-13 07:37:08'),
(57, 'twitter url', 'TWITTER_URL', 'https://www.twitter.com', 'general', 'text', '2019-09-13 07:31:51', '2019-09-13 07:37:21'),
(58, 'linkedIn url', 'LINKEDIN_URL', 'https://www.linkedin.com', 'general', 'text', '2019-09-13 07:32:39', '2019-09-13 07:32:39'),
(59, 'google url', 'GOOGLE_URL', 'https://www.google.com', 'general', 'text', '2019-09-13 07:33:03', '2019-09-13 07:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `api_token` text COLLATE utf8mb4_unicode_ci,
  `verification_code` text COLLATE utf8mb4_unicode_ci,
  `device_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_id` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `is_notifiable` tinyint(1) NOT NULL DEFAULT '1',
  `is_download_offline` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `phone`, `photo`, `gender`, `api_token`, `verification_code`, `device_type`, `device_id`, `status`, `is_verified`, `is_notifiable`, `is_download_offline`, `created_at`, `updated_at`) VALUES
(2, 'Main', 'Developer', 'developer@yopmail.com', '$2y$10$5j1fsbSGQOf6ccBSYUXLTuoNzG6Ws9hJYuOIr.Jhdxibriizx11fC', '1234567890', '1575957779.jpg', 0, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImViMzZlOWQxZTcwYzczNTJjMjNkNjBhOTdmNzg2MGFiYjYxZTc2NDZhYTEwN2RiY2E5OWRjYjgyZmEzNzlhY2MzM2JlZWVkMTI3NGU4NTY3In0.eyJhdWQiOiIxIiwianRpIjoiZWIzNmU5ZDFlNzBjNzM1MmMyM2Q2MGE5N2Y3ODYwYWJiNjFlNzY0NmFhMTA3ZGJjYTk5ZGNiODJmYTM3OWFjYzMzYmVlZWQxMjc0ZTg1NjciLCJpYXQiOjE1NzU5NzM4MzgsIm5iZiI6MTU3NTk3MzgzOCwiZXhwIjoxNjA3NTk2MjM4LCJzdWIiOiIyIiwic2NvcGVzIjpbXX0.oYOJNIcC9YoG1mNPhLceKfR1iQAbuTmpTBRCDu7d2Zp4fuQJ9DRdIDtCOaUSQONP8JWcAHCLzduOjAhDZPjTmhlO0SFUxGxzPzaRvaWkuajFm4hJsNSsF4HvuRu7UA2abrSEFpgGdGX-EVYuZYKdFflqFzqIz_cianCZhpLPAkjNkXDVYMtYFTmHOX-cJTGbgD9h1wBoMkbwNBZQ7VxbGoHiRJ2i1FZvMuKd8S8lOzkijsfqvc3wr51qpv6It8x__A1z424KB8bR8Rxjgek60YLxCkDv1_8V6LP9zHqen1Pdh9wFVk_2T3Dz0gjl7AwAu1a1ufu1VjohAgqk_CzqPOOOoDqMBHnI0RzWJ6kX8JA7lFIjokpsm1nfK-6jA6D5ihEMSBHokKvCsc_AzGQ7gGFPRFhuuckwApuNh_Ho2SAUzCvqkdfVZQSGWVJ61jQrkSsu9EAi4nlgA9t1hfIVHRK86k53bFmUL_GFS7oxDQT3UZGSUNKUflebxNs5pi_gzh0jI9pA601a_pOj5d_Z8SajES7v4tf7ky7E4vfZobC5OBF73guVCxVZFQSBlmo-tOV_7DfJonUSrHvnEE-gw83vfinvPzJIkBGfNCAWXDXwKWrzkyJ-l9RoFmitvhnT5QsP6xBxEhoRMEFlxefphb7_2LfxHgYg1WOEFisAYyA', NULL, '', '', 1, 1, 1, 0, '2019-09-30 01:41:23', '2020-01-17 04:06:08'),
(50, 'Dev', 'test', 'Dev@test.com', '$2y$10$Y61yydCsLG.xSzsbu/hpY.LelTvgmC9jOjG9y3zz7bj890u2F3/DW', '1234567890', 'Koala-1575960692.jpg', 0, NULL, 'DJUcvjnP', NULL, NULL, 1, 1, 1, 0, '2019-12-10 01:21:32', '2019-12-10 01:21:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  ADD KEY `admin_password_resets_email_index` (`email`(191));

--
-- Indexes for table `admin_roles`
--
ALTER TABLE `admin_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_role_admin_user`
--
ALTER TABLE `admin_role_admin_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_role_admin_user_admin_role_id_foreign` (`admin_role_id`),
  ADD KEY `admin_role_admin_user_admin_user_id_foreign` (`admin_user_id`);

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_hooks`
--
ALTER TABLE `email_hooks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_hooks_slug_unique` (`slug`);

--
-- Indexes for table `email_preferences`
--
ALTER TABLE `email_preferences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_templates_email_hook_id_foreign` (`email_hook_id`),
  ADD KEY `email_templates_email_preference_id_foreign` (`email_preference_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_slug_unique` (`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_roles`
--
ALTER TABLE `admin_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_role_admin_user`
--
ALTER TABLE `admin_role_admin_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_hooks`
--
ALTER TABLE `email_hooks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_preferences`
--
ALTER TABLE `email_preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_role_admin_user`
--
ALTER TABLE `admin_role_admin_user`
  ADD CONSTRAINT `admin_role_admin_user_admin_role_id_foreign` FOREIGN KEY (`admin_role_id`) REFERENCES `admin_roles` (`id`),
  ADD CONSTRAINT `admin_role_admin_user_admin_user_id_foreign` FOREIGN KEY (`admin_user_id`) REFERENCES `admin_users` (`id`);

--
-- Constraints for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD CONSTRAINT `email_templates_email_hook_id_foreign` FOREIGN KEY (`email_hook_id`) REFERENCES `email_hooks` (`id`),
  ADD CONSTRAINT `email_templates_email_preference_id_foreign` FOREIGN KEY (`email_preference_id`) REFERENCES `email_preferences` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
