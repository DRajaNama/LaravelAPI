<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
<!--        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e($adminUser->name); ?></p>
            </div>
        </div>-->

        <?php
        $currentUrl = \Illuminate\Support\Facades\Request::segment(2);
        ?>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php if($currentUrl == 'dashboard'): ?> active <?php endif; ?>">
                <a href="<?php echo e(url('admin/dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
            
           



 <!-- #### Manage faq #### -->


             <li class="treeview <?php echo e(in_array(\Request::route()->getName(), ["data.faq","data.faq.add","data.faq.edit","data.faq.view"]) ? "active" : ""); ?>">
                <a href="#">
                    <i class="fa fa-question-circle"></i>
                    <span>FAQ</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                   
                    <li class="<?php echo e(in_array(\Request::route()->getName(), ["data.faq","data.faq.add","data.faq.edit","data.faq.view"]) ? "active" : ""); ?>">
                        <a href="<?php echo e(url('admin/faqs')); ?>"><i class="fa fa-circle-o"></i>Manage FAQ</a>
                    </li>

                     
                </ul>
            </li>

 <!-- #### Manage faq #### -->

 




            <li class="treeview <?php echo e(in_array(\Request::route()->getName(), ["admin.pages.index","admin.pages.create","admin.pages.edit","admin.pages.show"]) ? "active" : ""); ?>">
                <a href="#">
                    <i class="fa fa-th"></i>
                    <span>CMS Manager</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(in_array(\Request::route()->getName(), ["admin.pages.index","admin.pages.create","admin.pages.edit","admin.pages.show"]) ? "active" : ""); ?>">
                        <a href="<?php echo e(route('admin.pages.index')); ?>"><i class="fa fa-circle-o"></i> CMS Pages</a>
                    </li>
                </ul>
            </li>






            <li class="treeview <?php echo e(in_array(\Request::route()->getName(), ["admin.hooks","admin.add-hooks","admin.edit-hooks","admin.view-hooks","admin.email-preferences.index","admin.email-preferences.create","admin.email-preferences.edit","admin.email-preferences.show", "admin.email-templates.index","admin.email-templates.create","admin.email-templates.edit","admin.email-templates.show"]) ? "active" : ""); ?>">
                <a href="#">
                    <i class="fa fa-fw fa-envelope-o"></i>
                    <span>Email Templates</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(in_array(\Request::route()->getName(), ["admin.hooks","admin.add-hooks","admin.edit-hooks","admin.view-hooks"]) ? "active" : ""); ?>"><a href="<?php echo e(route('admin.hooks')); ?>"><i class="fa fa-circle-o"></i> Hooks (slugs)</a></li>
                    <li class="<?php echo e(in_array(\Request::route()->getName(), ["admin.email-preferences.index","admin.email-preferences.create","admin.email-preferences.edit","admin.email-preferences.show"]) ? "active" : ""); ?>">
                            <a href="<?php echo e(route('admin.email-preferences.index')); ?>">
                                <i class="fa fa-circle-o"></i> Email Preferences (layouts)
                            </a>
                        </li>
                    <li  class="<?php echo e(in_array(\Request::route()->getName(), ["admin.email-templates.index","admin.email-templates.create","admin.email-templates.edit","admin.email-templates.show"]) ? "active" : ""); ?>">
                            <a href="<?php echo e(route('admin.email-templates.index')); ?>">
                                <i class="fa fa-circle-o"></i> Email Templates</a>
                            </li>
                </ul>
            </li>
            <li class="treeview <?php echo e(in_array(\Request::route()->getName(), ["settingtheme","setting.smtp","setting.general","setting.general.add","setting.general.view","setting.general.edit"]) ? "active" : ""); ?>">
                <a href="#">
                    <i class="fa fa-gear"></i>
                    <span>Settings</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(\Request::route()->getName() == "settingtheme" ? "active" : ""); ?>"><a href="<?php echo e(url('admin/settings/logos')); ?>">
                            <i class="fa fa-circle-o"></i> Logo/Favicon Icon</a>
                    </li>
                    <li class="<?php echo e(in_array(\Request::route()->getName(), ["setting.general","setting.general.add","setting.general.edit","setting.general.view"]) ? "active" : ""); ?>">
                        <a href="<?php echo e(url('admin/settings/logos')); ?>"><a href="<?php echo e(url('admin/settings/general')); ?>"><i class="fa fa-circle-o"></i> General Settings</a>
                    </li>

                    <li class="<?php echo e(\Request::route()->getName() == "setting.smtp" ? "active" : ""); ?>"><a href="<?php echo e(url('admin/settings/smtp')); ?>"><i class="fa fa-circle-o"></i> SMTP Details</a></li>
                    
                </ul>
            </li>

            <li class="<?php echo e(in_array(\Request::route()->getName(), ["admin.changepassword"]) ? "active" : ""); ?>">
                <a href="<?php echo e(route("admin.changepassword")); ?>">
                    <i class="fa fa-unlock"></i> <span>Change Password</span>
                </a>
            </li>
            <li class="<?php echo e(in_array(\Request::route()->getName(), ["admin.changepassword"]) ? "active" : ""); ?>">
                    <a href="<?php echo e(route('admin.logout')); ?>"
                    onclick="event.preventDefault();
                                    document.getElementById('logout-sidebarform').submit();">
                    <i class="fa fa-power-off"></i> <span><?php echo e(__('Logout')); ?></span>
                </a>
                </li>

        </ul>
        <form id="logout-sidebarform" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
    </section>
    <!-- /.sidebar -->
</aside>
