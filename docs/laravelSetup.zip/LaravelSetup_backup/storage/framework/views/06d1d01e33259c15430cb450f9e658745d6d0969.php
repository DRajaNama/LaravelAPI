<?php $__env->startSection('title', !empty($subscriptionPlan) ? 'Edit subscription plan' : 'Add subscription plan'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (subscription plan header) -->
    <section class="content-header">
        <h1>
            Manage subscription plans
            <small>Here you can manage <?php echo e(!empty($subscriptionPlan) ? 'edit subscription plan' : 'add subscription plan'); ?></small>
        </h1>
        <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.subscriptionplans.index'],['label' => !empty($subscriptionPlan) ? 'Edit subscription plan' : 'Add subscription plan' ]]])); ?>

    </section>
    <section class="content" data-table="subscription plans">

            <div class="row subscription plans">
                <div class="col-md-12">

                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($subscriptionPlan) ? 'Edit subscription plan' : 'Add subscription plan'); ?> </h3>
                            <a href="<?php echo e(route('admin.subscriptionplans.index', app('request')->query())); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                        </div><!-- /.box-header -->
                <?php if(isset($subscriptionPlan)): ?>
                <?php
                    $queryStr['id'] = $subscriptionPlan->id;
                    $queryStr = array_merge( $queryStr , app('request')->query());
                ?>
                    <?php echo e(Form::model($subscriptionPlan, ['url' => route('admin.subscriptionplans.update', $queryStr) , 'method' => 'patch','enctype'=>'multipart/form-data'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['url' => route('admin.subscriptionplans.store', app('request')->query()),'enctype'=>'multipart/form-data'])); ?>

                <?php endif; ?>
                <div class="box-body">

                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                                <li class="<?php echo e((!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>"><a href="#g_details" data-toggle="tab" aria-expanded="true">General Detail</a></li>
                                <li class="<?php echo e(!(!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>"><a href="#description_content" data-toggle="tab" aria-expanded="true">Description</a></li>

                        </ul>
                    <div class="tab-content">
                            <div class="tab-pane <?php echo e((!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>" id="g_details">
                            <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="title">Plan Name</label>
                                                    <div class="col-md-9">
                                                        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                                        <?php if($errors->has('title')): ?>
                                                        <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                        </div>

                                        <div class="form-group required <?php echo e($errors->has('amount') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="amount">Amount</label>
                                                    <div class="col-md-9">
                                                        <?php echo e(Form::number('amount', old('amount'), ['class' => 'form-control','placeholder' => 'Amount','min'=>0,'step' => '0.01','readonly' => !empty($subscriptionPlan) ? true : false])); ?>

                                                        <?php if($errors->has('amount')): ?>
                                                        <span class="help-block"><?php echo e($errors->first('amount')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                        </div>
                                        <div class="form-group hide <?php echo e($errors->has('duration') ? 'has-error' : ''); ?>">
                                            <div class="row">
                                                <label class="col-md-3 control-label" for="duration">Plan Duration</label>
                                                <div class="col-md-9">
                                                    <?php echo e(Form::number('duration', old('duration'), ['class' => 'form-control ','placeholder' => 'Enter Days'])); ?>

                                                    <?php if($errors->has('duration')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('duration')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group  required <?php echo e($errors->has('plan_interval') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="last_name">Interval</label>
                                                    <div class="col-md-9">
                                                            <?php echo e(Form::select('plan_interval', ['month' => 'month', 'year' => 'year'], old("plan_interval"), ['class' => 'form-control', 'disabled' => !empty($subscriptionPlan) ? true : false])); ?>

                                                    </div>
                                                    <?php if($errors->has('plan_interval')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('plan_interval')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                        </div>

                                        <div class="form-group  <?php echo e($errors->has('trail_days') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="trail_days">TrialDays</label>
                                                    <div class="col-md-9">
                                                        <?php echo e(Form::number('trail_days', old('trail_days'), ['class' => 'form-control ','placeholder' => 'Enter Days'])); ?>

                                                        <?php if($errors->has('trail_days')): ?>
                                                        <span class="help-block"><?php echo e($errors->first('trail_days')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>


                                        <div class="form-group  required <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="last_name">Status</label>
                                                    <div class="col-md-9">
                                                            <?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>

                                                    </div>
                                                </div>
                                        </div>
                                        
                                    </div>


                                    <div class="col-md-6">
                            <?php $features=config::get('constant.plan_features');
                            @$i=1;
                            if(!empty($subscriptionPlan)){
                                $existingfeatures = $subscriptionPlan->subscription_plan_features->pluck('value','title')->toArray();
                            }
                            ?>
                                                                <!--right side section-->
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $value='';
                            if( !empty($subscriptionPlan) && $existingfeatures && array_key_exists($key,$existingfeatures)){

                                $value=$existingfeatures[$key];
                            }
                            else{
                                $value=old("subscription_plan_features[$i][value]");
                            }
                            ?>
                            <div class="form-group required <?php echo e($errors->has('subscription_plan_features.'.$i.'.value') ? 'has-error' : ''); ?>">
                                    <div class="row">
                                        <label class="col-md-3 control-label" for=""><?php echo e($feature); ?></label>
                                        <div class="col-md-9">
                                                <?php echo e(Form::hidden("subscription_plan_features[$i][title]", $key, ['class' => 'form-control'])); ?>

                                                <?php echo e(Form::text("subscription_plan_features[$i][value]",$value, ['class' => 'form-control','placeholder' => $feature])); ?>

                                                <?php if($errors->has('subscription_plan_features.'.$i.'.value')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('subscription_plan_features.'.$i.'.value')); ?></span>
                                                    <?php endif; ?>
                                        </div>
                                    </div>
                            </div>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div> <!-- /.row -->

                            </div>


                            <div class="tab-pane <?php echo e(!(!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>" id="description_content">
                                    <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                                    <label for="description">Description</label>
                                                    <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ','placeholder' => 'Description', 'rows' => 8])); ?>

                                                    <?php if($errors->has('description')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                                    <?php endif; ?>
                                                </div>


                                            </div>
                                        </div>
                            </div>

                    </div>
                </div>
                </div><!-- /.box-body -->
                <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                        <a href="<?php echo e(route('admin.subscriptionplans.index', app('request')->query())); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                    </div>
                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('per_page_style'); ?>
<link href="<?php echo e(asset('plugins/select2-develop/dist/css/select2.min.css')); ?>" rel="stylesheet" />
<style>
.ui-sortable-helper {
    display: table;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('per_page_script'); ?>
<script>


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>