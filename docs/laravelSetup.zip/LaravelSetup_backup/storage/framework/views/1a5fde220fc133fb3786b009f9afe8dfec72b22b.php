

<?php $__env->startSection('title'); ?> Services <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage Services
                <small>Here you can manage the Services</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('data.service')); ?>" class="active">Services</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title"><span class="caption-subject font-green bold uppercase">List Services</span></h3>
                            <div class="box-tools">
                                <a href="<?php echo e(route('data.service.add')); ?>" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> New Services</a>
                            </div>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive">
                            <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Constant</th>
                                    <th scope="col">Description</th>
                                    <th scope="col" class="actions" style="width: 15%;">Actions</th>
                                </tr>
                                </thead>
                                    <?php if($services->count() > 0): ?>
                                    <tbody>
                                <?php
                                $i = (($services->currentPage() - 1) * ($services->perPage()) + 1)
                                ?>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="row-<?php echo e($service->id); ?>">
                                        <td> <?php echo e($i); ?>. </td>
                                        <td><?php echo e($service->title); ?></td>
                                        <td><?php echo e($service->slug); ?></td>
                                        <td><?php echo $service->description; ?></td>
                                        <td class="actions">
                                             
                                                <a href="<?php echo e(url('admin/services/view/'.$service->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" alt="View Category" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;
                                                <a href="<?php echo e(url('admin/services/edit/'.$service->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                &nbsp;&nbsp;
                                                  

                                                  <a href="javascript:void(0);" class="confirmDeleteBtn btn btn-danger btn-sm btn-flat" data-toggle="tooltip" alt="Cargo Category" data-url="<?php echo e(route('data.service.delete', $service->id)); ?>" data-title="Cargo Category"><i class="fa fa-trash"></i></a>



                                             
                                        </td>
                                    </tr>
                                <?php
                                    $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php else: ?>
                                <tfoot>
                                    <tr>
                                        <td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
                                    </tr>
                                </tfoot>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="box-footer clearfix">
                            <?php echo e($services->appends(Request::query())->links()); ?>

                         </div>
                    </div>
                </div>
                
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>