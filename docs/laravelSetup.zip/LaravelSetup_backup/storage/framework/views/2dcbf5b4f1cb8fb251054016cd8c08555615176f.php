<?php $__env->startSection('title','View Price Range Detail'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content-header">
    <h1>
        Manage Price Ranges
        <small>Here you can view Price Range detail</small>
    </h1>
    <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.price-ranges.index'],['label' => 'View Price Range Detail']]])); ?>

</section>

<section class="content" data-table="emailHooks">
    <div class="box">
        <div class="box-header"><h3 class="box-title"><?php echo e($price_range->title); ?></h3>
            
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row"><?php echo e(__('Title')); ?></th>
                    <td><?php echo e($price_range->title); ?></td>
                </tr>


              

                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td><?php echo e($price_range->created_at->toFormattedDateString()); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Modified')); ?></th>
                    <td><?php echo e($price_range->updated_at->toFormattedDateString()); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Status')); ?></th>
                    <td><?php echo e($price_range->status ? __('Active') : __('Inactive')); ?></td>
                </tr>
            </table>
            
        </div>
        <div class="box-footer">
                <a href="<?php echo e(route('admin.price-ranges.index')); ?>" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>