<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Road Transport</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="<?php echo e(asset('css/front/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/front/all.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo e(asset('css/front/animate.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" href="<?php echo e(asset('css/front/thumbslider.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.css">
<link href="<?php echo e(asset('css/front/style.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/front/responsive.css')); ?>" rel="stylesheet" type="text/css">
<script src="<?php echo e(asset('js/front/jquery-2.2.3.min.js')); ?>"></script>
<?php echo $__env->yieldContent('per_page_style'); ?>
</head>
<body>
        <!--header-->
    <?php echo $__env->make('partials.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--header-->
    <?php echo $__env->yieldContent('content'); ?>

<!--footer-->
<?php echo $__env->make('partials.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--footer-->
<div id="back-top"><a href="#top"><img src="<?php echo e(asset('img/html-images/back-to-top.png')); ?>" alt="top"></a></div>
<script src="<?php echo e(asset('js/front/bootstrap.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/owl.carousel-min.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/viewportchecker.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/jquery.waypoints.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/jquery.rcounterup.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/active.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/jquery.flexslider.js')); ?>"></script>
<script src="<?php echo e(asset('js/front/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('per_page_script'); ?>
</body>
</html>
