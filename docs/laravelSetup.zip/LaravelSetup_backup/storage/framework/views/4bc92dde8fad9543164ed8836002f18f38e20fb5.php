<?php $__env->startSection('title', !empty($faq) ? 'Edit FAQ' : 'Add FAQ'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<style type="text/css">
    input[type=file]{
      display: inline;
    }

    #baanner_preview{
      border: 1px solid black;
      padding: 10px;
    }

    #baanner_preview img{
      width: 200px;
      padding: 5px;
    }
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
       <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage FAQ
                <small>Here you can <?php echo e(!empty($faq) ? 'edit' : 'add'); ?> FAQ</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('data.faq')); ?>"><?php echo e(__("FAQ")); ?></a></li>
                <li><a href="javascript:void(0)" class="active"><?php echo e(!empty($faq) ? 'Edit FAQ ' : 'Add FAQ'); ?></a></li>
            </ol>
        </section>
        <section class="content" data-table="settings">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info settings">

                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($faq) ? 'Edit FAQ' : 'Add FAQ'); ?></h3>
                            <a href="<?php echo e(route('data.faq')); ?>" class="btn btn-default pull-right" title="Cancel"><i
                                        class="fa fa-fw fa-chevron-circle-left"></i> Back</a></div>
                        <!-- /.box-header -->
                        <?php if(isset($faq)): ?>
                            <?php echo e(Form::model($faq, ['route' => ['data.faq.update', $faq->id], 'method' => 'patch', 'enctype' => 'multipart/form-data'])); ?>

                        <?php else: ?>
                         <?php echo e(Form::open(['route' => 'data.faq.store', 'enctype' => 'multipart/form-data'])); ?>

                        <?php endif; ?>
                             
                            <div class="box-body">
                                <div class="row">
                                        
                                    <div class="col-md-12">

                                         <div class="form-group required <?php echo e($errors->has('is_carrierShipper') ? 'has-error' : ''); ?>">
                                             <div class="input select">
                                                <label for="is_carrierShipper">User Type</label>
                                                
                                                    <select id="is_carrierShipper" name="is_carrierShipper" class="form-control">
                                                    <option value="">Select User Type</option>
                                                    <?php if(isset($faq)): ?>
                                                    <option value="0" <?php if($faq->is_carrierShipper == 0) { echo "selected"; } ?>>Carrier</option>
                                                    <option value="1" <?php if($faq->is_carrierShipper == 1) { echo "selected"; }?>>Shipper</option>
                                                    <?php else: ?>
                                                    <option value="0">Carrier</option>
                                                    <option value="1">Shipper</option>
                                                    <?php endif; ?>
                                                    
                                                    </select>
                                            <?php if($errors->has('is_carrierShipper')): ?>
                                            <span class="help-block"><?php echo e($errors->first('is_carrierShipper')); ?></span>
                                            <?php endif; ?>
                                           </div>
                                        </div>






                                        <div class="form-group required <?php echo e($errors->has('heading') ? 'has-error' : ''); ?>">
                                             <div class="input text">
                                            <label for="heading">Question</label>
                                            <?php echo e(Form::text('heading', old('heading'), ['class' => 'form-control','placeholder' => 'Enter Question'])); ?>

                                            <?php if($errors->has('heading')): ?>
                                            <span class="help-block"><?php echo e($errors->first('heading')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        </div>


                                        <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>" style="">
                                            <div class="input textarea">
                                                <label for="category_textarea">Solution</label>
                                                <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Provide Answer', 'rows' => 5])); ?>

                                                <?php if($errors->has('description')): ?>
                                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

 
                                        

                                        

                                    </div>
                                </div><!-- /.row -->
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i
                                            class="fa fa-fw fa-save"></i> Submit
                                </button>
                                <a href="<?php echo e(route('data.faq')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>

      

</div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>