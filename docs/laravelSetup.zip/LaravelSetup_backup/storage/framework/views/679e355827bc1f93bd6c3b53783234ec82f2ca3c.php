<?php $__env->startSection('title'); ?> Add Banner <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<style type="text/css">
    input[type=file]{
      display: inline;
    }

    #baanner_preview{
      border: 1px solid black;
      padding: 10px;
    }

    #baanner_preview img{
      width: 200px;
      padding: 5px;
    }
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
       <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage Banners
                <small>Here you can <?php echo e(!empty($testimonials) ? 'edit' : 'add'); ?> Banners</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('data.bannerscategory')); ?>"><?php echo e(__("Banners")); ?></a></li>
                <li><a href="javascript:void(0)" class="active"><?php echo e(!empty($testimonials) ? 'Edit Banners ' : 'Add Banners'); ?></a></li>
            </ol>
        </section>
        <section class="content" data-table="testimonials">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info testimonials">

                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($testimonials) ? 'Edit Banners' : 'Add Banners'); ?></h3>
                            <a href="<?php echo e(route('data.bannerscategory')); ?>" class="btn btn-default pull-right" title="Cancel"><i
                                        class="fa fa-fw fa-chevron-circle-left"></i> Back</a></div>
                        <!-- /.box-header -->
                        <?php if(isset($testimonials)): ?>
                            <?php echo e(Form::model($testimonials, ['route' => ['data.bannerscategory.update', $testimonials->id], 'method' => 'patch', 'enctype' => 'multipart/form-data'])); ?>

                        <?php else: ?>
                         <?php echo e(Form::open(['route' => 'data.bannerscategory.store', 'enctype' => 'multipart/form-data'])); ?>

                        <?php endif; ?>
                             
                            <div class="box-body">
                                <div class="row">
                                        
                                    <div class="col-md-8 col-md-offset-2">

                                        <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                             <div class="input text">
                                            <label for="title">Title</label>
                                            <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Enter title name','required'=>'required'])); ?>

                                            <?php if($errors->has('title')): ?>
                                            <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        </div>


                                        <div class="form-group required <?php echo e($errors->has('status') ? 'has-error' : ''); ?>" style="">
                                             <!-- <div class="input text">
                                            <label for="designation">Status</label>
                                            <?php echo e(Form::text('status', old('status'), ['class' => 'form-control','placeholder' => 'Enter status name'])); ?>

                                           
                                        </div> -->
                                        <div class="input select">
                                                <label for="status">Status</label>
                                                
                                                    <select id="status" name="status" class="form-control">
                                                    <option value="">Select status </option>
                                                    <?php if(old('status')): ?>
                                                    <option value="1" <?php if(old('status') == 1) { echo "selected"; } ?>>Active</option>
                                                    <option value="0" <?php if(old('status') == 0) { echo "selected"; }?>>InActive</option>
                                                    <?php else: ?>
                                                    <option value="1">Active</option>
                                                    <option value="0">InActive</option>
                                                    <?php endif; ?>
                                                    
                                                    </select>
                                            <?php if($errors->has('status')): ?>
                                            <span class="help-block"><?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                           </div>
                                        </div>


                                        <div class="form-group required <?php echo e($errors->has('sort_order') ? 'has-error' : ''); ?>" style="">
                                            <div class="input textarea">
                                                <label for="sort_order">Sort Order</label>
                                                <?php echo e(Form::number('sort_order', old('sort_order'), ['class' => 'form-control ckeditor','placeholder' => 'Provide sort order','required'=>'required','min'=>0])); ?>

                                                <?php if($errors->has('sort_order')): ?>
                                                <span class="help-block"><?php echo e($errors->first('sort_order')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                       
                                          <!-- <div class="form-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>" style="">
                                            

                                            <div id="image_preview">

                                            <?php if(isset($testimonials)): ?>
                                             <img src="<?php echo e(asset('testimonial-image/'.$testimonials->image)); ?>" style="width: 400px;">
                                            <?php endif; ?>
                                               </div>

                                            <br/>


                                            <div class="input file">
                                                <label for="image_file">Upload Image</label>
                                                <input type="file" accept="image/*" id="image" name="image"/>
                                                <?php if($errors->has('image')): ?>
                                                <span class="help-block"><?php echo e($errors->first('image')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div> -->


                                        

                                    </div>
                                </div><!-- /.row -->
                            </div><!-- /.box-body -->
                            
                    

         <div class="col-md-12">
                    <table id="bannewrImages" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="text-left" style="width: 20%;">Title</th>
                                
                                <th class="text-center" style="width: 20%;">Description</th>

                                <th class="text-left" style="width: 20%;">Link</th>
                                <th class="text-right" style="width: 10%;">Image</th> 
                                <th class="text-right" style="width: 10%;">Sort Order</th>
                                <th  style="width: 8%;"></th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php
                                  $bannerImages = old('banner_images') ?? [];
                                  $inc = 0;
                              ?>
                              <?php $__currentLoopData = $bannerImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr id="imageBox-<?php echo e($inc); ?>" class="imageBox">
                                        <td class="text-left  required <?php echo e($errors->has('banner_images.'.$inc.'.title') ? 'has-error' : ''); ?>">
                                            
                                            <input required type="text" name="banner_images[<?php echo e($inc); ?>][title]" placeholder="Title"  value="<?php echo e(old('banner_images.'.$inc.'.title')); ?>" class="form-control" />
                                            <?php if($errors->has('banner_images.'.$inc.'.title')): ?>
                                                <span class="help-block"><?php echo e($errors->first('banner_images.'.$inc.'.title')); ?></span>
                                                <?php endif; ?>
                                        </td>
                                        
                                        <td class="text-left  required <?php echo e($errors->has('banner_images.'.$inc.'.description') ? 'has-error' : ''); ?>">
                                            
                                            <textarea required name="banner_images[<?php echo e($inc); ?>][description]" placeholder="Description" class="form-control"><?php echo e(old('banner_images.'.$inc.'.description')); ?></textarea>
                                            
                                        </td>
                                        
                                        <td class="text-left  required <?php echo e($errors->has('banner_images.'.$inc.'.external_link') ? 'has-error' : ''); ?>">
                                            
                                            <input required type="url" name="banner_images[<?php echo e($inc); ?>][external_link]" placeholder="Link" value="<?php echo e(old('banner_images.'.$inc.'.external_link')); ?>" class="form-control" />
                                            <?php if($errors->has('banner_images.'.$inc.'.external_link')): ?>
                                                <span class="help-block"><?php echo e($errors->first('banner_images.'.$inc.'.external_link')); ?></span>
                                                <?php endif; ?>
                                        </td>

                                        <td class="text-right  required <?php echo e($errors->has('banner_images.'.$inc.'.image') ? 'has-error' : ''); ?>">
                                            
                                                   <img   src="<?php echo e(asset('img/no_image.gif')); ?>" style="max-height:100px;">
                                                    <button class="btn bg-olive btn-flat margin button-upload" data-toggle="tooltip" title="Upload File" data-loading-text="Loading..." type="button">
                                                    <i class="fa fa-upload"></i>
                                                        Upload
                                                    </button>
                                                    <input type="hidden" name="banner_images[<?php echo e($inc); ?>][image]" class="img_hidden" value="" />
                                                    <?php if($errors->has('banner_images.'.$inc.'.image')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('banner_images.'.$inc.'.image')); ?></span>
                                                    <?php endif; ?>
                                                       
                                        </td>

                                        <td class="text-right  required <?php echo e($errors->has('banner_images.'.$inc.'.sort_order') ? 'has-error' : ''); ?>">
                                            
                                                <input  min='0' required type="number" name="banner_images[<?php echo e($inc); ?>][sort_order]" 
                                                value="<?php echo e(old('banner_images.'.$inc.'.sort_order')); ?>" placeholder="Sort Order" class="form-control" />
                                                <?php if($errors->has('banner_images.'.$inc.'.sort_order')): ?>
                                                <span class="help-block"><?php echo e($errors->first('banner_images.'.$inc.'.sort_order')); ?></span>
                                                <?php endif; ?>
                                        </td>
                                        <td class="text-left">
                                            
                                            <button type="button" onclick="$('#imageBox-' + <?php echo e($inc); ?> + ', .tooltip').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button>
                                        </td>
                            </tr>
                            <?php $inc++ ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5"></td>
                                <td class="text-left">
                                    <button type="button" onclick="addImage();" data-toggle="tooltip" title="<?= __('Add Banner') ?>" class="btn btn-primary">
                                        <i class="fa fa-plus-circle"></i>
                                    </button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                           <div class="box-footer">
                                <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i
                                            class="fa fa-fw fa-save"></i> Submit
                                </button>
                                <a href="<?php echo e(route('data.bannerscategory')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                            </div>
                        <?php echo e(Form::close()); ?>


                </div>
                </div>

</div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('per_page_script'); ?>
 <script type="text/javascript">
    var image_row = <?php echo e($inc); ?>;
    function addImage(language_id) {
      
     html = '<tr id="imageBox-' + image_row + '" class="imageBox">';
    html += '  <td class="text-left"><input required type="text" name="banner_images[' + image_row + '][title]" placeholder="Title" class="form-control" /></td>';
    
    html += '  <td class="text-left"><textarea required name="banner_images[' + image_row + '][description]" placeholder="Description" class="form-control"></textarea></td>';
    
   html += '  <td class="text-left"><input required type="text" name="banner_images[' + image_row + '][external_link]" placeholder="Link" class="form-control" /></td>';

    html += '  <td>';
            html += '<div class="thumbimage" id="imageBox-' + image_row + '">';
            html += ' <img src="<?php echo e(asset('img/no_image.gif')); ?>" class="img-thumbnail"  style="max-height:100px;" alt="">';
            html += '</div>';
            html += '<button class="btn bg-olive btn-flat margin button-upload" data-toggle="tooltip" title="" data-loading-text="Loading..." type="button" data-original-title="Upload File"><i class="fa fa-upload"></i>Upload</button>';
            html += '<input name="banner_images[' + image_row + '][image]" class="img_hidden" id="' + image_row + '-config-value" value="" type="hidden">';

            html += '  </td>';
           
    html += '  <td class="text-right"><input required type="number" min="0" name="banner_images[' + image_row + '][sort_order]" value="" placeholder="Sort Order" class="form-control" /></td>';
    
    html += '  <td class="text-left"><button type="button" onclick="$(\'#imageBox-' + image_row + ', .tooltip\').remove();" data-toggle="tooltip" title="Remove" class="btn btn-danger"><i class="fa fa-minus-circle"></i></button></td>';
    html += '</tr>';
    $('table#bannewrImages tbody').append(html);

    image_row++;
    
    }

    $(document).on('click','.button-upload', function () {
            var _this = $(this);
            var inputValue = _this.closest("tr").find(".img_hidden");
            var iconBox = _this.closest("tr").find("img");
            $('#form-upload').remove();
            var fields = '<input required type="file" accept="image/*" name="file" />';
            $('body').prepend('<form enctype="multipart/form-data" id="form-upload" style="display: none;">' + fields + '</form>');
            $('#form-upload input[name=\'file\']').trigger('click');
            if (typeof timer != 'undefined') {
                clearInterval(timer);
            }
            timer = setInterval(function () {
                if ($('#form-upload input[name=\'file\']').val() !== '') {
                    clearInterval(timer);
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '<?php echo e(url('admin/settings/store-image-temp')); ?>',
                        type: 'post',
                        dataType: 'json',
                        data: new FormData($('#form-upload')[0]),
                        cache: false,
                        contentType: false,
                        processData: false,
                        beforeSend: function (xhr) {
                            _this.closest("tr").find(".button-upload").button('loading');
                        },
                        complete: function () {
                            _this.closest("tr").find(".button-upload").button('reset');
                        },
                        success: function (json) {
                            if (json.success === true) {
                                console.log(json.fake_path);
                                inputValue.val(json.fake_path);
                                inputValue.val(json.filename);
                                iconBox.attr('src', json.image_path);
                            } else {
                                inputValue.val('');
                                iconBox.attr('src', "<?php echo e(asset('img/no_image.gif')); ?>");
                                // wowMsg(json.message);
                            }

                        },
                        error: function (xhr, ajaxOptions, thrownError) {                
                            var message='';
                         var title=   JSON.parse(xhr.responseText).message;
                        var reserrors=   JSON.parse(xhr.responseText).errors.file;
                        reserrors.forEach(function(er){
                        message+=er+ "\r\n" ;
                        });
                          
                        $.alert({
                            title: title,
                            content:   message,
                            }); }
                    });
                }
            }, 500);
        });

  </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>