<?php $__env->startSection('title',$page->title); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main-content">
    <div class="container">
    
    <h2 class="bdr"><?php echo e($page->title); ?></h2>
    <p><?php echo e($page->short_description); ?></p>
    
    <div class="faq-box">
    <div class="accordion" id="accordionExample">
        <?php 
         $temp=1; 
        ?>
      
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php  
          $heading = 'heading'.$temp; 
          $collapse = 'collapse'.$temp; 
         
          ?>
    <div class="card">
    <div class="card-header" id="<?php echo e($heading); ?>">
    <button class="btn btn-link  <?php echo e(($temp==1)?'':'collapsed'); ?>" type="button" data-toggle="collapse" data-target="#<?php echo e($collapse); ?>" aria-expanded="<?php echo e(($temp==1)?'true':'false'); ?>" aria-controls="<?php echo e($collapse); ?>"><i>Q</i> Lorem ipsum dolor sit amet, consectetur adipiscing elit. </button>
    </div>
    <div id="<?php echo e($collapse); ?>" class="collapse <?php echo e(($temp==1)?'show':''); ?>" aria-labelledby="<?php echo e($heading); ?>" data-parent="#accordionExample">
    <div class="card-body">
    <p>Nunc finibus nulla nibh, vitae pellentesque ligula auctor in. Pellentesque est massa, ullamcorper eu lacinia in, rhoncus quis purus. Fusce quis molestie mi. Sed porta convallis urna sit amet ultrices. Praesent pretium nibh a magna scelerisque, vel ullamcorper ligula pellentesque. Donec et ullamcorper risus. Mauris pretium suscipit leo et pellentesque. Nullam at pellentesque ligula. Mauris eget ante pulvinar, cursus massa ut, scelerisque felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vitae feugiat urna.</p>
    </div>
    </div>
    </div>
    <?php     $temp++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    </div>
    
    </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>