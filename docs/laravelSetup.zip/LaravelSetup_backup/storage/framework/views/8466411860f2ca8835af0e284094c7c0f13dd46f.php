<?php $__env->startSection('title', !empty($page) ? 'Edit CMS Page' : 'Add CMS Page'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Manage CMS Pages
            <small>Here you can add cms pages</small>
        </h1>
        <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.pages.index'],['label' => !empty($page) ? 'Edit CMS Page' : 'Add CMS Page' ]]])); ?>

    </section>
    <section class="content" data-table="pages">
            <div class="row pages">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($page) ? 'Edit CMS Page' : 'Add CMS Page'); ?> </h3>
                            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                        </div><!-- /.box-header -->

                <?php if(isset($page)): ?>
                    <?php echo e(Form::model($page, ['route' => ['admin.pages.update', $page->id], 'method' => 'patch'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['route' => 'admin.pages.store'])); ?>

                <?php endif; ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">

                            <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                <label for="title">Title</label>
                                <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                <?php if($errors->has('title')): ?>
                                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group <?php echo e($errors->has('sub_title') ? 'has-error' : ''); ?>">
                                <label for="title">Sub Title</label>
                                <?php echo e(Form::text('sub_title', old('sub_title'), ['class' => 'form-control','placeholder' => 'Sub Title'])); ?>

                                <?php if($errors->has('sub_title')): ?>
                                <span class="help-block"><?php echo e($errors->first('sub_title')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group required <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                                <label for="title">Slug</label>
                                <?php echo e(Form::text('slug', old('slug'), ['class' => 'form-control','placeholder' => 'Slug'])); ?>

                                <?php if($errors->has('slug')): ?>
                                <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                                <?php endif; ?>
                              </div>


                              <div class="form-group">
                                <label for="description">Short Description</label>
                                <?php echo e(Form::textarea('short_description', old('short_description'), ['class' => 'form-control','placeholder' => 'Short Description', 'rows' => 4])); ?>

                            </div>




                        </div>

                        <div class="col-md-6">
                            <div class="form-group required <?php echo e($errors->has('meta_title') ? 'has-error' : ''); ?>">
                                <label for="title">Meta Title</label>
                                <?php echo e(Form::text('meta_title', old('meta_title'), ['class' => 'form-control','placeholder' => 'Meta Title'])); ?>

                                <?php if($errors->has('meta_title')): ?>
                                <span class="help-block"><?php echo e($errors->first('meta_title')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group required <?php echo e($errors->has('meta_keyword') ? 'has-error' : ''); ?>">
                                <label for="title">Meta Keyword</label>
                                <?php echo e(Form::text('meta_keyword', old('meta_keyword'), ['class' => 'form-control','placeholder' => 'Meta Keyword'])); ?>

                                <?php if($errors->has('meta_keyword')): ?>
                                <span class="help-block"><?php echo e($errors->first('meta_keyword')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group required <?php echo e($errors->has('meta_description') ? 'has-error' : ''); ?>">
                                <label for="description">Meta Description</label>
                                <?php echo e(Form::textarea('meta_description', old('meta_description'), ['class' => 'form-control','placeholder' => 'Meta Description', 'rows' => 8])); ?>

                                <?php if($errors->has('meta_description')): ?>
                                <span class="help-block"><?php echo e($errors->first('meta_description')); ?></span>
                                <?php endif; ?>
                            </div>

                        </div>


                    </div> <!-- /.row -->

                    <div class="row">
                        <div class="col-md-12">

                            <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <label for="description">Description</label>
                                <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Description', 'rows' => 8])); ?>

                                <?php if($errors->has('description')): ?>
                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div>


                        </div>
                    </div>



                </div><!-- /.box-body -->
                <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                        <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                    </div>
                    <?php echo e(Form::close()); ?>


                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>