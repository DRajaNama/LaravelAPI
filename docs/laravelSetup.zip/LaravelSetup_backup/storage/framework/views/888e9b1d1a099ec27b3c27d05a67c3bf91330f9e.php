<?php $__env->startSection('title','View Package Detail'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content-header">
    <h1>
        Manage Package
        <small>Here you can view package detail</small>
    </h1>
    <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'data.packages'],['label' => 'view Package detail']]])); ?>

</section>
<section class="content" data-table="emailHooks">
    <div class="listings box">
        <div class="box-header">
            <h3 class="box-title"><?php echo e($package->title); ?></h3>
            
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row"><?php echo e(__('Package Title')); ?></th>
                    <td><?php echo e($package->title); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td><?php echo e($package->created_at->format(config('get.ADMIN_DATE_TIME_FORMAT'))); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Modified')); ?></th>
                    <td><?php echo e($package->updated_at->format(config('get.ADMIN_DATE_TIME_FORMAT'))); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Status')); ?></th>
                    <td><?php echo e($package->status ? __('Active') : __('Inactive')); ?></td>
                </tr>
            </table>

        </div>





    </div>

    <div class="listings box">
        <div class="box-header">
            <h3 class="box-title">Package Prices</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <table class="table table-hover table-striped">

                    <?php $__currentLoopData = $package->package_prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                          <?php echo e($price->priceRange->title); ?>

                        </th>
                        <td>$<?php echo e($price->price); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>
        
    </div>
    <div class="listings box">
        <div class="box-header">
            <h3 class="box-title">Package Features</h3>
        </div>
        <div class="box-body">
            <div class="row">
                <table class="table table-hover table-striped">
                    <?php $__currentLoopData = $package->package_features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">
                            <?php echo (array_key_exists($feature->title,config::get('constant.package_features')))?config::get('constant.package_features')[$feature->title]:$feature->title; ?>

                        </th>
                        <td><?php echo e(($feature->value)?'Yes':'No'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>
        <div class="box-footer">
            <a href="<?php echo e(route('data.packages', app('request')->query())); ?>"
                class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i>
                Back</a>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>