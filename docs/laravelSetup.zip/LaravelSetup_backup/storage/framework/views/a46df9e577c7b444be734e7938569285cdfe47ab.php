<?php $__env->startSection('title', !empty($price_range) ? 'Edit Package' : 'Add Package'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (category header) -->
    <section class="content-header">
        <h1> 
            Manage Package
            <small>Here you can <?php echo e(!empty($price_range) ? 'edit' : 'add'); ?> Package</small>
        </h1>
        <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'data.packages'],['label' => !empty($price_range) ? 'Edit Package' : 'Add Package' ]]])); ?>

    </section>
    <section class="content" data-table="categories">
            <div class="row categories">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($price_range) ? 'Edit Package' : 'Add Package'); ?> </h3>
                            <a href="<?php echo e(url('admin/packages')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                        </div><!-- /.box-header -->

                <?php if(isset($price_range)): ?>
                    <?php echo e(Form::model($price_range, ['url' => url('admin/packages/update', $price_range->id), 'method' => 'patch'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['url' => url('admin/packages/store')])); ?>

                <?php endif; ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">

                            

                              <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                <label for="title">Title</label>
                                <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                <?php if($errors->has('title')): ?>
                                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                              </div>

                              <div class="form-group <?php echo e($errors->has('min') ? 'has-error' : ''); ?>">
                                <label for="title"> Price Ranges</label>
                                <?php $__currentLoopData = $Range; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PriceRanges): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                              </div>
                              
                              <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                                    <label class="control-label" for="last_name">Status</label>
                                            <?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>

                          </div>
                        </div>

                        


                    </div> <!-- /.row -->


                </div><!-- /.box-body -->
                <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                        <a href="<?php echo e(url('admin/packages')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                    </div>
                    <?php echo e(Form::close()); ?>


                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>