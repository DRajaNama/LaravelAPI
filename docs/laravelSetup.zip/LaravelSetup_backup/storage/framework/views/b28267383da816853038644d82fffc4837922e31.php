

<?php $__env->startSection('title','Email Hooks'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Manage Price Ranges
            <small>Here you can manage Price Range</small>
        </h1>
        <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> \Request::route()->getName()]]])); ?>

    </section>
    <section class="content" data-table="Price Range">
            <div class="row Price Range">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title"><span class="caption-subject font-green bold uppercase"><?php echo e(__('List Price Range')); ?></span></h3>
                            <div class="box-tools">
                                <a href="<?php echo e(url('admin/price-ranges/create')); ?>" class="btn btn-success btn-flat"><i class="fa fa-plus"></i> Add New Price Range
                                </a>
                            </div>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive">
                                <?php echo e(Form::open(['url' => url('admin/price-ranges'),'method' => 'get'])); ?>

                                <div class="col-md-12">
                                <div class="row">
                                   
                                    <div class="col-md-2 form-group">
                                            <?php echo e(Form::select('status', ['' => 'All',1 => 'Active', 0 => 'Inactive'], app('request')->query('status'), ['class' => 'form-control'])); ?>

                                        </div>
                                    <div class="col-md-5 form-group">
                                        <?php echo e(Form::text('keyword', app('request')->query('keyword'), ['class' => 'form-control','placeholder' => 'Keyword e.g: name, email, mobile'])); ?>

                                    </div>
                                    <div class="col-md-3 form-group">
                                        <button class="btn btn-success" title="Search" type="submit"><i class="fa fa-filter"></i> Filter</button>
                                        <a href="<?php echo e(url('admin/price-ranges')); ?>" class="btn btn-warning" title="Cancel"><i class="fa fa-fw fa-refresh"></i> Reset</a>
                                    </div>
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>

                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                       <th scope="col">Title</th>
                                        <th scope="col">Min</th>
                                        <th scope="col">Max</th>
                                        <th scope="col" width="18%">created</th>
                                        <th scope="col" class="actions" width="12%">Action</th>
                                    </tr>
                                </thead>
                               
                                        <?php if($pricerange->count() > 0): ?>
                                        <tbody>
                                    <?php
                                    $i = (($pricerange->currentPage() - 1) * ($pricerange->perPage()) + 1)
                                    ?>
                                    <?php $__currentLoopData = $pricerange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="row-<?php echo e($i); ?>">
                                            <td> <?php echo e($i); ?>. </td>
                                            
                                            <td><?php echo e($prange->title); ?></td>
                                            <td><?php echo e($prange->min); ?></td>
                                            <td><?php echo e($prange->max); ?></td>
                                            <td><?php echo e($prange->created_at->format(config('get.ADMIN_DATE_TIME_FORMAT'))); ?></td>
                                            <td class="actions">
                                                <div class="form-group">
                                                     <a href="<?php echo e(route('admin.price-ranges.show',['id' => $prange->id])); ?>" class="btn btn-warning btn-sm btn-flat" data-toggle="tooltip" alt="View setting" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a> 
                                                    <a href="<?php echo e(url('admin/price-ranges/edit/'.$prange->id)); ?>" class="btn btn-primary btn-sm btn-flat" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                    <a href="javascript:void(0);" class="confirmDeleteBtn reload btn btn-danger btn-sm btn-flat" data-toggle="tooltip" alt="Delete <?php echo e($prange->title); ?>" data-url="<?php echo e(route('admin.price-ranges.delete', $prange->id)); ?>" data-title="<?php echo e($prange->title); ?>"><i class="fa fa-trash"></i></a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                        $i++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <?php else: ?>
                                    <tfoot>
                                        <tr>
                                            <td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
                                        </tr>
                                    </tfoot>
                                    <?php endif; ?>
                            </table>
                        </div>
                        <div class="box-footer clearfix">
                            <?php echo e($pricerange->appends(Request::query())->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>