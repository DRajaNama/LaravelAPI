<?php $__env->startSection('title', !empty($package) ? 'Edit Package' : 'Add Package'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (Package header) -->
    <section class="content-header">
        <h1>
            Manage Packages
            <small>Here you can manage <?php echo e(!empty($package) ? 'edit Package' : 'add Package'); ?></small>
        </h1>
        <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'data.packages'],['label' => !empty($package) ? 'Edit Package' : 'Add Package' ]]])); ?>

    </section>
    <section class="content" data-table="Packages">

            <div class="row Packages">
                <div class="col-md-12">

                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($package) ? 'Edit Package' : 'Add Package'); ?> </h3>
                            <a href="<?php echo e(route('data.packages', app('request')->query())); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                        </div><!-- /.box-header -->
                <?php if(isset($package)): ?>
                <?php
                    $queryStr['id'] = $package->id;
                    $queryStr = array_merge( $queryStr , app('request')->query());
                ?>
                    <?php echo e(Form::model($package, ['url' => route('data.packages.update', $queryStr) , 'method' => 'patch','enctype'=>'multipart/form-data'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['url' => route('data.packages.store', app('request')->query()),'enctype'=>'multipart/form-data'])); ?>

                <?php endif; ?>
                <div class="box-body">

                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                                <li class="<?php echo e((!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>"><a href="#g_details" data-toggle="tab" aria-expanded="true">General Detail</a></li>
                                <li class="<?php echo e(!(!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>"><a href="#description_content" data-toggle="tab" aria-expanded="true">Package Price</a></li>

                        </ul>
                    <div class="tab-content">
                            <div class="tab-pane <?php echo e((!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>" id="g_details">
                            <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="title">Package Name</label>
                                                    <div class="col-md-9">
                                                        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                                        <?php if($errors->has('title')): ?>
                                                        <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                        </div>

                                       
                                        <div class="form-group  required <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                                                <div class="row">
                                                    <label class="col-md-3 control-label" for="last_name">Status</label>
                                                    <div class="col-md-9">
                                                            <?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>

                                                    </div>
                                                </div>
                                        </div>
                                        
                                    </div>


                                    <div class="col-md-6">
                            <?php $features=config::get('constant.package_features');
                            @$i=1;
                            if(!empty($package)){
                                $existingfeatures = $package->package_features->pluck('value','title')->toArray();
                            }
                            ?>
                                                                <!--right side section-->
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $value='';
                            if( !empty($package) && $existingfeatures && array_key_exists($key,$existingfeatures)){

                                $value=$existingfeatures[$key];
                            }
                            else{
                                $value=old("subscription_plan_features[$i][value]");
                            }
                            ?>
                            <div class="form-group required <?php echo e($errors->has('subscription_plan_features.'.$i.'.value') ? 'has-error' : ''); ?>">
                                    <div class="row">
                                        <label class="col-md-3 control-label" for=""><?php echo $feature; ?></label>
                                        <div class="col-md-9">
                                                <?php echo e(Form::hidden("package_features[$i][title]", $key, ['class' => 'form-control'])); ?>

                                                <?php echo Form::select("package_features[$i][value]", [1=>"Yes",0=>'No'], $value, ['class' => 'form-control']); ?>

                                                <?php if($errors->has('package_features.'.$i.'.value')): ?>
                                                    <span class="help-block"><?php echo e($errors->first('package_features.'.$i.'.value')); ?></span>
                                                    <?php endif; ?>
                                        </div>
                                    </div>
                            </div>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div> <!-- /.row -->
                            </div>


                         

                   
                    <div class="tab-pane <?php echo e(!(!empty($errors->any()) && (count($errors->keys()) == 1 )) ? "" : "active"); ?>" id="description_content">
                        <div class="row">
                            <?php
                            $priceRanges=$ranges;
                            @$i=1;
                            if(!empty($package)){
                                $existingprices = $package->package_prices->pluck('price','price_range_id')->toArray();
                            }
                            ?>
                            <?php $__currentLoopData = $priceRanges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $range): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php
                                                   $value='';
                                                   if( !empty($package) && $existingprices && array_key_exists($range->id,$existingprices)){
                       
                                                       $value=$existingprices[$range->id];
                                                   }
                                                   else{
                                                       $value=old("package_prices[$i][price]");
                                                   }
                                                   ?>
                                                   <div class="form-group required <?php echo e($errors->has('package_prices.'.$i.'.price') ? 'has-error' : ''); ?>">
                                                       <div class="row">
                                                           <label class="col-md-3 control-label" for=""><?php echo e($range->title); ?></label>
                                                           <div class="col-md-3">
                                                                   <?php echo e(Form::hidden("package_prices[$i][price_range_id]", $range->id, ['class' => 'form-control'])); ?>

                                                                   <?php echo e(Form::number("package_prices[$i][price]", $value, ['class' => 'form-control','placeholder' => 'Amount'/*,'min'=>$range->min,'max'=>$range->max*/,'min'=>0,'step' => '0.01','readonly' => !empty($package) ? false : false])); ?>

                                                                   <?php if($errors->has('package_prices.'.$i.'.value')): ?>
                                                                       <span class="help-block"><?php echo e($errors->first('package_prices.'.$i.'.price')); ?></span>
                                                                       <?php endif; ?>
                                                           </div>
                                               </div>   </div>     
                                               <?php $i++; ?>          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                </div>
                </div>
                </div><!-- /.box-body -->
                <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
                        <a href="<?php echo e(route('data.packages', app('request')->query())); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                    </div>
                    <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('per_page_style'); ?>
<link href="<?php echo e(asset('plugins/select2-develop/dist/css/select2.min.css')); ?>" rel="stylesheet" />
<style>
.ui-sortable-helper {
    display: table;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('per_page_script'); ?>
<script>


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>