<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main-content">
    <div class="container">
    <h2 class="bdr">FAQ</h2>
    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
    
    <div class="faq-box">
    <div class="accordion" id="accordionExample">
    <div class="card">
    <div class="card-header" id="headingOne">
    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><i>Q</i> Lorem ipsum dolor sit amet, consectetur adipiscing elit. </button>
    </div>
    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
    <div class="card-body">
    <p>Nunc finibus nulla nibh, vitae pellentesque ligula auctor in. Pellentesque est massa, ullamcorper eu lacinia in, rhoncus quis purus. Fusce quis molestie mi. Sed porta convallis urna sit amet ultrices. Praesent pretium nibh a magna scelerisque, vel ullamcorper ligula pellentesque. Donec et ullamcorper risus. Mauris pretium suscipit leo et pellentesque. Nullam at pellentesque ligula. Mauris eget ante pulvinar, cursus massa ut, scelerisque felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vitae feugiat urna.</p>
    </div>
    </div>
    </div>
    <div class="card">
    <div class="card-header" id="headingTwo">
    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><i>Q</i> labore et dolore magna aliqua. Ut enim ad minim veniam?</button>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
    <div class="card-body">
    <p>Nunc finibus nulla nibh, vitae pellentesque ligula auctor in. Pellentesque est massa, ullamcorper eu lacinia in, rhoncus quis purus. Fusce quis molestie mi. Sed porta convallis urna sit amet ultrices. Praesent pretium nibh a magna scelerisque, vel ullamcorper ligula pellentesque. Donec et ullamcorper risus. Mauris pretium suscipit leo et pellentesque. Nullam at pellentesque ligula. Mauris eget ante pulvinar, cursus massa ut, scelerisque felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vitae feugiat urna.</p>
    </div>
    </div>
    </div>
    <div class="card">
    <div class="card-header" id="headingthree">
    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"><i>Q</i> labore et dolore magna aliqua. Ut enim ad minim veniam?</button>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingthree" data-parent="#accordionExample">
    <div class="card-body">
    <p>Nunc finibus nulla nibh, vitae pellentesque ligula auctor in. Pellentesque est massa, ullamcorper eu lacinia in, rhoncus quis purus. Fusce quis molestie mi. Sed porta convallis urna sit amet ultrices. Praesent pretium nibh a magna scelerisque, vel ullamcorper ligula pellentesque. Donec et ullamcorper risus. Mauris pretium suscipit leo et pellentesque. Nullam at pellentesque ligula. Mauris eget ante pulvinar, cursus massa ut, scelerisque felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vitae feugiat urna.</p>
    </div>
    </div>
    </div>
    <div class="card">
    <div class="card-header" id="headingfour">
    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"><i>Q</i> labore et dolore magna aliqua. Ut enim ad minim veniam?</button>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingfour" data-parent="#accordionExample">
    <div class="card-body">
    <p>Nunc finibus nulla nibh, vitae pellentesque ligula auctor in. Pellentesque est massa, ullamcorper eu lacinia in, rhoncus quis purus. Fusce quis molestie mi. Sed porta convallis urna sit amet ultrices. Praesent pretium nibh a magna scelerisque, vel ullamcorper ligula pellentesque. Donec et ullamcorper risus. Mauris pretium suscipit leo et pellentesque. Nullam at pellentesque ligula. Mauris eget ante pulvinar, cursus massa ut, scelerisque felis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed vitae feugiat urna.</p>
    </div>
    </div>
    </div>
    </div>
    </div>
    
    </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>