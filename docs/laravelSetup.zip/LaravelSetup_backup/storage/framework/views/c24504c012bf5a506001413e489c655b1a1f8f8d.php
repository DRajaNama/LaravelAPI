<?php $__env->startSection('title'); ?> Testimonials <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage Testimonials
                <small>Here you can manage the Testimonials</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('data.testimonial')); ?>" class="active">Testimonials</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-header">
                            <h3 class="box-title"><span class="caption-subject font-green bold uppercase">List Testimonial</span></h3>
                            <div class="box-tools">
                                <a href="<?php echo e(route('data.testimonial.add')); ?>" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> New Testimonial</a>
                            </div>
                        </div><!-- /.box-header -->
                        <div class="box-body table-responsive">
                            <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th scope="col"><a href="<?php echo e(URL::route('data.testimonial',['sort' => 'heading','direction'=> request()->direction == 'asc' ? 'desc' : 'asc'])); ?>">Author</a></th>
                                    <th scope="col">Date</th>
                                    <th scope="col" class="actions" style="width: 15%;">Actions</th>
                                </tr>
                                </thead>
                                    <?php if($testimonials->count() > 0): ?>
                                    <tbody>
                                <?php
                                $i = (($testimonials->currentPage() - 1) * ($testimonials->perPage()) + 1)
                                ?>
                                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="row-<?php echo e($testimonial->id); ?>">
                                        <td> <?php echo e($i); ?>. </td>
                                        <td><?php echo e($testimonial->author); ?></td>
                                        
                                    <td>

                                        <?php echo e($testimonial->created_at); ?>

                                      
                                    </td>
                                        <td class="actions">
                                             
                                                <a href="<?php echo e(url('admin/testimonials/view/'.$testimonial->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" alt="View Testimonials" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;
                                                <a href="<?php echo e(url('admin/testimonials/edit/'.$testimonial->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
                                                &nbsp;&nbsp;
                                                  

                                                  <a href="javascript:void(0);" class="confirmDeleteBtn btn btn-danger btn-sm btn-flat" data-toggle="tooltip" alt="Testimonial" data-url="<?php echo e(route('data.testimonial.delete', $testimonial->id)); ?>" data-title="Testimonial"><i class="fa fa-trash"></i></a>
                                             
                                        </td>
                                    </tr>
                                <?php
                                    $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <?php else: ?>
                                <tfoot>
                                    <tr>
                                        <td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
                                    </tr>
                                </tfoot>
                                <?php endif; ?>
                            </table>
                        </div>
                        <div class="box-footer clearfix">
                            <?php echo e($testimonials->appends(Request::query())->links()); ?>

                         </div>
                    </div>
                </div>
                
            </div>
        </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>