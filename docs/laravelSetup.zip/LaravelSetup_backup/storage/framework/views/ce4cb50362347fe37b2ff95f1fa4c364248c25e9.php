<?php $__env->startSection('title', !empty($emailTemplate) ? 'Edit Email Template' : 'Add Email Template'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content-header">
    <h1>
            Manage Email Preference
        <small>Here you can <?php echo e(!empty($emailTemplate) ? 'edit' : 'add'); ?> email preferences(layout)</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route("admin.dashboard")); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(route('admin.email-templates.index')); ?>"><?php echo e(__("Email Template")); ?></a></li>
        <li><a href="javascript:void(0)" class="active"><?php echo e(!empty($emailTemplate) ? 'Edit Email Template' : 'Add Email Template'); ?></a></li>
    </ol>
</section>
<section class="content" data-table="emailTemplates">
    <div class="row">
        <div class="col-md-7">
            <div class="box box-info emailTemplates">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e(!empty($emailTemplate) ? 'Edit Email Template' : 'Add Email Template'); ?> </h3>
                    <a href="<?php echo e(route('admin.email-templates.index')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                </div><!-- /.box-header -->
                <?php if(isset($emailTemplate)): ?>
                    <?php echo e(Form::model($emailTemplate, ['route' => ['admin.email-templates.update', $emailTemplate->id], 'method' => 'patch'])); ?>

                <?php else: ?>
                    <?php echo e(Form::open(['route' => 'admin.email-templates.store'])); ?>

                <?php endif; ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group required <?php echo e($errors->has('email_hook_id') ? 'has-error' : ''); ?>">
                                <label for="title">Email Hook</label>
                                <?php echo e(Form::select('email_hook_id', $hooks, null , ['class' => 'form-control', 'placeholder' => 'Select Email Hook'])); ?>

                                <?php if($errors->has('email_hook_id')): ?>
                                <span class="help-block"><?php echo e($errors->first('email_hook_id')); ?></span>
                                <?php endif; ?>
                              </div>  
                              
                            <div class="form-group required <?php echo e($errors->has('subject') ? 'has-error' : ''); ?>">
                                <label for="title">Subject</label>
                                <?php echo e(Form::text('subject', old('subject'), ['class' => 'form-control','placeholder' => 'Subject'])); ?>

                                <?php if($errors->has('subject')): ?>
                                <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                              </div>    

                              
                            <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <label for="description">Description (Email Content)</label>
                                <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Description', 'rows' => 8])); ?>

                                <?php if($errors->has('description')): ?>
                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div> 
                            
                            <div class="form-group">
                                <label for="description">Footer Text</label>
                                <?php echo e(Form::textarea('footer_text', old('footer_text'), ['class' => 'form-control','placeholder' => 'Footer Text', 'rows' => 8])); ?>

                            </div> 


                            <div class="form-group required <?php echo e($errors->has('email_preference_id') ? 'has-error' : ''); ?>">
                                <label for="title">Email Layout</label>
                                <?php echo e(Form::select('email_preference_id', $emailPreference, null , ['class' => 'form-control', 'placeholder' => 'Select Layout'])); ?>

                                <?php if($errors->has('email_preference_id')): ?>
                                <span class="help-block"><?php echo e($errors->first('email_preference_id')); ?></span>
                                <?php endif; ?>
                              </div> 

                              <div class="form-group">
                                <label for="status">Status</label> 
                                <?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>

                            </div>


                        </div>
                    </div> <!-- /.row -->
                </div><!-- /.box-body -->
                <div class="box-footer">
                        <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>  
                        <a href="<?php echo e(route('admin.email-templates.index')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>                
                    </div>
                    <?php echo e(Form::close()); ?>

            </div>
        </div>
        <div class="col-md-5">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">
                        <i class="fa fa-exclamation"></i> Important Rules
                    </h3>

                </div><!-- /.box-header -->
                <div class="box-body">
                <p>For each email hook that would be added to the sytem, make sure to follow these rules:</p>
                <ul>
                    <li>
                        Use <small class="label bg-yellow">##SYSTEM_APPLICATION_NAME##</small> 
                        on the subject or message to print application name defined by admin settings.
                    </li>
                    <li>
                        Use <small class="label bg-yellow">##USER_EMAIL##</small> 
                        on the subject or message to print user email.
                    </li>
                    <li>
                        Use <small class="label bg-yellow">##USER_NAME##</small> 
                        on the subject or message to print user name.
                    </li>
                    <li>Make sure the message contain <small class="label bg-yellow">##MESSAGE##</small>.</li>
                </ul>
            </div>
            </div>


            <?php if(!$emailTemplateLists->isEmpty()): ?>
            <div class="box box-default">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-anchor"></i> Last updated templates</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <!-- form start -->
                       
                            <ul class="timeline">
                                <!-- timeline time label -->
                                <?php $__currentLoopData = $emailTemplateLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailTemplate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="time-label">
                                            <span class="bg-navy">
                                                <?php echo e($emailTemplate->created_at->toFormattedDateString()); ?>

                                            </span>
                                        </li>
                                        <!-- /.timeline-label -->
                                        <!-- timeline item -->
                                        <li>
                                            <i class="fa fa-anchor bg-blue"></i>
                                            <div class="timeline-item">
                                                <span class="time"><i class="fa fa-clock-o"></i> <?php echo e($emailTemplate->created_at->format('H:i A')); ?></span>
    
                                                <h3 class="timeline-header">
                                                   <a href="<?php echo e(route('admin.hooks')); ?>/<?php echo e($emailTemplate->email_hook->id); ?>"> <?php echo e($emailTemplate->email_hook->title); ?> (<?php echo e($emailTemplate->email_hook->slug); ?>) </a>
                                                </h3>
                                                <div class="timeline-body">
                                                    <h3 style="margin-top: 0px;"> <small>
                                                            <a href="<?php echo e(route('admin.email-preferences.show', ['id' => $emailTemplate->email_preference->id])); ?>"><?php echo e($emailTemplate->email_preference->title); ?></a>
                                                        </small>
                                                    </h3>
                                                    <?php echo e($emailTemplate->subject); ?>

                                                </div>
                                                <div class="timeline-footer form-inline">
                                                    <a href="<?php echo e(route('admin.email-templates.show', ['id' => $emailTemplate->id])); ?>" class="btn btn-default btn-xs"><i class="fa fa-eye" data-toggle="tooltip" data-placement="left" data-title="View" data-original-title="" title=""></i></a>                                                
                                                    <a href="<?php echo e(route('admin.email-templates.edit', ['id' => $emailTemplate->id])); ?>" class="btn btn-primary btn-xs btn-flat"><i class="fa fa-pencil-square-o" data-toggle="tooltip" data-placement="right" data-title="Edit" data-original-title="Edit" title=""></i></a>                      
                                                </div>
                                            </div>
                                        </li>
                                    <!-- END timeline item -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                                <li>
                                    <i class="fa fa-clock-o bg-gray"></i>
                                </li>
                            </ul>
                           
                    </div>

            </div>
            <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>