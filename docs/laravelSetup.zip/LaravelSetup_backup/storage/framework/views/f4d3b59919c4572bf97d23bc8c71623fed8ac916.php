<?php $__env->startSection('title', !empty($service) ? 'Edit Services' : 'Add Services'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<style type="text/css">
    input[type=file]{
      display: inline;
    }

    #baanner_preview{
      border: 1px solid black;
      padding: 10px;
    }

    #baanner_preview img{
      width: 200px;
      padding: 5px;
    }
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
       <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Manage Services
                <small>Here you can <?php echo e(!empty($service) ? 'edit' : 'add'); ?> Services constant/Slug</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('data.service')); ?>"><?php echo e(__("Service")); ?></a></li>
                <li><a href="javascript:void(0)" class="active"><?php echo e(!empty($service) ? 'Edit Services' : 'Add Services'); ?></a></li>
            </ol>
        </section>
        <section class="content" data-table="settings">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info settings">

                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e(!empty($service) ? 'Edit Services' : 'Add Services'); ?></h3>
                            <a href="<?php echo e(route('data.service')); ?>" class="btn btn-default pull-right" title="Cancel"><i
                                        class="fa fa-fw fa-chevron-circle-left"></i> Back</a></div>
                        <!-- /.box-header -->
                        <?php if(isset($service)): ?>
                            <?php echo e(Form::model($service, ['route' => ['data.service.update', $service->id], 'method' => 'post', 'enctype' => 'multipart/form-data'])); ?>

                        <?php else: ?>
                         <?php echo e(Form::open(['route' => 'data.service.store', 'enctype' => 'multipart/form-data'])); ?>

                        <?php endif; ?>
                            <div style="display:none;">
                            </div>
                            <div class="box-body">
                                <div class="row">
                                        <?php echo e(Form::hidden('manager', 'general')); ?>

                                    <div class="col-md-12">
                                        <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                            <label for="title">Title</label>
                                            <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                            <?php if($errors->has('title')): ?>
                                            <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
                                                <label for="slug">Constant/Slug</label>
                                                <?php echo e(Form::text('slug', old('slug'), ['class' => 'form-control','placeholder' => 'Constant/Slug' ,'readonly' => isset($service) ? true : false])); ?>

                                                <?php if($errors->has('slug')): ?>
                                                <span class="help-block"><?php echo e($errors->first('slug')); ?></span>
                                                <?php else: ?>
                                                <p class="help-block">No space, separate each word with underscore. (if you want auto generated then please leave blank)</p>
                                                <?php endif; ?>
                                            </div>
                                        <div class="form-group hide">
                                            <div class="input select required">
                                                <label for="field-type">Field Type</label>
                                                <select name="field_type" class="form-control" placeholder="Field Type" required="required" id="field-type">
                                                    <option value="text">Text</option>
                                                    <option value="checkbox">Yes/No</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>" style="">
                                            <div class="input textarea">
                                                <label for="category_textarea">Description</label>
                                                <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Provide Description', 'rows' => 5])); ?>

                                                <?php if($errors->has('description')): ?>
                                                <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>


                                         <!-- <div class="form-group required <?php echo e($errors->has('banner') ? 'has-error' : ''); ?>" style="">
                                            

                                            <div id="banner_preview">

                                            <?php if(isset($settings)): ?>
                                             <img src="<?php echo e(asset('cargo-banner/'.$settings->banner)); ?>" style="width: 400px;">
                                            <?php endif; ?>
                                               </div>

                                            <br/>


                                            <div class="input textarea">
                                                <label for="banner_file">Upload Banner</label>
                                                <input type="file" id="banner" name="banner"/>
                                                <?php if($errors->has('description')): ?>
                                                <span class="help-block"><?php echo e($errors->first('banner')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div> -->

                                        
                                    </div>
                                </div><!-- /.row -->
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <button class="btn btn-primary btn-flat" title="Submit" type="submit"><i
                                            class="fa fa-fw fa-save"></i> Submit
                                </button>
                                <a href="<?php echo e(route('data.service')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>

<script type="text/javascript">
  jQuery("#banner").change(function(){
     jQuery('#banner_preview').html("");
     var total_file=document.getElementById("banner").files.length;
     for(var i=0;i<total_file;i++)
     {
      jQuery('#banner_preview').append("<img src='"+URL.createObjectURL(event.target.files[i])+"' style='width: 400px'>");
     }
  });
</script>            

</div>
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>