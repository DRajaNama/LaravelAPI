<?php $__env->startSection('title','View Email Hook'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content-header">
        <h1>
                Manage Email Templates 
                <small>Here you can manage the email templates</small>
            </h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route("admin.dashboard")); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(route('admin.email-templates.index')); ?>">Email Templates</a></li>
        <li><a href="javascript:void(0)" class="active">View Email Templates Detail</a></li>
    </ol>
</section>

<section class="content" data-table="emailTemplates">
    <div class="box">
        <div class="box-header"><h3 class="box-title"><?php echo e($emailTemplate->title); ?></h3>
            <a href="<?php echo e(route('admin.email-templates.index')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
        <div class="box-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row"><?php echo e(__('Hook/Slug')); ?></th>
                    <td><?php echo e($emailTemplate->email_hook->title); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Subject')); ?></th>
                    <td><?php echo e($message['subject']); ?></td>
                </tr>
                <tr>
                        <th scope="row"><?php echo e(__('Status')); ?></th>
                        <td><?php echo e($emailTemplate->status == 1 ? "Active" : "Inactive"); ?></td>
                    </tr>
               <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td><?php echo e($emailTemplate->created_at->toFormattedDateString()); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Modified')); ?></th>
                    <td><?php echo e($emailTemplate->updated_at->toFormattedDateString()); ?></td>
                </tr>
               
            </table>
            <div class="row">
                <div class="col-md-12">
                    <h4><?php echo e(__('Email Template Layout')); ?></h4>
                    <?php echo $message['message']; ?>

                </div>
            </div>
        </div>
        <div class="box-footer">
                <a href="<?php echo e(route('admin.email-templates.index')); ?>" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>