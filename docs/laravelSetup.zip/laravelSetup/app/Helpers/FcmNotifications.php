<?php
namespace App\Helpers;

use Illuminate\Support\Facades\DB;

class FcmNotifications{

    public static function pushNotificationToDevice($deviceId = null, $device_type = null, $notiftyMsg = null, $navigation_id = null, $title = 'default') { 
        ob_start();
        if (!empty($deviceId)) {

            $device_type = strtolower($device_type);
            if ($device_type == 'ios') {
                $sound = 'default';


                $msg = array
                    (
                    'body' => $notiftyMsg,
                    'title' => $title,
                    'content_available' => true,
                    'message' => $notiftyMsg,
                    'icon' => 'ic_launcher',
                    'sound' => $sound,
                    'type' => $title,
                    'id' => $navigation_id,
                );

                $fields = array
                    (
                    'to' => $deviceId,
                    'notification' => $msg,
                    'data' => $msg,
                    'priority' => 'high',
                    'time_to_live' => 30
                );
            } else { //this for andriond
                $formdata['message'] = $notiftyMsg;
                $formdata['type'] = $title;
                $formdata['id'] = $navigation_id;
                $msg = array
                    (
                    'body' => $formdata,
                    'title' => $title,
                    'icon' => 'ic_launcher',
                    'vibrate' => 1,
                    'sound' => 1, //'default'
                    //   'badge' => isset($device_badge['badge_count']) ? $device_badge['badge_count'] + 1 : 1,
                  //  'image' => $user_image,
                );

                $fields = array
                    (
                    'to' => $deviceId,
                    //'notification' => $msg,
                    'data' => $msg,
                    'priority' => 'high',
                    'time_to_live' => 30
                );
            }


            $url = 'https://fcm.googleapis.com/fcm/send'; //'https://www.googleapis.com';
            $headers = array(
                'Authorization:key=AAAAWfghJsA:APA91bELpiqpYONt040K9ToBnCQQ4pZBaQ8XfTeIHqTcyAUynpdfIBndDe7akgFgM9jbU7-s5YGxZs-pTTmoJi0-k5UvXd6GSTN2fTDa3unQy8x-eRXQN9TtLk40tFtEGLdKCh7Iq0zJ',  
                'Content-Type: application/json'
            );

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($ch);
            $results = json_decode($result);

            $status = 1;
            if ($result === FALSE) {
                die('FCM Send Error: ' . curl_error($ch));
            }
            
            // exit;
            curl_close($ch);
            return $status;
            //ob_flush();
        } else {
            return false;
        }
        //ob_flush();
    }

}