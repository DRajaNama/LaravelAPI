<?php
namespace App\Helpers;

use Illuminate\Support\Facades\DB;

class MenuHelpers
{
    /**
     * getStingWithEmoji
     * @return String
     */

    public static function imageUrl($path, $width = null, $height = null, $quality = null, $crop = null)
    {

        if (!$width && !$height) {
            $url = env('IMAGE_URL') . $path;
        } else {
            $url = url('/') . '/timthumb.php?src=' . env('IMAGE_URL') . $path;
            if (isset($width)) {
                $url .= '&w=' . $width;
            }
            if (isset($height) && $height > 0) {
                $url .= '&h=' . $height;
            }
            if (isset($crop)) {
                $url .= "&zc=" . $crop;
            } else {
                $url .= "&zc=1";
            }
            if (isset($quality)) {
                $url .= '&q=' . $quality . '&s=1';
            } else {
                $url .= '&q=95&s=1';
            }
        }

        return $url;
    }
    /* get product type */
    public static function getProductType($category_id)
    {
        $productGroup = $productType = '';
        if (!empty($category_id)) {
            $category = DB::table('categories')->get()->where('status', 1)->where('id', $category_id)->first();
            if (!empty($category->parent_id)) {
                $productType = $category->title;
                $parent_cat = DB::table('categories')->get()->where('status', 1)->where('id', $category->parent_id)->first();
                $productGroup = $parent_cat->title;

            } else {
                $productGroup = $category->title;
            }

        }
        return ['product_group' => $productGroup, 'product_type' => $productType];
    }

    public static function getSupplierMainProducts($supplier)
    {
        $productGroupList = array();
        foreach ($supplier->products as $product) {
            $catArrray = MenuHelpers::getProductType($product->category_id);
            if (!in_array($catArrray['product_group'], $productGroupList)) {
                $productGroupList[] = $catArrray['product_group'];
            }
        }
        return implode(',', $productGroupList);
    }

    public static function getUnreadMessageCount($user_id)
    {
        $messageThreads = DB::table('messages')->where('receiver_id', $user_id)->where('is_new', 1)->orderBy('created_at', 'desc')->get()->groupBy('message_group');
        return count($messageThreads);
    }
}
