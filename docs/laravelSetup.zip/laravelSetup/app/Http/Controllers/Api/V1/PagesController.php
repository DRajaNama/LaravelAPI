<?php

namespace App\Http\Controllers\API\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\ApiGlobalFunctions;
use DB; 
class PagesController extends Controller
{
	use ApiGlobalFunctions;
	
    public function index($slug) {
		$page = DB::table('pages')->where('slug',$slug)->first();     
		if (!empty($page)) {
			return $this->sendResponse($page, $this->messageDefault('list_found'));
		} else {
			return $this->sendError($this->messageDefault('record_found'), '', '200');
		}
    }
}
