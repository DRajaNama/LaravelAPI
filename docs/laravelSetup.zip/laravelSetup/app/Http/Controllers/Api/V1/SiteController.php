<?php

namespace App\Http\Controllers\Api\v1;

use App\Models\Sites;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\ApiGlobalFunctions;
use DB;

class SiteController extends Controller {

    use ApiGlobalFunctions;

    public function getSites(Request $request) {
		 $user = $request->get('Auth');
        if ($user->id) {
            $getDeatils = Sites::select(['id', 'title', 'address', 'status', 'created_at', 'updated_at'])->where('status',"1")->get();
            if (!empty($getDeatils)) {
                return $this->sendResponse($getDeatils, $this->messageDefault('list_found'));
            } else {
                return $this->sendError($this->messageDefault('record_found'), '', '200');
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_request'), '', '200');
        }
    }


}
