<?php

namespace App\Http\Controllers\API\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Tickets;
use App\Models\TicketImages;
use App\Traits\ApiGlobalFunctions;
use Illuminate\Support\Facades\Storage;
use Validator;
use DB;
use PDF;


class TicketController extends Controller
{
    //
	use ApiGlobalFunctions;
	 
	public function index(Request $request) {
		 $user = $request->get('Auth');
        if ($user->id) {
				$query = Tickets::query();
                $ticket_data = $query->select(['id', 'user_id', 'vehical_no', 'model','color','make','site_id', 'description', 'pdf_file', 'created_at', 'updated_at', 'status'])->with(['user:id,first_name,last_name','sites:id,title,address','images'])->where('user_id',$user->id)->get();
			if (!empty($ticket_data)) {
                return $this->sendResponse($ticket_data, $this->messageDefault('list_found'));
            } else {
                return $this->sendError($this->messageDefault('record_found'), '', '200');
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_request'), '', '200');
        }
    }
	
	public function createTicket(Request $request) {
		 $user = $request->get('Auth');
		 if ($user->id) {
           
		   $validator = Validator::make($request->all(), [
                        'vehical_no' => 'required',
                        'model' => 'required',
                        'color' => 'required',
                        'make' => 'required',
                        'site_id' => 'required',
                        'description' => 'required',
						'image' => 'required',
						'image.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
                            ], [
                        'vehical_no.required' => 'Please provide vehical number.',
                        'model.required' => 'Please provide model.',
                        'color.required' => 'Please provide color.',
                        'make.required' => 'Please provide make.',
                        'site_id.required' => 'Please select specified site location.',
                        'description.required' => 'Please provide the ticket description in detail.',
                        'image.required' => 'Please provide the ticket images of current situation.',
            ]);
			
            if ($validator->fails()) {
                return $this->sendError('Validation Error.', $validator->errors()->first(), '200');
            }
			
			
			$ticket 				= new Tickets(); 
			$ticket->user_id		= $user->id;
            $ticket->vehical_no 	= $request->vehical_no;
            $ticket->model		 	= $request->model;
            $ticket->color		 	= $request->color;
            $ticket->make		 	= $request->make;
            $ticket->site_id 		= $request->site_id;
            $ticket->description 	= $request->description;
			$ticket->status  		= '1';
			$ticket->save();
			
			if($request->hasfile('image'))
			{
				foreach($request->file('image') as $image)
				{
					$destinationPath = public_path('uploads/tickets');
					$file_name = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME);
					$file_name = str_replace(' ', '-', $file_name);
					$filename  = $file_name . '-' . time() . '.' . $image->getClientOriginalExtension();
					$image->move($destinationPath, $filename);
					
					$ticket_image 				= new TicketImages();
					$ticket_image->user_id  	= $user->id;
					$ticket_image->ticket_id  	= $ticket->id;
					$ticket_image->image_title  = $file_name;
					$ticket_image->image  		= $filename;
					$ticket_image->status  		= '1';
					$ticket_image->save();
				}
			}
			
			/* create Invoice PDF */ 
			$pdf_name = 'ticket'.time().'_'.$ticket->id.'.pdf';
			$path = public_path('uploads/pdf/');
			$pdf = PDF::loadView('pages/pdf', compact('ticket'));
			$pdf->save($path . '/' . $pdf_name);
			
			
			 $ticket = Tickets::find($ticket->id);
			 $ticket->pdf_file = $pdf_name;
			 $ticket->save(); 
			
            if (!empty($ticket->id)) {
				 // $query = Tickets::query();
                // $ticket_data = $query->select(['id', 'user_id', 'vehical_no', 'model','color','make','site_id', 'description', 'pdf_file', 'created_at', 'updated_at', 'status'])->where('id', $ticket->id)->first();
				
                return $this->sendResponse([], $this->messageDefault('save_records'));
            } else {
                return $this->sendError($this->messageDefault('save_failed'), '', '200');
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_request'), '', '200');
        }
    }
	
	 
	public function getTicket(Request $request,$id) {
		$user = $request->get('Auth');
        if ($user->id) {
				$query = Tickets::query();
                $ticket_data = $query->select(['id', 'user_id', 'vehical_no', 'model','color','make','site_id', 'description', 'pdf_file', 'created_at', 'updated_at', 'status'])->with(['user:id,first_name,last_name','sites:id,title,address','images'])->where('user_id',$user->id)->where('id',$id)->first();
			if (!empty($ticket_data)) {
                return $this->sendResponse($ticket_data, $this->messageDefault('list_found'));
            } else {
                return $this->sendError($this->messageDefault('record_found'), '', '200');
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_request'), '', '200');
        }
    }
	
}
