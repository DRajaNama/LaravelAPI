<?php

namespace App\Http\Controllers\Api\v1;

use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\ForgotPasswordRequest;
use App\Http\Requests\Api\PasswordRequest;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Collections\UserCollection;
use Illuminate\Support\Str;
use App\Traits\ApiGlobalFunctions;
use DB;
use Validator;
use App\Mail\VerifyUserMail;
use App\Mail\EnquiryMail;
use App\Mail\NewPasswordMail;
use App\Models\VerifyUser;

class UserController extends Controller {

    use ApiGlobalFunctions;

    /**
     * Login api
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request) {

        $data = [];
        if (Auth::attempt(['email' => request('email'), 'password' => request('password')])) {

            $user = Auth::user();
            if (!$user->status) {
                return $this->sendError($this->messageDefault('not_activated'), '', '200');
            } elseif (!$user->is_verified) {

                return $this->sendError($this->messageDefault('not_verified'), '', '200');
            } else {
                $input = $request->all();
                $data = $user;
                $data['device_id'] = isset($input['device_id']) ? $input['device_id'] : $data['device_id'];
                $data['device_type'] = isset($input['device_type']) ? $input['device_type'] : $data['device_type'];
                $data['api_token'] = $user->createToken('Maxminpower')->accessToken;

                DB::table('users')
                        ->where('id', $user->id)
                        ->update(['api_token' => $data['api_token'], 'device_id' => $data['device_id'], 'device_type' => $data['device_type']]);

                $query = User::query();
                $udata = $query->select(['id', 'first_name', 'last_name', 'email', 'phone', 'photo', 'created_at', 'updated_at', 'api_token', 'status', 'is_verified', 'is_notifiable', 'is_download_offline', 'device_type', 'device_id', 'gender'])->where('id', $user->id)->first();

                return $this->sendResponse($udata, $this->messageDefault('login_success'));
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_login'), '', '200');
        }
    }

    /**
     * Register api
     *
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request) {

        $input = $request->all();

        try {
            $user = new User();
            $validator = Validator::make($request->all(), [
                        'email' => 'required|email|unique:users',
                        'password' => 'required|min:6',
                        'first_name' => 'required',
                            ], [
                        'first_name.required' => 'Please provide your first name.',
                        'email.required' => 'Please provide your email address.',
                        'email.unique' => 'This email address is already registered. Please try with different one.',
                        'password.required' => 'Please provide your password.',
                        'password.min' => 'Password length should be more than 6 character.',
            ]);
            if ($validator->fails()) {
                return $this->sendError('Validation Error.', $validator->errors()->first(), '200');
            }

            $user->email = $input['email'];
            $user->first_name = $input['first_name'];
            $user->phone = isset($input['mobile']) ? $input['mobile'] : "";
            $user->device_id = "";
            $user->device_type = "";
            $user->password = bcrypt($input['password']);
            $user->verification_code = str_random(8);

            $user->save();
            if ($user) {
                $query = User::query();
                $udata = $query->select(['id', 'phone', 'first_name', 'last_name','email', 'created_at', 'updated_at', 'status', 'is_verified', 'is_notifiable', 'is_download_offline', 'device_type', 'device_id', 'gender'])->where('id', $user->id)->first();

                \Mail::to($udata->email)->send(new VerifyUserMail($udata));

                return $this->sendResponse($udata, $this->messageDefault('signup_success'));
            } else {
                return $this->sendError($this->messageDefault('signup_error'), '', '200');
            }
        } catch (\Exception $e) {

            return $this->sendError($this->messageDefault('oops'), '', '200');
        }
    }

    public function logout(Request $request) {
        $user = $request->get('Auth');

        $input = $request->all();
        $result = DB::table('users')
                ->where('id', $user->id)
                ->update(['api_token' => '', 'device_type' => '', 'device_id' => '']);
        if ($result) {
            $data = (object) [];
            return $this->sendResponse($data, $this->messageDefault('logout_success'));
        } else {
            return $this->sendError($this->messageDefault('process_failed'));
        }
    }

    public function forgotPassword(ForgotPasswordRequest $request) {
        $input = $request->all();
        try {
            $query = User::where('email', $request->email);
            if ($query->exists()) {
                $user = $query->first();
                // Check if user is active
                if (!$user->status) {
                    return $this->sendError($this->messageDefault('not_activated'), '', '200');
                } elseif (!$user->is_verified) {

                    return $this->sendError($this->messageDefault('not_verified'), '', '200');
                }
                // Create password reset token

                $random_password = str_random(6);
                $password = bcrypt($random_password);
                $result = DB::table('users')
                        ->where('id', $user->id)
                        ->update(['password' => $password]);
                // Send password reset email to user 
                \Mail::to($user->email)->send(new NewPasswordMail($user, $random_password));

                $data = (object) [];
                return $this->sendResponse($data, $this->messageDefault('forgot_app_success'));
            } else {
                return $this->sendError($this->messageDefault('not_register_email'), '', '200');
            }
        } catch (\Exception $e) {
            //return $this->sendError($e); 
            return $this->sendError($this->messageDefault('oops'), '', '200');
        }
    }

    public function changePassword(Request $request) {
		$input = $request->all();
        $user = $request->get('Auth');
        $validator = Validator::make($request->all(), [
                    'old_password' => 'required',
                    'new_password' => 'required|min:6',
                        ], [
                    'old_password.required' => 'Please provide your old password.',
                    'new_password.required' => 'Please provide your new password.',
                    'new_password.min' => 'Password length should be more than 6 character.',
        ]);
        if ($validator->fails()) {
            return $this->sendError('Validation Error.', $validator->errors()->first(), '200');
        }
        try {

            $user = User::find($user->id);
            $old_password = $user->password;
            $user->password = bcrypt($request->new_password);
            $data = (object) [];
            if (strcmp($request->old_password, $request->new_password) == 0) {
                return $this->sendError($this->messageDefault('New password cannot be same as your old password'));
            } elseif (!Hash::check($request->old_password, $old_password)) {
                return $this->sendError($this->messageDefault('The old password is incorrect.'));
            } elseif ($user->save()) {

                return $this->sendResponse($data, $this->messageDefault('change_password_success'));
            } else {
                return $this->sendError($this->messageDefault('process_failed'));
            }
        } catch (\Exception $e) {
            return $this->sendError($this->messageDefault('oops'));
        }
    }

    public function profileDetails(Request $request) {
		$input = $request->all();
        $user = $request->get('Auth');
        if ($user->id) {
            $query = User::query();
            $userDeatils = $query->select(['id', 'first_name','last_name', 'email', 'photo', 'phone', 'created_at', 'updated_at', 'api_token', 'status', 'is_verified', 'is_notifiable', 'is_download_offline', 'device_type', 'device_id', 'gender'])->where('id', $user->id)->first();
            if (!empty($userDeatils)) {
                return $this->sendResponse($userDeatils, $this->messageDefault('profile_get'));
            } else {
                return $this->sendError($this->messageDefault('record_found'), '', '200');
            }
        } else {
            return $this->sendError($this->messageDefault('invalid_request'), '', '200');
        }
    }

    public function editProfile(Request $request) {
        $input = $request->all();
        $user = $request->get('Auth');
        try {
            $validator = Validator::make($request->all(), [
                        'first_name' => 'required',
                        'last_name' => 'required',
                        'mobile' => 'nullable|numeric|digits_between:10,16',
            ]);
            if ($validator->fails()) {
                return $this->sendError('Validation Error.', $validator->errors()->first(), '200');
            }

            if (isset($_FILES['profile_photo']['name']) && $_FILES['profile_photo']['name'] != '') {

                $profile_photo = time() . '.' . request()->profile_photo->getClientOriginalExtension();
                request()->profile_photo->move(public_path('uploads/users/'), $profile_photo);
                $input['photo'] = $profile_photo;
                $input['profile_photo_full_path'] = asset('uploads/users/' . $profile_photo);
            } else {
                $input['photo'] = $user->photo;
                $input['profile_photo_full_path'] = !empty($user->photo) ? asset('uploads/users/' . $user->photo) : "";
            }
            if(isset($request->mobile)){
				$input['mobile'] = (string) $input['mobile'];
			}else{
				$input['mobile'] = (string) $user->phone;
			}
			$input['photo'] = (string) $input['photo'];
            DB::table('users')
                    ->where('id', $user->id)
                    ->update([
                        'first_name' => $input['first_name'],
                        'last_name' => $input['last_name'],
                        'photo' => $input['photo'],
                        'phone' => $input['mobile'],
            ]);

            $query = User::query();
            $udata = $query->select(['id', 'first_name', 'last_name','email', 'photo', 'phone', 'created_at', 'updated_at', 'api_token', 'status', 'is_verified', 'is_notifiable', 'is_download_offline', 'device_type', 'device_id', 'gender'])->where('id', $user->id)->first();

            return $this->sendResponse($udata, $this->messageDefault('profile_edit'));
        } catch (\Exception $e) {
            //return $this->sendError($e);
            return $this->sendError($this->messageDefault('oops'), '', '200');
        }
    }

    public function setting(Request $request) {

        $input = $request->all();
        $user = $request->get('Auth');

        try {

            $user = User::find($user->id);
            if (isset($input['is_notifiable']))
                $user->is_notifiable = $input['is_notifiable'];

            if (isset($input['is_download_offline']))
                $user->is_download_offline = $input['is_download_offline'];

            if ($user->save()) {
                $data = (object) [];
                return $this->sendResponse($data, "Profile setting updated successfully");
            } else {
                return $this->sendError($this->messageDefault('process_failed'));
            }
        } catch (\Exception $e) {

            return $this->sendError($this->messageDefault('oops'));
        }
    }


}
