<?php

namespace App\Http\Controllers;

use App\Models\User;
use DB;

class UserController extends AppBaseController {

    /**
     * function to render cms page based on slug
     * @param int slug 
     * return redirect respose  
     */
    public function verifyaccount($token) {
        $data['title'] = "Email Verification";
        try {
            $query = User::query();
            $user = $query->where("verification_code", $token)->first();

            if ($user) {

                if (!$user->is_verified) {
                    // update user
                    $user->verification_code = "";
                    $user->is_verified = 1;
                    $user->updated_at = date('Y-m-d H:i:s');
                    $user->save();


                    $data['status'] = "Verified";
                    $data['message'] = "Your account has been verified successfully";
                    return view('home.verify', compact('data'));
                } else {
                    $data['status'] = "Already Verified";
                    $data['message'] = "Your account has already verified successfully";
                    return view('home.verify', compact('data'));
                }
            } else {
                $data['status'] = "Invalid Access";
                $data['message'] = "Something went wrong";
                return view('home.verify', compact('data'));
            }
        } catch (\Exception $e) {
         //   dd($e);
            $data['status'] = "Invalid Access";
            $data['message'] = "Something went wrong";
            return view('home.verify', compact('data'));
        }
    }

}
