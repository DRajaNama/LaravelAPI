<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = \Auth::guard('user')->user();
        $rules =  [
            'first_name'            =>'bail|required|max:50',
            'last_name'             =>'bail|required|max:50',
            'phone'                 =>'bail|required|numeric|digits_between:4,16|unique:users,phone,'.$user->id.',id',
            'company_name'          =>'bail|required|max:100',
            'address'               =>'bail|required|string|max:150'
        ];

        if($this->hasFile('avatar')){
            $rules['avatar'] = 'bail|nullable|image';
        }
        
        return $rules;
    }

    /**
     * Configure the validator instance.
     *
     * @param \Illuminate\Validation\Validator $validator
     *
     * @return void
     */
    public function withValidator($validator)
    {
        $validator->after(function ($validator) {
            if($this->hasFile('avatar')){
                if ($this->file('avatar')->getClientSize() > '5242880') {
                    $validator->errors()->add('avatar', 'Profile picture shouldn\'t be greater than 5 MB. Please select another file.');
                }
            }
        });
    }
    /**
     * Get the validation messages that apply to the request.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'avatar.image'=>'The profile picture must be an image. '
        ];
    }

}
