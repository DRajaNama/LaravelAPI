<?php

namespace App\Mail;

use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use App\Models\EmailTemplate;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class EnquiryMail extends Mailable implements ShouldQueue {

      use Queueable,
        SerializesModels;

    /**
     * The enquiry instance.
     *
     * @var Enquiry
     */

    public $enquiry;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($enquiry)
    {
        $this->enquiry = $enquiry;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
         $et = EmailTemplate::where("email_hook_id", 7)->first();
        if($et){
            $subject = $et->subject;
            $body = $et->body;

            $body = Str::replaceArray('##HEADER##', [asset("images/et_header.jpg")], $body);
            $body = Str::replaceArray('##INQUIRY_SUBJECT##', [$this->enquiry->subject], $body);
            $body = Str::replaceArray('##INQUIRY_NAME##', [$this->enquiry->name], $body);
            $body = Str::replaceArray('##INQUIRY_EMAIL##', [$this->enquiry->email], $body);
            $body = Str::replaceArray('##INQUIRY_PHONE##', [$this->enquiry->phone], $body);
            $body = Str::replaceArray('##INQUIRY_MESSAGE##', [$this->enquiry->message], $body);
            $body = Str::replaceArray('##COPYRIGHT_YEAR##', [date('Y')], $body);

            $this->subject($subject)
                ->view('emails.template')
                ->with(['template'=>$body]);
        }
    }
}
