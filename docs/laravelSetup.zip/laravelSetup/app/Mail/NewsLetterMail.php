<?php

namespace App\Mail;

use App\Models\NewsLetter;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use App\Models\EmailTemplate;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class NewsLetterMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * The newsLetter instance.
     *
     * @var NewsLetter
     */

    public $newsLetter;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(NewsLetter $newsLetter)
    {
        $this->newsLetter = $newsLetter;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereName('News Letter Mail')->first(['subject', 'body']);
        if($et){
            $subject = $et->subject;
            $body = $et->body;

            $body = Str::replaceArray('##HEADER##', [asset("images/et_header.jpg")], $body);
            $body = Str::replaceArray('##NEWSLETTER_EMAIL##', [$this->newsLetter->email], $body);
            $body = Str::replaceArray('##COPYRIGHT_YEAR##', [date('Y')], $body);

            $this->subject($subject)
                ->view('emails.template')
                ->with(['template'=>$body]);
        }
    }
}
