<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use App\Models\EmailTemplate;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class VerifyOtpMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * The user instance.
     *
     * @var User
     */

    public $user;

    /**
     * The Otp.
     *
     * @var Otp
     */

    public $Otp;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $user, $Otp)
    {
        $this->user = $user;
        $this->Otp = $Otp;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $et = EmailTemplate::whereName('Verify Otp')->first(['subject', 'body']);
        if($et){
            $subject = $et->subject;
            $body = $et->body;

            $body = Str::replaceArray('##HEADER##', [asset("images/et_header.jpg")], $body);
            $body = Str::replaceArray('##USER_NAME##', [$this->user->first_name], $body);
            $body = Str::replaceArray('##VERIFY_OTP##', [$this->Otp], $body);
            $body = Str::replaceArray('##COPYRIGHT_YEAR##', [date('Y')], $body);

            $this->subject($subject)
                ->view('emails.template')
                ->with(['template'=>$body]);
        }
    }
}
