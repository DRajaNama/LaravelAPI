<?php

namespace App\Mail;

use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use App\Models\EmailTemplate;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class VerifyUserMail extends Mailable implements ShouldQueue {

    use Queueable,
        SerializesModels;

    /**
     * The user instance.
     *
     * @var User
     */
    public $user;

    /**
     * The token.
     *
     * @var Token
     */
    public $token;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($user) {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build() {
        
        $et = EmailTemplate::where("email_hook_id", 1)->first();
        if ($et) {
            $fullUrl = \App::make('url')->to('/');
            $subject = $et->subject;
            $subject = Str::replaceArray('##USER_NAME##', [$this->user->name], $subject);
            $subject = Str::replaceArray('##SYSTEM_APPLICATION_NAME##', ['MaxMindPower'], $subject);

            $body = $et->description;

            $body = Str::replaceArray('##HEADER##', [asset("images/et_header.jpg")], $body);
            $body = Str::replaceArray('##USER_NAME##', [$this->user->name], $body);
            $body = Str::replaceArray('##VERIFY_LINK##', [$fullUrl.'/users/verify-account/'.$this->user->verification_code], $body);
            $body = Str::replaceArray('##COPYRIGHT_YEAR##', [date('Y')], $body);
            $body = Str::replaceArray('##SYSTEM_APPLICATION_NAME##', ['MaxMindPower'], $body);

            $this->subject($subject)
                    ->view('emails.template')
                    ->with(['template' => $body]);
        }
    }

}
