<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{

    const PER_PAGE = 20;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title', 
        'sub_title', 
        'excerpt', 
        'description',
        'meta_title',
        'meta_keyword',
        'meta_description',
        'slug',
    ];

    /**
     * Get the page title .
     *
     * @param  string  $value
     * @return string
     */
    public function getPageTitleAttribute() {
        $pageTitle = explode(' ', $this->title, 2);
        if(count($pageTitle) > 1){
            return $pageTitle[0].' <strong>'.$pageTitle[1].'</strong>';
        }
        return $this->title;
    }

    /**
     * Get the body.
     *
     * @param  string  $value
     * @return string
     */
    public function getDescriptionAttribute($value)
    {
        return html_entity_decode($value, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getCreatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }

    /**
     * Get the updated at.
     *
     * @param  string  $value
     * @return string
     */
    public function getUpdatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }
}
