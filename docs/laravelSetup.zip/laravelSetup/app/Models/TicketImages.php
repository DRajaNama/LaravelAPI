<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class TicketImages extends Model
{
	use SoftDeletes;
	
    protected $fillable = [
        'user_id', 
        'ticket_id',
		'image_title',
		'image',
		'status',
    ];
	protected $appends = array('image_full_path');
	
	 protected $dates = ['deleted_at']; 
	 
	 /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getCreatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }

    /**
     * Get the updated at.
     *
     * @param  string  $value
     * @return string
     */
    public function getUpdatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }
	
	 public function getImageFullPathAttribute() {
        // return "{$this->audio}";
        return !empty($this->image) ? asset('uploads/tickets/' . $this->image) : "";
    }
}
