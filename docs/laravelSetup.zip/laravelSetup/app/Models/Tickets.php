<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Tickets extends Model
{
	 use SoftDeletes;
	 
    protected $fillable = [
        'user_id', 
        'site_id',
		'vehical_no',
		'vehical_no',
    ];
	protected $appends = array('pdf_full_path');
	
	protected $dates = ['deleted_at']; 
	 
	/**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getCreatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }

    /**
     * Get the updated at.
     *
     * @param  string  $value
     * @return string
     */
    public function getUpdatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }
	
	public function images()
    {
        return $this->hasMany('App\Models\TicketImages','ticket_id');
    }
	
	public function user()
    {
        return $this->belongsTo('App\Models\User','user_id');
    }
	public function sites(){
		return $this->belongsTo('App\Models\Sites','site_id');
	}
	
	public function getPdfFullPathAttribute() {
       return !empty($this->pdf_file) ? asset('uploads/pdf/' . $this->pdf_file) : "";
    }
}
