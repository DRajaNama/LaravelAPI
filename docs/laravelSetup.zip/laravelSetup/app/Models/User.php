<?php

namespace App\Models;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Notifications\ResetPasswordNotification;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    const NOT_VERIFIED = 0;
    const IN_ACTIVE = 0;
    const VERIFIED = 1;
    const ACTIVE = 1;
    const PER_PAGE = 20;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'email', 'photo', 'phone', 'dob', 'status','is_verified','password','gender','is_download_offline','is_notifiable'];
    protected $appends = array('profile_photo_full_path', 'created', 'modified','token');
    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'last_seen_at',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 
        'remember_token',
    ];


    /**
     * The attributes casts.
     *
     * @var array
     */
    protected $casts = [
        'status' => 'boolean',
        'is_verified' => 'boolean',
        'is_notifiable' => 'boolean',
        'is_download_offline' => 'boolean',
    ];

    /**
     * Scope a query to only include active users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('status', self::ACTIVE);
    }

    /**
     * Scope a query to only include verified users.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeVerified($query)
    {
        return $query->where('is_verified', self::VERIFIED);
    }

    /**
     * Get the verify user.
     */
    public function verifyUser()
    {
        return $this->hasOne('App\VerifyUser');
    }

    /**
     * Get the user's full name.
     *
     * @return string
     */
    public function getFullNameAttribute()
    {
        return "{$this->name}";
    }


    /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getCreatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }

    /**
     * Get the updated at.
     *
     * @param  string  $value
     * @return string
     */
    public function getUpdatedAtAttribute($value) {
        return \Carbon\Carbon::parse($value)->format('d M Y g:i A');
    }

    /**
     * Get the created at.
     *
     * @param  string  $value
     * @return string
     */
    public function getMemberSinceAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->format('d M Y');
    }

    /*
     * make dynamic attribute for human readable time
     *
     * @return string
     * 
     */
    public function getHumansTimeAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->diffForHumans();
    }

    /**
     * Send the password reset notification.
     *
     * @param  string  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new ResetPasswordNotification($token));
    }
     public function getCreatedAttribute() {
        return \Carbon\Carbon::parse($this->created_at)->format('Y-m-d H:i:s');
    }

    public function getModifiedAttribute() {
        return \Carbon\Carbon::parse($this->updated_at)->format('Y-m-d H:i:s');
    }

    public function getProfilePhotoFullPathAttribute() {
        // return "{$this->audio}";
        return !empty($this->photo) ? asset('uploads/users/' . $this->photo) : "";
    }
    public function getTokenAttribute() {
         return "{$this->api_token}";
       
    }
}
