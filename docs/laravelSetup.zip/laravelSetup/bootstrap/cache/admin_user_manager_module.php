<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdminUserManager\\Providers\\AdminUserManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdminUserManager\\Providers\\AdminUserManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);