<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdvertisementCategoryManager\\Providers\\AdvertisementCategoryManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdvertisementCategoryManager\\Providers\\AdvertisementCategoryManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);