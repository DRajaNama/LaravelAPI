<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AdvertisementPackageManager\\Providers\\AdvertisementPackageManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AdvertisementPackageManager\\Providers\\AdvertisementPackageManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);