<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BaseCategoryManager\\Providers\\BaseCategoryManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BaseCategoryManager\\Providers\\BaseCategoryManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);