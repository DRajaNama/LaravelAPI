<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BookManager\\Providers\\BookManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BookManager\\Providers\\BookManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);