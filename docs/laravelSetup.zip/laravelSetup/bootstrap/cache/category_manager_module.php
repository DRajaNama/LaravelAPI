<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CategoryManager\\Providers\\CategoryManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CategoryManager\\Providers\\CategoryManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);