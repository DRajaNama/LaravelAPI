<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\EmotionManager\\Providers\\EmotionManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\EmotionManager\\Providers\\EmotionManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);