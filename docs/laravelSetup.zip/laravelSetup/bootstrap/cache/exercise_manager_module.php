<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ExerciseManager\\Providers\\ExerciseManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ExerciseManager\\Providers\\ExerciseManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);