<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FaqManager\\Providers\\FaqManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FaqManager\\Providers\\FaqManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);