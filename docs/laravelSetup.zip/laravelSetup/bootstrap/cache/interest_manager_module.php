<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\InterestManager\\Providers\\InterestManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\InterestManager\\Providers\\InterestManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);