<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LocationManage\\Providers\\LocationManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LocationManage\\Providers\\LocationManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);