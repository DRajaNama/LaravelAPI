<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\LocationManager\\Providers\\LocationManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\LocationManager\\Providers\\LocationManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);