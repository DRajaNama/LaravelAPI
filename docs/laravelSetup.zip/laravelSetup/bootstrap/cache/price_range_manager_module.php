<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PriceRangeManager\\Providers\\PriceRangeManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PriceRangeManager\\Providers\\PriceRangeManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);