<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SectionManager\\Providers\\SectionManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SectionManager\\Providers\\SectionManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);