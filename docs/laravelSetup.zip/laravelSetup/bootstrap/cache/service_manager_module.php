<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ServiceManager\\Providers\\ServiceManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ServiceManager\\Providers\\ServiceManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);