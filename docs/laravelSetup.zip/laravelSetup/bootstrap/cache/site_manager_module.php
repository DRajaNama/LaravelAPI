<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SiteManager\\Providers\\SiteManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SiteManager\\Providers\\SiteManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);