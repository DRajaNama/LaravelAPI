<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TestimonialManager\\Providers\\TestimonialManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TestimonialManager\\Providers\\TestimonialManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);