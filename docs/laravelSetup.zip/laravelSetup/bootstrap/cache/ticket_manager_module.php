<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TicketManager\\Providers\\TicketManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TicketManager\\Providers\\TicketManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);