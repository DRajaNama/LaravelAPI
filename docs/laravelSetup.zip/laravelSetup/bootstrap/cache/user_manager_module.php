<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserManager\\Providers\\UserManagerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserManager\\Providers\\UserManagerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);