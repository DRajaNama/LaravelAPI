<table width="700" border="0" cellspacing="0" cellpadding="0" align="center" style="border: 1px solid #f7f7f7;">
    <tr>
        <td valign="top">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td valign="top">
                        <img src="##HEADER##"  alt="" />
                    </td>
                </tr>
                <tr>
                    <td valign="top" style="padding-top:15px; padding-right:30px; padding-bottom:30px; padding-left:30px;">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px; padding-bottom:60px;">
                                    Hi, ##APP_NAME##! <br />
                                    <br />
                                    You are receiving this email because ##PROVIDER_NAME## has been created a below event:
                                </td>
                            </tr>
                            <tr>
                                <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px; padding-bottom:60px;">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                              <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">Title:</td>
                                              <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px; ">##EVENT_TITLE##</td>
                                        </tr>
                                        <tr>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">Supervisor:</td>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">##EVENT_SUPERVISOR##</td>
                                        </tr>
                                        <tr>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">Start date time:</td>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">##EVENT_START_DATE_TIME##</td>
                                        </tr>
                                        <tr>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">End date time:</td>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">##EVENT_END_DATE_TIME##</td>
                                        </tr>
                                        <tr>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">Peoples Required:</td>
                                            <td style=" font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#5d5d5d; line-height:24px;">##PEOPLES_REQUIRED##</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td valign="top" style="background-color:#cc73e9; padding-top:15px; padding-bottom:15px; font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#ffffff; text-align:center; font-weight:bold;">
                        ##APP_NAME## © ##COPYRIGHT_YEAR## All rights reserved.
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>