@extends('layouts.master')
@section('title',$data['title'])
@section('content')

<div class="main-content">
    <div class="container">

        <h2 class="bdr">{{ __('Account Verification') }}</h2>
        <p> <h6 class="bdr">{{ $data['status'] }}</h6> </p>
        <p>{!! $data['message'] !!}</p>
    </div>
</div>

@stop

