<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="{{ asset('storage/settings/' . config('get.MAIN_FAVICON')) }}" type="image/x-icon" rel="icon"/>
    <link href="{{ asset('storage/settings/' . config('get.MAIN_FAVICON')) }}" type="image/x-icon" rel="shortcut icon"/>
    <title>{{ config('get.SYSTEM_APPLICATION_NAME') }} | @yield('title')</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="{{asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')}}">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset('bower_components/font-awesome/css/font-awesome.min.css')}}">
    <!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="{{asset('dist/css/adminlte.min.css')}}">
    <!-- iCheck -->
    <link rel="stylesheet" href="{{asset('plugins/iCheck/square/blue.css')}}">
	<link rel="stylesheet" href="{{asset('plugins/fontawesome-free/css/all.min.css')}}">
 
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <!-- Google Font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <style>
    .login-box .alert{ margin-bottom: 0px !important; }
    </style>
</head>
<body class="hold-transition login-page">

<?php if(!empty($errors->count())){ ?>
	<div class="alert alert-danger alert-dismissible" style="position: absolute;top: 50px;right: 50px;z-index: 999;">
	  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	  <i class="icon fas fa-ban"></i> Error! &nbsp; Something went wrong!
	</div>
	
<?php } ?>
<div class="container">
	<div class="row">
		<div class="col-lg-8 text-center hidden-xs">
			<h1>Manage Your Administration Account</h1>
			<p>Donec dictum nisl nec mi lacinia, sed maximus tellus eleifend. Proin molestie cursus sapien ac eleifend.</p>
			<center>
			<img src="{{ asset('img/admin_login_page.jpg') }}" alt="" style="max-width: 300px;">
			</center>
		</div>
		<div class="col-lg-4" >
			<div class="login-box">
				<div class="login-logo">
					<img src="{{ asset('storage/settings/' . config('get.MAIN_LOGO')) }}" style="max-height:100px;" />
				</div>
				
				<div class="card">
					<div class="card-body login-card-body">
					@yield('content')
					</div>
				</div>

			</div>
			<!-- /.login-box -->
		</div>
	</div>
</div>
<!-- jQuery 3 -->
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- iCheck -->
<script src="{{asset('dist/js/adminlte.min.js')}}"></script>


<script>
	$(function () {
		$('input').iCheck({
			checkboxClass: 'icheckbox_square-blue',
			radioClass: 'iradio_square-blue',
			increaseArea: '20%' // optional
		});
	});
	$('.alert').fadeTo(5000, 0);
</script>

@yield('script_per_page')
</body>
</html>
