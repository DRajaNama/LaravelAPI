@php
	$currentUrl = \Illuminate\Support\Facades\Request::segment(2);
	$currentUrlSection = \Illuminate\Support\Facades\Request::segment(3);
@endphp
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{url('admin/dashboard')}}" class="brand-link">
      <img src="{{ asset('storage/settings/' . config('get.MAIN_LOGO')) }}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">{{ config('get.SYSTEM_APPLICATION_NAME') }}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="{{asset('dist/img/user2-160x160.jpg')}}" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="{{url('admin/dashboard')}}" class="d-block">{{$adminUser->name}}</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="{{url('admin/dashboard')}}" class="nav-link @if($currentUrl == 'dashboard') active @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="{{url('admin/users')}}" class="nav-link @if($currentUrl == 'users') active @endif">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Manage Users
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
		  <li class="nav-item">
            <a href="{{url('admin/faqs')}}" class="nav-link @if($currentUrl == 'faqs') active @endif">
              <i class="nav-icon fas fa-question-circle"></i>
              <p>
                Faq
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
		  <li class="nav-item">
            <a href="{{ route('admin.pages.index')}}" class="nav-link @if($currentUrl == 'pages') active @endif">
              <i class="nav-icon fas fa-book"></i>
              <p>
                CMS Pages
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview @if($currentUrl == 'hooks' || $currentUrl == 'email-preferences' || $currentUrl == 'email-templates') menu-open @endif">
            <a href="#" class="nav-link @if($currentUrl == 'hooks' || $currentUrl == 'email-preferences' || $currentUrl == 'email-templates') active @endif">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Email Templates
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item ">
                <a href="{{ route('admin.hooks')}}" class="nav-link @if($currentUrl == 'hooks') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Hooks (slugs)</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="{{ route('admin.email-preferences.index') }}" class="nav-link @if($currentUrl == 'email-preferences') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Email Preferences (layouts)</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="{{ route('admin.email-templates.index') }}" class="nav-link @if($currentUrl == 'email-templates') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Email Templates</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview @if($currentUrl == 'settings') menu-open @endif">
            <a href="#" class="nav-link @if($currentUrl == 'settings') active @endif">
              <i class="nav-icon fa fa-cogs"></i>
              <p>
                Settings
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item ">
                <a href="{{url('admin/settings/logos')}}" class="nav-link @if($currentUrlSection == 'logos') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logo/Favicon Icon</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="{{url('admin/settings/general')}}" class="nav-link @if($currentUrlSection == 'general') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>General Settings</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="{{url('admin/settings/smtp')}}" class="nav-link @if($currentUrlSection == 'smtp') active @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>SMTP Details</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-header">Application Settings</li>
		  <li class="nav-item ">
            <a href="{{ route('admin.changepassword') }}" class="nav-link @if($currentUrl == 'change-password') active @endif">
              <i class="nav-icon fas fa-unlock"></i>
              <p>
                Change Password
              </p>
            </a>
          </li>
		  <li class="nav-item ">
            <a href="{{ route('admin.logout') }}" class="nav-link @if($currentUrl == 'logout') active @endif" onclick="event.preventDefault(); document.getElementById('logout-sidebarform').submit();">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
          <form id="logout-sidebarform" action="{{ route('admin.logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>


