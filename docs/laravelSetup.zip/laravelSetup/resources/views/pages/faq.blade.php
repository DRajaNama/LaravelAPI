@extends('layouts.master')
@section('title',$page->title)
@section('content')
@include('layouts.admin.flash.alert')
<div class="main-content">
    <div class="container">
    
    <h2 class="bdr">{{ $page->title }}</h2>
    <p>{{ $page->short_description }}</p>
    
    <div class="faq-box">
    <div class="accordion" id="accordionExample">
        @php 
         $temp=1; 
        @endphp
      
        @foreach($faqs as $item)
        @php  
          $heading = 'heading'.$temp; 
          $collapse = 'collapse'.$temp; 
         
          @endphp
    <div class="card">
    <div class="card-header" id="{{ $heading }}">
    <button class="btn btn-link  {{ ($temp==1)?'':'collapsed' }}" type="button" data-toggle="collapse" data-target="#{{ $collapse }}" aria-expanded="{{ ($temp==1)?'true':'false' }}" aria-controls="{{ $collapse }}"><i>Q</i> {{$item->heading}} </button>
    </div>
    <div id="{{ $collapse }}" class="collapse {{ ($temp==1)?'show':'' }}" aria-labelledby="{{ $heading }}" data-parent="#accordionExample">
    <div class="card-body">
    <p>{{$item->heading}} </p>
    </div>
    </div>
    </div>
    @php     $temp++; @endphp
    @endforeach
    
    </div>
    </div>
    
    </div>
    </div>


@stop
