@extends('layouts.master')
@section('title',$page->title)
@section('content')
<div class="main-content">
    <div class="container">
    
    <h2 class="bdr">{{ $page->title }}</h2>
    <p>{{ $page->short_description }}</p>
      <p>{!! $page->description !!}</p>
    </div>
    </div>


@stop
