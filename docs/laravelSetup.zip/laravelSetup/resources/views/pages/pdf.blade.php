<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table class="table table-bordered">
      <tr>
        <td>
          {{$ticket->vehical_no}}
        </td>
        <td>
          {{$ticket->site_id}}
        </td>
      </tr>
      <tr>
        <td>
          {{$ticket->description}}
        </td>
      </tr>
    </table>
  </body>
</html>