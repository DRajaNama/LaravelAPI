<?php $__env->startSection('title'); ?> Settings <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-8">
		<h1 class="m-0 text-dark">Manage Setting</h1>
		<small>Setting Detail</small>
	  </div><!-- /.col -->
	  <div class="col-sm-4">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/settings/general')); ?>">Settings</a></li>
			<li class="breadcrumb-item active">Setting Detail</li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<section class="content">
	<!-- Default box -->
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					Office Address
				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('setting.general')); ?>" class="btn btn-default pull-right" title="Cancel">
					<i class="fa fa-fw fa-chevron-circle-left"></i> Back
				</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<table class="table table-hover">
				<tbody>
					<tr>
						<th scope="row">Title</th>
						<td><?php echo e($settings->title); ?></td>
					</tr>
					<tr>
						<th scope="row">Manager</th>
						<td><?php echo e($settings->manager); ?></td>
					</tr>
					<tr>
						<th scope="row">Constant/Slug</th>
						<td><?php echo e($settings->slug); ?></td>
					</tr>
					<tr>
						<th scope="row">Config Value</th>
						<td><?php echo e($settings->config_value); ?></td>
					</tr>
					<tr>
						<th scope="row">Field Type</th>
						<td><?php echo e($settings->field_type); ?></td>
					</tr>
					<tr>
						<th scope="row">Created</th>
						<td><?php echo e($settings->created_at); ?></td>
					</tr>
					<tr>
						<th scope="row">Modified</th>
						<td><?php echo e($settings->updated_at); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>