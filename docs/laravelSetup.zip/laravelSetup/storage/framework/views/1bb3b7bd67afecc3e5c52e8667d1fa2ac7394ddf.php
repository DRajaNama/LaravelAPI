

<?php $__env->startSection('title'); ?> Settings <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Manage Setting</h1>
		<small>Here you can manage the general settings</small>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item active">General Settings</li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<section class="content">
	<!-- Default box -->
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					List Settings
				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('setting.general.add')); ?>" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> New Setting</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<div class="row">
				<div class="col-lg-12">
					<table class="table table-hover">
						<thead>
						<tr>
							<th>#</th>
							<th scope="col"><a href="<?php echo e(URL::route('setting.general',['sort' => 'title','direction'=> request()->direction == 'asc' ? 'desc' : 'asc'])); ?>">Title</a></th>
							<th scope="col"><a href="<?php echo e(URL::route('setting.general',['sort' => 'slug','direction'=> request()->direction == 'asc' ? 'desc' : 'asc'])); ?>">Constant</a></th>
							<th scope="col">Value</th>
							<th scope="col" class="actions" style="width: 15%;">Actions</th>
						</tr>
						</thead>
						<?php if($settings->count() > 0): ?>
						<tbody>
						<?php
						$i = (($settings->currentPage() - 1) * ($settings->perPage()) + 1)
						?>
						<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td> <?php echo e($i); ?>. </td>
								<td><?php echo e($setting->title); ?></td>
								<td><?php echo e($setting->slug); ?></td>
								<td><?php echo e($setting->config_value); ?></td>
								<td class="actions">
									<div class="btn-group">
										<a href="<?php echo e(url('admin/settings/general/view/'.$setting->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" alt="View setting" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a>
										<a href="<?php echo e(url('admin/settings/general/edit/'.$setting->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
									</div>
								</td>
							</tr>
						<?php
							$i++;
						?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<?php else: ?>
						<tfoot>
							<tr>
								<td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
							</tr>
						</tfoot>
						<?php endif; ?>
					</table>
				</div>
			</div>
		</div>
		<!-- /.card-footer -->
		<div class="card-footer">
			<?php echo e($settings->appends(Request::query())->links()); ?>

		</div>
		
	</div>
</section>
<section class="content">
	<!-- Default box -->
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<i class="fa fa-exclamation"></i> Important Rules
				</span>
			</h3>
			<div class="card-tools">
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<div class="row">
				<div class="col-md-12">
					<p> For each config settings that would be added to the system, make sure it has these constant/slug:</p>
					<ul>
						<li>
							<small class="label bg-yellow">
								SITE_TITLE
							</small> - Will be replaced by website title from the admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								ADMIN_EMAIL
							</small> - Will be replaced by admin email from the admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								FROM_EMAIL
							</small> - Will be replaced by email from the admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								WEBSITE_OWNER
							</small> - Will be replaced by Owner name from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								TELEPHONE
							</small> - Will be replaced by phone number from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								ADMIN_PAGE_LIMIT
							</small> - Will be replaced by admin page limit from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								FRONT_PAGE_LIMIT
							</small> - Will be replaced by front page limit from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								ADMIN_DATE_FORMAT
							</small> - Will be replaced by admin date format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								ADMIN_DATE_TIME_FORMAT
							</small> - Will be replaced by admin date time format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								FRONT_DATE_FORMAT
							</small> - Will be replaced by front date format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								FRONT_DATE_TIME_FORMAT
							</small> - Will be replaced by front date time format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								CONTACT_US_TEXT
							</small> - Will be replaced by front date time format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								GOOGLE_MAP_KEY
							</small> - Will be replaced by front date time format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								OFFICE_ADDRESS
							</small> - Will be replaced by front date time format from admin settings.
						</li>
						<li>
							<small class="label bg-yellow">
								DEVELOPMENT_MODE
							</small> - Will be replaced by debug mode from admin settings.
						</li>


					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>