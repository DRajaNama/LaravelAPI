<?php $__env->startSection('title','View User Detail'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Manage Users</h1>
		<small>Here you can view user detail</small>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		 <?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.users'],['label' => 'View User Detail']]])); ?>

	  </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content" >
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e($user->name); ?>

				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		
        <!-- /.card-body -->
		<div class="card-body">
            <table class="table table-hover">
                <tr>
                    <th scope="row"><?php echo e(__('First Name')); ?></th>
                    <td><?php echo e($user->first_name); ?></td>
					
					<th scope="row"><?php echo e(__('Last Name')); ?></th>
                    <td><?php echo e($user->last_name); ?></td>

                </tr>

                <tr>
                    <th scope="row"><?php echo e(__('Phone')); ?></th>
                    <td><?php echo e($user->phone); ?></td>
					
					
                    <th scope="row"><?php echo e(__('Email')); ?></th>
                    <td><?php echo e($user->email); ?></td>
				</tr>


               
                <tr>
                    <th scope="row"><?php echo e(__('Status')); ?></th>
                    <td><?php echo e($user->status ? __('Active') : __('Inactive')); ?></td>

                    <th scope="row"><?php echo e(__('Verified')); ?></th>
                    <td><?php echo e($user->is_verified ? __('Verified') : __('Not Verified')); ?></td>
                </tr>
				<tr>
					<th scope="row"><?php echo e(__('Profile Image')); ?></th>
                    <td>  
						<?php
						$filepath = '/uploads/users/';
						?>


						<?php if(!empty($user->photo) && file_exists(public_path() . $filepath . $user->photo)): ?>
						<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $user->photo), '200', '200', '100'); ?>
					   
						<?php else: ?>
						<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url('img/no_image.gif'), '200', '200', '100'); ?>
						<?php endif; ?>
						<img src="<?php echo e($imageurl); ?>" class=" img-responsive img-thumbnail" alt="<?php echo e($user->name); ?>">
                    </td>

				</tr>
            </table>  
		</div>
        <!-- /.card-footer -->
		<div class="card-footer">
            <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>