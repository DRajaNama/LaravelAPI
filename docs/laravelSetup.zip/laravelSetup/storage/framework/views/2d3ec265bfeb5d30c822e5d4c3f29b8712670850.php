<?php $__env->startSection('title', !empty($user) ? 'Edit User' : 'Add User'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Content Header (Page header) -->

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Manage Users</h1>
		<small>Here you can manage users</small>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		<?php echo e(Breadcrumbs::render('common',['append' => [['label'=> $getController,'route'=> 'admin.users'],['label' => !empty($user) ? 'Edit User' : 'Add User' ]]])); ?>

	  </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>


<section class="content">
<?php if(isset($user)): ?>
	<?php echo e(Form::model($user, ['route' => ['admin.users.update', $user->id], 'method' => 'patch','enctype'=>"multipart/form-data"])); ?>

<?php else: ?>
	<?php echo e(Form::open(['route' => 'admin.users.store','enctype'=>"multipart/form-data"])); ?>

<?php endif; ?>
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e(!empty($user) ? 'Edit User' : 'Add User'); ?> 
				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-default pull-right" title="Cancel">
					<i class="fa fa-fw fa-chevron-circle-left"></i> 
					Back
				</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
            <div class="row">
				<div class="col-md-6">
					<div class="form-group required <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
						<label for="name">First Name</label>
						<?php echo e(Form::text('first_name', old('first_name'), ['class' => 'form-control','placeholder' => 'First Name'])); ?>

						<?php if($errors->has('first_name')): ?>
						<span class="help-block"><?php echo e($errors->first('first_name')); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group required <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
						<label for="name">Last Name</label>
						<?php echo e(Form::text('last_name', old('last_name'), ['class' => 'form-control','placeholder' => 'Last Name'])); ?>

						<?php if($errors->has('last_name')): ?>
						<span class="help-block"><?php echo e($errors->first('last_name')); ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">	
				<div class="col-md-6">
					<div class="form-group <?php echo e(empty($user) ? 'required' : ''); ?> <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
						<label for="password">Password</label>
						<input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder ='Password'>                                
						<?php if($errors->has('password')): ?>
						<span class="help-block"><?php echo e($errors->first('password')); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group <?php echo e(empty($user) ? 'required' : ''); ?> <?php echo e($errors->has('password_confirmation') ? 'has-error' : ''); ?>">
						<label for="confirm_password">Confirm Password</label>
						<input id="password_confirmation" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" placeholder ='Confirm Password'>

						<?php if($errors->has('confirm_password')): ?>
						<span class="help-block"><?php echo e($errors->first('password_confirmation')); ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group required <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
						<label for="email">Email</label>
						<?php echo e(Form::text('email', old('email'), ['class' => 'form-control','placeholder' => 'Email'])); ?>

						<?php if($errors->has('email')): ?>
						<span class="help-block"><?php echo e($errors->first('email')); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group required <?php echo e($errors->has('is_verified') ? 'has-error' : ''); ?>">
						<label for="is_verified">Verified</label>
						<?php echo e(Form::select('is_verified', [1 => 'Verified', 0 => 'Not Verified'], old("is_verified"), ['class' => 'form-control'])); ?>


					</div>
				</div>
			 </div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group required <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
						<label for="status">Status</label>
						<?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>


					</div>
				</div>
				 <div class="col-md-6">
					<div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
						<label for="phone">Phone Number</label>
						<?php echo e(Form::text('phone', old('phone'), ['class' => 'form-control','placeholder' => 'Phone Number'])); ?>

						<?php if($errors->has('phone')): ?>
						<span class="help-block"><?php echo e($errors->first('phone')); ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group  <?php echo e($errors->has('photo') ? 'has-error' : ''); ?>">
						<label for="imageInput">Profile Photo</label>
						<input data-preview="#photo" name="photo" type="file" id="photoInput">
					</div>
				</div>
				<div class="col-md-6">
					<img class="col-sm-6" id="preview"  src="">
					<p class="help-block">Browse Profile Photo.</p>
						 <?php
						$filepath = '/uploads/users/';
						?>
						<?php if(!empty($user->photo) && file_exists(public_path() . $filepath . $user->photo)): ?>
						<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $user->photo), '200', '200', '100'); ?>
					
						<?php else: ?>
						<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url('img/no_image.gif'), '200', '200', '100'); ?>
						<?php endif; ?>
					<img src="<?php echo e($imageurl); ?>" class=" img-responsive img-thumbnail">
				</div>
			</div>
		</div>
		<!-- /.card-footer -->
		<div class="card-footer">
			<button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
		</div>
	</div>
	<?php echo e(Form::close()); ?>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>