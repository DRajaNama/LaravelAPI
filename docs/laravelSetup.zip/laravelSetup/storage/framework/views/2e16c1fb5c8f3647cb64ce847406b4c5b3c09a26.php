
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
   
	
	<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
		<div class="container-fluid">
      <!-- Small boxes (Stat box) -->
			<div class="row">
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-aqua">
					<div class="inner">
					  <h3><?php echo e($users); ?></h3>

					  <p>Total Users</p>
					</div>
					<div class="icon">
					  <i class="ion ion-person-add"></i>
					</div>
					<a href="<?php echo e(route('admin.users')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				  </div>
				</div>
				<!-- ./col -->
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-maroon">
					<div class="inner">
					  <h3><?php echo e($faqs); ?></h3>

					  <p>Total Faqs</p>
					</div>
					<div class="icon">
					  <i class="ion ion-stats-bars"></i>
					</div>
					<a href="<?php echo e(route('data.faq')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				  </div>
				</div>
				<!-- ./col -->
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-fuchsia">
					<div class="inner">
					  <h3><?php echo e($email_templates); ?></h3>

					  <p>Total Email Templates</p>
					</div>
					<div class="icon">
					  <i class="ion ion-stats-bars"></i>
					</div>
					<a href="<?php echo e(url('admin/email-templates')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				  </div>
				</div>
			   
				<!-- ./col -->
				<div class="col-lg-3 col-xs-6">
				  <!-- small box -->
				  <div class="small-box bg-red">
					<div class="inner">
					  <h3><?php echo e($pages); ?></h3>

					  <p>Total CMS Pages</p>
					</div>
					<div class="icon">
					  <i class="ion ion-pie-graph"></i>
					</div>
					<a href="<?php echo e(url('admin/pages')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				  </div>
				</div>
			</div> 
			<div class="row">
				<section class="col-lg-6 connectedSortable">
					 <!-- Calendar -->
						<div class="card bg-gradient-success">
						  <div class="card-header border-0">

							<h3 class="card-title">
							  <i class="far fa-calendar-alt"></i>
							  Calendar
							</h3>
							<!-- tools card -->
							<div class="card-tools">
							  <!-- button with a dropdown -->
							  <button type="button" class="btn btn-success btn-sm" data-card-widget="collapse">
								<i class="fas fa-minus"></i>
							  </button>
							  <button type="button" class="btn btn-success btn-sm" data-card-widget="remove">
								<i class="fas fa-times"></i>
							  </button>
							</div>
							<!-- /. tools -->
						  </div>
						  <!-- /.card-header -->
						  <div class="card-body pt-0">
							<!--The calendar -->
							<div id="calendar" style="width: 100%"></div>
						  </div>
						  <!-- /.card-body -->
						</div>
						<!-- /.card -->
				</section>
			</div>
		</div>
      <!-- /.row -->
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>