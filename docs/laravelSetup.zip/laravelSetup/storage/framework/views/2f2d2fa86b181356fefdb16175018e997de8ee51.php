
<?php $__env->startSection('title','Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <p class="login-box-msg" style="padding-bottom: 5px;"><?php echo e(__('Forgot Password ?')); ?></p>
    <p  style="padding-left: 15px;"><small>Enter your e-mail address below to reset your password.</small> </p>
    <form method="POST" action="<?php echo e(route('admin.password.email')); ?>">
            <?php echo csrf_field(); ?>
	<?php if($errors->has('email')): ?>
		<label class="col-form-label text-danger" for="email">
			<i class="far fa-times-circle"></i> 
			<?php echo e($errors->first('email')); ?>

		</label>
	   <?php endif; ?>
    <div class="input-group mb-3 ">
		<input id="email" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$" placeholder="Enter your e-mail address">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope <?php echo e($errors->has('email') ? ' text-danger' : ''); ?>"></span>
            </div>
          </div>
	 </div>
	 
    <div class="row">
        <div class="col-lg-12">
                <button type="submit" class="btn btn-primary btn-block btn-flat">
                        <?php echo e(__('Send Password Reset Link')); ?>

                    </button>
        </div><!-- /.col -->
    </div>
</form>
 <br>
<div class="social-auth-links text-center">
      <p>- OR -</p>
     <a href="<?php echo e(route('admin.login')); ?>">Go to login</a>
    </div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>