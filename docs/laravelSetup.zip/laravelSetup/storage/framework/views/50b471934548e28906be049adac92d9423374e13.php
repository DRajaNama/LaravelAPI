<?php $__env->startSection('title','View CMS Page Detail'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-8">
		<h1 class="m-0 text-dark">Manage CMS Pages</h1>
		<small>Here you can view cms page detail</small>
	  </div><!-- /.col -->
	  <div class="col-sm-4">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/pages')); ?>"><?php echo e(__("CMS Pages")); ?></a></li>
			<li class="breadcrumb-item active">View CMS Page Detail</li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
	<div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e($page->title); ?>

				</span>
			</h3>
			<div class="card-tools">
				 <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-default pull-right" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
            <table class="table table-hover table-striped">
                <tr>
                    <th scope="row"><?php echo e(__('Title')); ?></th>
                    <td><?php echo e($page->title); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Sub  Title')); ?></th>
                    <td><?php echo e($page->sub_title); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Slug')); ?></th>
                    <td><?php echo e($page->slug); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?= __('Created') ?></th>
                    <td><?php echo e($page->created_at->toFormattedDateString()); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Modified')); ?></th>
                    <td><?php echo e($page->updated_at->toFormattedDateString()); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Status')); ?></th>
                    <td><?php echo e($page->status ? __('Active') : __('Inactive')); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php echo e(__('Description')); ?></th>
                    <td><?php echo $page->description; ?></td>
                </tr>
            </table>
        </div>
        <!-- /.card-footer -->
		<div class="card-footer">
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-default pull-left" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>