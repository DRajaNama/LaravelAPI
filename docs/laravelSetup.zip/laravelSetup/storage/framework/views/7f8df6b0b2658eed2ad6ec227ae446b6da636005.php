<?php
	$currentUrl = \Illuminate\Support\Facades\Request::segment(2);
	$currentUrlSection = \Illuminate\Support\Facades\Request::segment(3);
?>
  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('admin/dashboard')); ?>" class="brand-link">
      <img src="<?php echo e(asset('storage/settings/' . config('get.MAIN_LOGO'))); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><?php echo e(config('get.SYSTEM_APPLICATION_NAME')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="<?php echo e(url('admin/dashboard')); ?>" class="d-block"><?php echo e($adminUser->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item ">
            <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link <?php if($currentUrl == 'dashboard'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('admin/users')); ?>" class="nav-link <?php if($currentUrl == 'users'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Manage Users
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
		  <li class="nav-item">
            <a href="<?php echo e(url('admin/faqs')); ?>" class="nav-link <?php if($currentUrl == 'faqs'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-question-circle"></i>
              <p>
                Faq
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
		  <li class="nav-item">
            <a href="<?php echo e(route('admin.pages.index')); ?>" class="nav-link <?php if($currentUrl == 'pages'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                CMS Pages
                <!--span class="right badge badge-danger">New</span-->
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview <?php if($currentUrl == 'hooks' || $currentUrl == 'email-preferences' || $currentUrl == 'email-templates'): ?> menu-open <?php endif; ?>">
            <a href="#" class="nav-link <?php if($currentUrl == 'hooks' || $currentUrl == 'email-preferences' || $currentUrl == 'email-templates'): ?> active <?php endif; ?>">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Email Templates
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item ">
                <a href="<?php echo e(route('admin.hooks')); ?>" class="nav-link <?php if($currentUrl == 'hooks'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Hooks (slugs)</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="<?php echo e(route('admin.email-preferences.index')); ?>" class="nav-link <?php if($currentUrl == 'email-preferences'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Email Preferences (layouts)</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="<?php echo e(route('admin.email-templates.index')); ?>" class="nav-link <?php if($currentUrl == 'email-templates'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Email Templates</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item has-treeview <?php if($currentUrl == 'settings'): ?> menu-open <?php endif; ?>">
            <a href="#" class="nav-link <?php if($currentUrl == 'settings'): ?> active <?php endif; ?>">
              <i class="nav-icon fa fa-cogs"></i>
              <p>
                Settings
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item ">
                <a href="<?php echo e(url('admin/settings/logos')); ?>" class="nav-link <?php if($currentUrlSection == 'logos'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logo/Favicon Icon</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="<?php echo e(url('admin/settings/general')); ?>" class="nav-link <?php if($currentUrlSection == 'general'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>General Settings</p>
                </a>
              </li>
              <li class="nav-item ">
                <a href="<?php echo e(url('admin/settings/smtp')); ?>" class="nav-link <?php if($currentUrlSection == 'smtp'): ?> active <?php endif; ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>SMTP Details</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-header">Application Settings</li>
		  <li class="nav-item ">
            <a href="<?php echo e(route('admin.changepassword')); ?>" class="nav-link <?php if($currentUrl == 'change-password'): ?> active <?php endif; ?>">
              <i class="nav-icon fas fa-unlock"></i>
              <p>
                Change Password
              </p>
            </a>
          </li>
		  <li class="nav-item ">
            <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link <?php if($currentUrl == 'logout'): ?> active <?php endif; ?>" onclick="event.preventDefault(); document.getElementById('logout-sidebarform').submit();">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
          <form id="logout-sidebarform" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>


