<?php $__env->startSection('title', !empty($faq) ? 'Edit FAQ' : 'Add FAQ'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<style type="text/css">
    input[type=file]{
      display: inline;
    }

    #baanner_preview{
      border: 1px solid black;
      padding: 10px;
    }

    #baanner_preview img{
      width: 200px;
      padding: 5px;
    }
</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js"></script>
<!-- Content Header (Page header) -->

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Manage Users</h1>
		<small>Here you can manage users</small>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item"><a href="<?php echo e(route('data.faq')); ?>"><?php echo e(__("FAQ")); ?></a></li>
			<li class="breadcrumb-item active"><?php echo e(!empty($faq) ? 'Edit FAQ ' : 'Add FAQ'); ?></li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">

<?php if(isset($faq)): ?>
	<?php echo e(Form::model($faq, ['route' => ['data.faq.update', $faq->id], 'method' => 'patch', 'enctype' => 'multipart/form-data'])); ?>

<?php else: ?>
 <?php echo e(Form::open(['route' => 'data.faq.store', 'enctype' => 'multipart/form-data'])); ?>

<?php endif; ?>
	<div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e(!empty($faq) ? 'Edit FAQ' : 'Add FAQ'); ?>

				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('data.faq')); ?>" class="btn btn-default pull-right" title="Cancel">
					<i class="fa fa-fw fa-chevron-circle-left"></i> 
					Back
				</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<div class="row">
				<div class="col-md-12">
					<div class="form-group required <?php echo e($errors->has('heading') ? 'has-error' : ''); ?>">
						<div class="input text">
							<label for="heading">Question</label>
							<?php echo e(Form::text('heading', old('heading'), ['class' => 'form-control','placeholder' => 'Enter Question'])); ?>

							<?php if($errors->has('heading')): ?>
							<span class="help-block"><?php echo e($errors->first('heading')); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>" style="">
						<div class="input textarea">
							<label for="category_textarea">Solution</label>
							<?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Provide Answer', 'rows' => 5])); ?>

							<?php if($errors->has('description')): ?>
							<span class="help-block"><?php echo e($errors->first('description')); ?></span>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div><!-- /.row -->
		</div>
		<!-- /.card-footer -->
		<div class="card-footer">
			<button class="btn btn-primary btn-flat" title="Submit" type="submit"><i
						class="fa fa-fw fa-save"></i> Submit
			</button>
			<a href="<?php echo e(route('data.faq')); ?>" class="btn btn-warning btn-flat" title="Cancel"><i class="fa fa-fw fa-chevron-circle-left"></i> Back</a>
		</div>	
	</div>
<?php echo e(Form::close()); ?>	
</section>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>