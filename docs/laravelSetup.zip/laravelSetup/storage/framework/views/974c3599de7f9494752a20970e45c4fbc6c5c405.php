
<?php $__env->startSection('title','Email Hooks'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Manage Email Hooks
            <small>Here you can manage email hooks(slug)</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo e(url('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="javascript:void(0)" class="active">Hooks</a></li>
        </ol>
    </section>

    <section class="content" data-table="emailHooks">
        <div class="row emailHooks">
            <div class="col-md-7">
                <div class="box box-info">
                    <div class="box-header">
                        <h3 class="box-title"><span class="caption-subject font-green bold uppercase">List <?php echo e(__('Email Hooks')); ?></span></h3>
                        <div class="box-tools">
                            <a href="<?php echo e(route('admin.add-hooks')); ?>" class="btn btn-success btn-flat"><i class="fa fa-plus"></i> New Email Hook</a>
                        </div>
                    </div><!-- /.box-header -->
                    <div class="box-body table-responsive">
                     <?php if(!$emailHooks->isEmpty()): ?>
                            <ul class="timeline">
                               <?php $__currentLoopData = $emailHooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="time-label">
                                        <span class="bg-navy">
                                            <?php echo e($hook->created_at->toFormattedDateString()); ?>

                                        </span>
                                    </li>
                                    <!-- /.timeline-label -->
                                    <!-- timeline item -->
                                    <li>
                                        <i class="fa fa-anchor bg-blue"></i>
                                        <div class="timeline-item">
                                            <span class="time"><i class="fa fa-clock-o"></i> <?php echo e($hook->created_at->format('H:i A')); ?></span>

                                            <h3 class="timeline-header">
                                                <?php echo e($hook->title); ?>

                                            </h3>
                                            <div class="timeline-body">
                                            <?php echo e($hook->description); ?>

                                            </div>
                                            <div class="timeline-footer form-inline">
                                            <a href="<?php echo e(route('admin.view-hooks', ['id' => $hook->id])); ?>" class="btn btn-default btn-xs btn-flat"><i class="fa fa-eye" data-toggle="tooltip" data-placement="left" data-title="View" data-original-title="" title=""></i></a>
                                            <a href="<?php echo e(route('admin.edit-hooks', ['id' => $hook->id])); ?>" class="btn btn-primary btn-xs btn-flat"><i class="fa fa-pencil-square-o" data-toggle="tooltip" data-placement="right" data-title="Edit" data-original-title="Edit" title=""></i></a>
                                        </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <i class="fa fa-clock-o bg-gray"></i>
                                </li>
                            </ul>
                            <?php else: ?>
                            <div style="align:center;">  <strong>Record Not Available</strong> </div>
                            <?php endif; ?>
                    </div>

                </div>
            </div>
            <div class="col-md-5">
                <div class="box box-default">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-anchor"></i> Quick Start</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php echo e(Form::open(['route' => 'admin.save-hooks'])); ?>

                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="alert alert-danger print-error-msg" style="display:none">
                                        <ul></ul>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                                        <label for="title">Title</label>
                                        <?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

                                        <?php if($errors->has('title')): ?>
                                        <span class="help-block"><?php echo e($errors->first('title')); ?></span>
                                        <?php endif; ?>

                                        </div>
                                    <div class="form-group">
                                        <label for="slug">Hook</label>
                                        <?php echo e(Form::text('slug', old('slug'), ['class' => 'form-control','placeholder' => 'Hook/Slug' ,'readonly' => isset($emailHook) ? true : false])); ?>

                                        <p class="help-block">No space, separate each word with underscore. (if you want auto generated then please leave blank)</p>
                                    </div>
                                    <div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                        <label for="description">Description</label>
                                        <?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control','placeholder' => 'Description', 'rows' => 8])); ?>

                                        
                                        <?php if($errors->has('description')): ?>
                                        <span class="help-block"><?php echo e($errors->first('description')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <?php echo e(Form::select('status', [1 => 'Active', 0 => 'Inactive'], old("status"), ['class' => 'form-control'])); ?>

                                    </div>
                                </div>
                            </div> <!-- /.row -->
                        </div><!-- /.box-body -->
                        <div class="box-footer">
                            <button class="btn btn-primary l-button" data-size="xs" title="Submit" type="submit"><span class="ladda-label"><i class="fa fa-fw fa-save"></i> Submit</span></button>
                        </div>
                        <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>