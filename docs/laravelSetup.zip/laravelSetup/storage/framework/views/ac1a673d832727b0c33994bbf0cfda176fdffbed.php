<?php $__env->startSection('title'); ?> FAQS <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-6">
		<h1 class="m-0 text-dark">Manage FAQ</h1>
		<small>Here you can manage the FAQS</small>
	  </div><!-- /.col -->
	  <div class="col-sm-6">
		<ol class="breadcrumb float-sm-right">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
		  <li class="breadcrumb-item active">FAQ</li>
		</ol>
	  </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>		

<?php
$qparams = app('request')->query();
?>
<section class="content">
	<!-- Default box -->
    <div class="card card-solid">
	
		<!-- /.card-body -->
        <div class="card-header">
			<h3 class="card-title"><span class="caption-subject font-green bold uppercase"><?php echo e(__('List FAQ')); ?></span></h3>
			<div class="card-tools">
				<a href="<?php echo e(route('data.faq.add')); ?>" class="btn btn-success btn-flat btn-sm"><i class="fa fa-plus"></i> New FAQ</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
				<!--button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fas fa-times"></i></button-->
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<?php echo e(Form::open(['url' => route('data.faq', $qparams),'method' => 'get'])); ?>

			<div class="row">
				<div class="col-md-5 form-group">
					<?php echo e(Form::text('keyword', app('request')->query('keyword'), ['class' => 'form-control','placeholder' => 'Keyword e.g: question, answer'])); ?>

				</div>
				<div class="col-md-3 form-group">
					<button class="btn btn-success" title="Search" type="submit"><i class="fa fa-filter"></i> Filter</button>
					<a href="<?php echo e(route('data.faq')); ?>" class="btn btn-warning" title="Cancel"><i class="fa fa-retweet"></i> Reset</a>
				</div>
			</div>
			<?php echo e(Form::close()); ?>

			<div class="tab-pane active">
				<table class="table table-hover table-striped">
					<thead>
						<tr>
							<th>#</th>
							<th scope="col"><a href="<?php echo e(URL::route('data.faq',['sort' => 'heading','direction'=> request()->direction == 'asc' ? 'desc' : 'asc'])); ?>">Question</a></th>
							<th scope="col" class="actions" style="width: 15%;">Actions</th>
						</tr>
					</thead>
					<?php if($faqs->count() > 0): ?>
					<tbody>
						<?php
						$i = (($faqs->currentPage() - 1) * ($faqs->perPage()) + 1)
						?>
						<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="row-<?php echo e($faq->id); ?>">
							<td> <?php echo e($i); ?>. </td>
							<td><?php echo e($faq->heading); ?></td>
							<td class="actions">
									<a href="<?php echo e(url('admin/faqs/view/'.$faq->id)); ?>" class="btn btn-warning btn-sm" data-toggle="tooltip" alt="View Category" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a>&nbsp;&nbsp;
									<a href="<?php echo e(url('admin/faqs/edit/'.$faq->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
									&nbsp;&nbsp;
									<a href="javascript:void(0);" class="confirmDeleteBtn btn btn-danger btn-sm btn-flat" data-toggle="tooltip" alt="Delete FAQ" data-url="<?php echo e(route('data.faq.delete', $faq->id)); ?>" data-title="FAQ"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						<?php
							$i++;
						?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<?php else: ?>
					<tfoot>
						<tr>
							<td colspan='7' align='center'> <strong>Record Not Available</strong> </td>
						</tr>
					</tfoot>
					<?php endif; ?>
				</table>
			</div>
		</div>
		<!-- /.card-body -->
        <div class="card-footer">
			<?php echo e($faqs->appends(Request::query())->links()); ?>

		 </div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>