
<?php $__env->startSection('title', 'Change Current Password'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Change Password</h1>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item active">Change Password</li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content" >
 <?php echo e(Form::open(['route' => 'admin.updatepassword'])); ?>

    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e(__("Change Password")); ?> 
				</span>
			</h3>
			<div class="card-tools">
				
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
			<div class="row">
				<div class="col-md-8 com-md-offset-2">
					<div class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?>">
							<div class="row">
						<label for="new-password" class="col-md-4 control-label">Current Password</label>
						<div class="col-md-6">
							<input id="current-password" value="<?php echo e(old("current-password")); ?>" type="password" class="form-control" name="current-password" placeholder="Current Password" required>

							<?php if($errors->has('current-password')): ?>
								<span class="help-block">
								<strong><?php echo e($errors->first('current-password')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
							</div>
					</div>

					<div class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?>">
							<div class="row">
						<label for="new-password" class="col-md-4 control-label">New Password</label>
						<div class="col-md-6">
							<input id="new-password" type="password" value="<?php echo e(old("new-password")); ?>" class="form-control" placeholder="New Password" name="new-password" required>
							<?php if($errors->has('new-password')): ?>
								<span class="help-block">
								<strong><?php echo e($errors->first('new-password')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
							</div>
					</div>

					<div class="form-group">
							<div class="row">
						<label for="new-password-confirm" class="col-md-4 control-label">Confirm New Password</label>
						<div class="col-md-6">
							<input id="new-password-confirm" type="password" value="<?php echo e(old("new-password_confirmation")); ?>" class="form-control" name="new-password_confirmation" placeholder="Confirm New Password" required>
						</div>
							</div>
					</div>
				</div>
			</div> <!-- /.row -->
		</div>
		<!-- /.card-footer -->
		<div class="card-footer">
			<button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Change Password</button>
		</div>
    </div>
<?php echo e(Form::close()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>