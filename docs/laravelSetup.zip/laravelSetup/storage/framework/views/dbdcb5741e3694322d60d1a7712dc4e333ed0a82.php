<?php $__env->startSection('title', !empty($page) ? 'Edit CMS Page' : 'Add CMS Page'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Header (Page header) -->

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-9">
		<h1 class="m-0 text-dark">Manage CMS Pages</h1>
		<small>Here you can add cms pages</small>
	  </div><!-- /.col -->
	  <div class="col-sm-3">
		<ol class="breadcrumb float-sm-right">
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="breadcrumb-item"><a href="<?php echo e(url('admin/pages')); ?>"><?php echo e(__("CMS Pages")); ?></a></li>
			<li class="breadcrumb-item active"><?php echo e(!empty($page) ? 'Edit CMS Page' : 'Add CMS Page'); ?></li>
		</ol>
	 </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
<?php if(isset($page)): ?>
	<?php echo e(Form::model($page, ['route' => ['admin.pages.update', $page->id], 'method' => 'patch'])); ?>

<?php else: ?>
	<?php echo e(Form::open(['route' => 'admin.pages.store'])); ?>

<?php endif; ?>
	<!-- Default box -->
    <div class="card card-solid">
		<!-- /.card-header -->
        <div class="card-header">
			<h3 class="card-title">
				<span class="caption-subject font-green bold uppercase">
					<?php echo e(!empty($page) ? 'Edit CMS Page' : 'Add CMS Page'); ?>

				</span>
			</h3>
			<div class="card-tools">
				<a href="<?php echo e(route('admin.pages.index')); ?>" class="btn btn-default pull-right" title="Cancel">
					<i class="fa fa-fw fa-chevron-circle-left"></i> 
					Back
				</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
			</div>
		</div>
		<!-- /.card-body -->
		<div class="card-body">
				<div class="row">
					<div class="col-md-6">

						<div class="form-group required <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
							<label for="title">Title</label>
							<?php echo e(Form::text('title', old('title'), ['class' => 'form-control','placeholder' => 'Title'])); ?>

							<?php if($errors->has('title')): ?>
							<span class="help-block"><?php echo e($errors->first('title')); ?></span>
							<?php endif; ?>
						</div>

						<div class="form-group <?php echo e($errors->has('sub_title') ? 'has-error' : ''); ?>">
							<label for="title">Sub Title</label>
							<?php echo e(Form::text('sub_title', old('sub_title'), ['class' => 'form-control','placeholder' => 'Sub Title'])); ?>

							<?php if($errors->has('sub_title')): ?>
							<span class="help-block"><?php echo e($errors->first('sub_title')); ?></span>
							<?php endif; ?>
						</div>

						<div class="form-group required <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
							<label for="title">Slug</label>
							<?php if(empty($page)): ?>
							<?php echo e(Form::text('slug', old('slug'), ['class' => 'form-control','placeholder' => 'Slug'])); ?>

							<?php endif; ?>
							<?php if(!empty($page)): ?>
							<?php echo e(Form::text('slug', old('slug'), ['class' => 'form-control','placeholder' => 'Slug','readonly'])); ?>

							<?php endif; ?>
							<?php if($errors->has('slug')): ?>
							<span class="help-block"><?php echo e($errors->first('slug')); ?></span>
							<?php endif; ?>
						</div>

						<div class="form-group">
							<label for="description">Short Description</label>
							<?php echo e(Form::textarea('short_description', old('short_description'), ['class' => 'form-control','placeholder' => 'Short Description', 'rows' => 4])); ?>

						</div>

					</div>

					<div class="col-md-6">
						<div class="form-group required <?php echo e($errors->has('meta_title') ? 'has-error' : ''); ?>">
							<label for="title">Meta Title</label>
							<?php echo e(Form::text('meta_title', old('meta_title'), ['class' => 'form-control','placeholder' => 'Meta Title'])); ?>

							<?php if($errors->has('meta_title')): ?>
							<span class="help-block"><?php echo e($errors->first('meta_title')); ?></span>
							<?php endif; ?>
						</div>

						<div class="form-group required <?php echo e($errors->has('meta_keyword') ? 'has-error' : ''); ?>">
							<label for="title">Meta Keyword</label>
							<?php echo e(Form::text('meta_keyword', old('meta_keyword'), ['class' => 'form-control','placeholder' => 'Meta Keyword'])); ?>

							<?php if($errors->has('meta_keyword')): ?>
							<span class="help-block"><?php echo e($errors->first('meta_keyword')); ?></span>
							<?php endif; ?>
						</div>

						<div class="form-group required <?php echo e($errors->has('meta_description') ? 'has-error' : ''); ?>">
							<label for="description">Meta Description</label>
							<?php echo e(Form::textarea('meta_description', old('meta_description'), ['class' => 'form-control','placeholder' => 'Meta Description', 'rows' => 8])); ?>

							<?php if($errors->has('meta_description')): ?>
							<span class="help-block"><?php echo e($errors->first('meta_description')); ?></span>
							<?php endif; ?>
						</div>

					</div>
				</div> <!-- /.row -->

				<div class="row">
					<div class="col-md-12">

						<div class="form-group required <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
							<label for="description">Description</label>
							<?php echo e(Form::textarea('description', old('description'), ['class' => 'form-control ckeditor','placeholder' => 'Description', 'rows' => 8])); ?>

							<?php if($errors->has('description')): ?>
							<span class="help-block"><?php echo e($errors->first('description')); ?></span>
							<?php endif; ?>
						</div>


					</div>
				</div>
		</div>
		<!-- /.card-footer -->
		<div class="card-footer">
			<button class="btn btn-primary btn-flat" title="Submit" type="submit"><i class="fa fa-fw fa-save"></i> Submit</button>
		</div>
	</div>
<?php echo e(Form::close()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>