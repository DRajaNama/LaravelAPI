<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
   <p class="login-box-msg">Sign in to start your session</p>
    <?php
    $cfo = [];
     if(Request::cookie('adminckrem')){
         $cfo = json_decode(Request::cookie('adminckrem'), true);
     }
    ?>
    <form method="POST" action="<?php echo e(route('admin.login')); ?>">
         <?php echo csrf_field(); ?>
     
	   <?php if($errors->has('email')): ?>
		<label class="col-form-label text-danger" for="email">
			<i class="far fa-times-circle"></i> 
			<?php echo e($errors->first('email')); ?>

		</label>
	   <?php endif; ?>
	  <div class="input-group mb-3 ">
		<input id="email" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email') ? old('email') : (!empty($cfo['email']) ? $cfo['email'] : '')); ?>" placeholder="<?php echo e(__('E-Mail Address')); ?>">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope <?php echo e($errors->has('email') ? ' text-danger' : ''); ?>"></span>
            </div>
          </div>
	 </div>
	 
	 <?php if($errors->has('password')): ?>
		<label class="col-form-label text-danger" for="password">
			<i class="far fa-times-circle"></i> 
			<?php echo e($errors->first('password')); ?>

		</label>
	   <?php endif; ?>
	  <div class="input-group mb-3 ">
		 <input id="password" type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('password') ? old('password') :  (!empty($cfo['password']) ? $cfo['password'] : '')); ?>" name="password" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock <?php echo e($errors->has('password') ? ' text-danger' : ''); ?>"></span>
            </div>
          </div>
	 </div>
	 
     
	  
	  <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input  value="1" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked="checked"' : (!empty($cfo['remember']) ? 'checked="checked"' : '')); ?> >
              <label for="remember">
                Remember Me
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
    </form>
<div class="social-auth-links text-center">
      <p>- OR -</p>
     <a href="<?php echo e(route('admin.password.request')); ?>">I forgot my password</a>
    </div>
    <!-- /.social-auth-links -->
	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.login', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>