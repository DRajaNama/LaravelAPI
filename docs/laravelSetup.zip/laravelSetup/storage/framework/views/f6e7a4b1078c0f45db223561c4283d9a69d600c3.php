
<?php $__env->startSection('title','User Manager'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin.flash.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Content Header (Page header) -->

<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-6">
		<h1 class="m-0 text-dark">Manage Users</h1>
		<small>Here you can manage users</small>
	  </div><!-- /.col -->
	  <div class="col-sm-6">
		<ol class="breadcrumb float-sm-right">
		  <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Home</a></li>
		  <li class="breadcrumb-item active">Users</li>
		</ol>
	  </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card card-solid">
		 
		<!-- /.card-body -->
        <div class="card-header">
			<h3 class="card-title"><span class="caption-subject font-green bold uppercase"><?php echo e(__('List Users')); ?></span></h3>
			<div class="card-tools">
				<a href="<?php echo e(route('admin.users.add')); ?>" class="btn btn-success btn-flat pull-right"><i class="fa fa-plus"></i> Add New User</a>
				<button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fas fa-minus"></i></button>
				<!--button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fas fa-times"></i></button-->
			</div>
		</div>
		<!-- /.card-body -->
        <div class="card-body">
		<?php echo e(Form::open(['url' => route('admin.users'),'method' => 'get'])); ?>

			<div class="row">
				<div class="col-lg-4 ">
					<?php echo e(Form::select('status', ['' => 'All',1 => 'Active', 0 => 'Inactive'], app('request')->query('status'), ['class' => 'form-control'])); ?>

				</div>
				<div class="col-lg-4">
					<?php echo e(Form::text('keyword', app('request')->query('keyword'), ['class' => 'form-control','placeholder' => 'Keyword e.g: name, email'])); ?>

				</div>
				<div class="coll-lg-4">
					<button class="btn btn-success" title="Search" type="submit"><i class="fa fa-filter"></i> Filter</button>
					<a href="<?php echo e(route('admin.users')); ?>" class="btn btn-warning" title="Cancel"><i class="fa fa-retweet"></i> Reset</a>
				</div>
			</div>
		<?php echo e(Form::close()); ?>

		<br>
          <div class="row">
				<div class="col-lg-12">
							
					<table class="table table-hover table-striped">
						<thead>
							<tr>
								<th>#</th>
								<th scope="col"> <?php
									$sorting['sort'] = "first_name";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">First Name</a></th>
								<th scope="col"> <?php
									$sorting['sort'] = "last_name";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">Last Name</a></th>
								<th scope="col">Photo</th>
								<th scope="col"><?php
									$sorting['sort'] = "email";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">Email</a></th>
								<th scope="col"><?php
									$sorting['sort'] = "status";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">Status</a></th>
								<th scope="col"><?php
									$sorting['sort'] = "is_verified";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">Verified</a></th>
								<th scope="col" width="18%"><?php
									$sorting['sort'] = "created_at";
									$sorting['direction'] = request()->direction == 'asc' ? 'desc' : 'asc';
									?>
									<a href="<?php echo e(URL::route('admin.users',$sorting)); ?>">Created</a></th>
								<th scope="col" class="actions" width="12%">Action</th>
							</tr>
						</thead>
						<?php if($users->count() > 0): ?>
						<tbody>
							<?php
							$i = (($users->currentPage() - 1) * ($users->perPage()) + 1)
							?>
							<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr class="row-<?php echo e($user->id); ?>">
								<td> <?php echo e($i); ?>. </td>
								<td><?php echo e($user->first_name); ?></td>
								<td><?php echo e($user->last_name); ?></td>
								<td><?php
									$filepath = '/uploads/users/';
									?>


									<?php if(!empty($user->photo) && file_exists(public_path() . $filepath . $user->photo)): ?>
									<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url($filepath . $user->photo), '100', '100', '100'); ?>

									<?php else: ?>
									<?php $imageurl = \App\Helpers\MenuHelpers::imageUrl(url('img/no_image.gif'), '100', '100', '100'); ?>
									<?php endif; ?>

									<img src="<?php echo e($imageurl); ?>" class=" img-responsive img-thumbnail" alt="<?php echo e($user->name); ?>">      
								</td>
								<td><?php echo e($user->email); ?></td>
								<td><?php echo e($user->status == 1 ? "Active" : "In-Active"); ?></td>
								<td><?php echo e($user->is_verified == 1 ? "Verified" : "Not Verified"); ?></td>
								<td><?php echo e($user->created_at->format(config('get.ADMIN_DATE_TIME_FORMAT'))); ?></td>
								<td class="actions">
									<div class="form-group">
										<a href="<?php echo e(route('admin.users.view',['id' => $user->id])); ?>" class="btn btn-warning btn-sm btn-flat" data-toggle="tooltip" alt="View" title="" data-original-title="View"><i class="fa fa-fw fa-eye"></i></a> 
										<a href="<?php echo e(route('admin.users.edit',['id' => $user->id])); ?>" class="btn btn-primary btn-sm btn-flat" data-toggle="tooltip" alt="Edit" title="" data-original-title="Edit"><i class="fa fa-edit"></i></a>
										<a href="javascript:void(0);" class="confirmDeleteBtn reload btn btn-danger btn-sm btn-flat"  alt="Delete <?php echo e($user->name); ?>" data-url="<?php echo e(route('admin.users.delete', $user->id)); ?>" data-title="<?php echo e($user->name); ?>"><i class="fa fa-trash"></i></a>
									</div>
								</td>
							</tr>
							<?php
							$i++;
							?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<?php else: ?>
						<tfoot>
							<tr>
								<td colspan='9' align='center'> <strong>Record Not Available</strong> </td>
							</tr>
						</tfoot>
						<?php endif; ?>
					</table>
						
				</div>	
			</div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          <?php echo e($users->appends(Request::query())->links()); ?>

        </div>
        <!-- /.card-footer -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>